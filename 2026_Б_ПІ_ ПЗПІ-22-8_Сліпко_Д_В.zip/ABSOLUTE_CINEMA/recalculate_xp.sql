-- ============================================================
-- ABSOLUTE CINEMA — Перерахунок XP та досягнень для старих користувачів
-- Цей скрипт збирає всі попередні дії користувачів і нараховує їм XP та досягнення
-- ============================================================

DO $$
DECLARE
    r RECORD;
    v_base_xp INTEGER;
BEGIN
    FOR r IN SELECT user_id FROM profiles LOOP
        v_base_xp := 0;

        -- 1. Рецензії (30 XP за кожну)
        SELECT COALESCE(COUNT(*), 0) * 30 INTO v_base_xp
        FROM reviews WHERE user_id = r.user_id;

        -- 2. Обране (10 XP за кожне)
        v_base_xp := v_base_xp + COALESCE((SELECT COUNT(*) * 10 FROM favorites WHERE user_id = r.user_id), 0);

        -- 3. Історія переглядів (10 XP за кожну)
        v_base_xp := v_base_xp + COALESCE((SELECT COUNT(*) * 10 FROM watch_history WHERE user_id = r.user_id), 0);

        -- 4. Коментарі в обговореннях (15 XP за кожен)
        v_base_xp := v_base_xp + COALESCE((SELECT COUNT(*) * 15 FROM discussion_comments WHERE user_id = r.user_id), 0);

        -- 5. Створені обговорення (25 XP за кожне)
        v_base_xp := v_base_xp + COALESCE((SELECT COUNT(*) * 25 FROM discussions WHERE creator_id = r.user_id), 0);

        -- 6. Лайки на власні рецензії (5 XP за кожен лайк)
        v_base_xp := v_base_xp + COALESCE((
            SELECT COUNT(*) * 5
            FROM review_likes rl
            JOIN reviews rev ON rev.id = rl.review_id
            WHERE rev.user_id = r.user_id
        ), 0);

        -- Оновлюємо базовий досвід користувача
        INSERT INTO user_xp (user_id, xp, updated_at)
        VALUES (r.user_id, v_base_xp, now())
        ON CONFLICT (user_id) DO UPDATE
            SET xp = v_base_xp,
                updated_at = now();

        -- Запускаємо перевірку досягнень для користувача
        -- Ця функція також додасть бонусний XP за самі досягнення!
        PERFORM check_and_grant_achievements(r.user_id);
    END LOOP;
END;
$$;
