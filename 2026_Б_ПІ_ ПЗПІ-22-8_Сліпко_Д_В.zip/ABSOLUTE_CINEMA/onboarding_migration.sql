-- ================================================================
-- ABSOLUTE CINEMA: Onboarding Migration
-- Виконати у Supabase SQL Editor
-- ================================================================

-- 1. Додаємо колонки до таблиці profiles
ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS genre_preferences JSONB DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS onboarding_completed BOOLEAN DEFAULT FALSE NOT NULL;

-- 2. RLS-політики для нових колонок
-- Оскільки колонки є частиною таблиці profiles, RLS вже діє.
-- Але на бекенді ми використовуємо supabaseAdmin (SERVICE_KEY) → обходить RLS.

-- 3. Якщо ви хочете дозволити USER самостійно читати/оновлювати свої prefs
--    через frontend (не через бекенд), додайте ці політики:

-- Дозволяємо юзеру оновлювати лише свій профіль (включно з новими колонками)
CREATE POLICY IF NOT EXISTS "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Дозволяємо юзеру читати свій профіль
CREATE POLICY IF NOT EXISTS "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- ================================================================
-- ПЕРЕВІРКА: після виконання запиту виконайте цей SELECT
-- ================================================================
-- SELECT column_name, data_type FROM information_schema.columns
-- WHERE table_name = 'profiles'
-- AND column_name IN ('genre_preferences', 'onboarding_completed');
