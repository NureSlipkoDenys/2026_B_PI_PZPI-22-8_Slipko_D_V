-- ============================================================
-- МІГРАЦІЯ: Групові чати (group chats)
-- Вставте у Supabase SQL Editor і виконайте RUN
-- ============================================================

-- 1. Таблиця групових чатів
CREATE TABLE IF NOT EXISTS group_chats (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT,
    avatar_url  TEXT,
    owner_id    UUID NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Таблиця учасників групового чату
CREATE TABLE IF NOT EXISTS group_chat_members (
    id         SERIAL PRIMARY KEY,
    group_id   INTEGER NOT NULL REFERENCES group_chats(id) ON DELETE CASCADE,
    user_id    UUID    NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
    role       TEXT    NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
    joined_at  TIMESTAMPTZ DEFAULT NOW(),
    last_read_at TIMESTAMPTZ,
    UNIQUE(group_id, user_id)
);

-- 3. Таблиця повідомлень групового чату
CREATE TABLE IF NOT EXISTS group_chat_messages (
    id          SERIAL PRIMARY KEY,
    group_id    INTEGER NOT NULL REFERENCES group_chats(id) ON DELETE CASCADE,
    sender_id   UUID    NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
    content     TEXT    NOT NULL,
    reply_to_id INTEGER REFERENCES group_chat_messages(id) ON DELETE SET NULL,
    sent_at     TIMESTAMPTZ DEFAULT NOW()
);

-- Індекси
CREATE INDEX IF NOT EXISTS idx_gcm_group_id ON group_chat_members(group_id);
CREATE INDEX IF NOT EXISTS idx_gcm_user_id  ON group_chat_members(user_id);
CREATE INDEX IF NOT EXISTS idx_gcmsg_group  ON group_chat_messages(group_id);
CREATE INDEX IF NOT EXISTS idx_gcmsg_time   ON group_chat_messages(sent_at);

-- 4. RLS
ALTER TABLE group_chats           ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_chat_members    ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_chat_messages   ENABLE ROW LEVEL SECURITY;

-- group_chats: читати може учасник
CREATE POLICY "gc_select_member"
ON group_chats FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM group_chat_members
        WHERE group_chat_members.group_id = group_chats.id
        AND group_chat_members.user_id = auth.uid()
    )
);

-- group_chats: створювати може авторизований
CREATE POLICY "gc_insert_auth"
ON group_chats FOR INSERT
WITH CHECK (auth.uid() = owner_id);

-- group_chats: оновлювати може власник або адмін
CREATE POLICY "gc_update_owner_admin"
ON group_chats FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM group_chat_members
        WHERE group_chat_members.group_id = group_chats.id
        AND group_chat_members.user_id = auth.uid()
        AND group_chat_members.role IN ('owner', 'admin')
    )
);

-- group_chats: видаляти може тільки власник
CREATE POLICY "gc_delete_owner"
ON group_chats FOR DELETE
USING (owner_id = auth.uid());

-- group_chat_members: читати може учасник
CREATE POLICY "gcm_select_member"
ON group_chat_members FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM group_chat_members gcm2
        WHERE gcm2.group_id = group_chat_members.group_id
        AND gcm2.user_id = auth.uid()
    )
);

-- group_chat_members: вставляти може власник або адмін
CREATE POLICY "gcm_insert_owner_admin"
ON group_chat_members FOR INSERT
WITH CHECK (
    auth.uid() = user_id  -- додати себе (при створенні)
    OR EXISTS (
        SELECT 1 FROM group_chat_members gcm2
        WHERE gcm2.group_id = group_chat_members.group_id
        AND gcm2.user_id = auth.uid()
        AND gcm2.role IN ('owner', 'admin')
    )
);

-- group_chat_members: видаляти може власник/адмін або сам себе
CREATE POLICY "gcm_delete_self_or_admin"
ON group_chat_members FOR DELETE
USING (
    user_id = auth.uid()
    OR EXISTS (
        SELECT 1 FROM group_chat_members gcm2
        WHERE gcm2.group_id = group_chat_members.group_id
        AND gcm2.user_id = auth.uid()
        AND gcm2.role IN ('owner', 'admin')
    )
);

-- group_chat_members: оновлювати роль може власник
CREATE POLICY "gcm_update_owner"
ON group_chat_members FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM group_chat_members gcm2
        WHERE gcm2.group_id = group_chat_members.group_id
        AND gcm2.user_id = auth.uid()
        AND gcm2.role = 'owner'
    )
);

-- group_chat_messages: читати може учасник
CREATE POLICY "gcmsg_select_member"
ON group_chat_messages FOR SELECT
USING (
    EXISTS (
        SELECT 1 FROM group_chat_members
        WHERE group_chat_members.group_id = group_chat_messages.group_id
        AND group_chat_members.user_id = auth.uid()
    )
);

-- group_chat_messages: вставляти може учасник
CREATE POLICY "gcmsg_insert_member"
ON group_chat_messages FOR INSERT
WITH CHECK (
    auth.uid() = sender_id
    AND EXISTS (
        SELECT 1 FROM group_chat_members
        WHERE group_chat_members.group_id = group_chat_messages.group_id
        AND group_chat_members.user_id = auth.uid()
    )
);

-- ============================================================
-- ГОТОВО! Тепер виконайте backend-код та frontend-зміни.
-- ============================================================
