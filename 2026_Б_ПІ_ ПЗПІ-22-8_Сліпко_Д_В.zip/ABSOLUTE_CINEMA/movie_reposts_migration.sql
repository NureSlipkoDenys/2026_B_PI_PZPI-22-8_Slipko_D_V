-- ============================================================
-- МІГРАЦІЯ: Таблиця movie_reposts для функції "Скинути другу"
-- Вставте цей SQL у Supabase SQL Editor і виконайте
-- ============================================================

-- 1. Створення таблиці
CREATE TABLE IF NOT EXISTS movie_reposts (
    id          SERIAL PRIMARY KEY,
    media_id    INTEGER NOT NULL REFERENCES media(id) ON DELETE CASCADE,
    user_id     UUID    NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
    chat_id     INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Індекс для швидкого підрахунку репостів за фільмом
CREATE INDEX IF NOT EXISTS idx_movie_reposts_media_id ON movie_reposts(media_id);
-- Індекс для пошуку за користувачем
CREATE INDEX IF NOT EXISTS idx_movie_reposts_user_id ON movie_reposts(user_id);

-- 2. Увімкнення RLS
ALTER TABLE movie_reposts ENABLE ROW LEVEL SECURITY;

-- 3. RLS Policies

-- Читати кількість репостів може будь-хто (навіть анонім, для лічильника на сторінці фільму)
CREATE POLICY "movie_reposts_select_all"
ON movie_reposts
FOR SELECT
USING (true);

-- Вставляти репост може тільки авторизований власник запису
CREATE POLICY "movie_reposts_insert_own"
ON movie_reposts
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Видаляти свої репости (необов'язково, але хорошa практика)
CREATE POLICY "movie_reposts_delete_own"
ON movie_reposts
FOR DELETE
USING (auth.uid() = user_id);

-- ============================================================
-- ГОТОВО! Тепер надайте доступ сервісному ключу (service_role).
-- Service role автоматично обходить RLS, тому додаткових
-- політик для нього не потрібно.
-- ============================================================

-- Якщо у вас вже є проблеми з INSERT у chat_messages через RLS,
-- переконайтесь що є наступна policy (виконайте якщо ще не маєте):
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'chat_messages'
    AND policyname = 'chat_messages_insert_participant'
  ) THEN
    EXECUTE '
      CREATE POLICY "chat_messages_insert_participant"
      ON chat_messages
      FOR INSERT
      WITH CHECK (
        auth.uid() = sender_id
        AND EXISTS (
          SELECT 1 FROM chats
          WHERE chats.id = chat_messages.chat_id
          AND (chats.user1_id = auth.uid() OR chats.user2_id = auth.uid())
        )
      )
    ';
  END IF;
END $$;
