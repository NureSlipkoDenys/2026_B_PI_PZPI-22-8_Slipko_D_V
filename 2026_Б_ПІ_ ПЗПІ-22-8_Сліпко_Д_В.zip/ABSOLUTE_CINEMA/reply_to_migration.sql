-- ============================================================
-- МІГРАЦІЯ: Додати reply_to_id до chat_messages
-- Вставте у Supabase SQL Editor і виконайте RUN
-- ============================================================

-- 1. Додати колонку reply_to_id (посилання на оригінальне повідомлення)
ALTER TABLE chat_messages
ADD COLUMN IF NOT EXISTS reply_to_id INTEGER REFERENCES chat_messages(id) ON DELETE SET NULL;

-- Індекс для швидкого пошуку відповідей
CREATE INDEX IF NOT EXISTS idx_chat_messages_reply_to ON chat_messages(reply_to_id)
  WHERE reply_to_id IS NOT NULL;

-- 2. RLS — дозволити читання chat_messages (якщо ще не існує policy)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'chat_messages'
    AND policyname = 'chat_messages_select_participant'
  ) THEN
    EXECUTE '
      CREATE POLICY "chat_messages_select_participant"
      ON chat_messages
      FOR SELECT
      USING (
        EXISTS (
          SELECT 1 FROM chats
          WHERE chats.id = chat_messages.chat_id
          AND (chats.user1_id = auth.uid() OR chats.user2_id = auth.uid())
        )
      )
    ';
  END IF;
END $$;

-- ============================================================
-- ГОТОВО! reply_to_id тепер доступна у таблиці chat_messages.
-- ============================================================
