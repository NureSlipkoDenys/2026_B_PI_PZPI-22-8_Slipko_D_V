// test-db.js
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

// Створюємо клієнта Supabase з використанням змінних середовища
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Спробуємо створити клієнта із сервісним ключем, якщо він є
const supabaseAdmin = process.env.SUPABASE_SERVICE_KEY
  ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY)
  : null;

// Функція для перевірки підключення
async function testConnection() {
  console.log('Перевірка підключення до Supabase...');
  console.log('SUPABASE_URL:', process.env.SUPABASE_URL);
  console.log('SUPABASE_ANON_KEY:', process.env.SUPABASE_ANON_KEY ? 'Ключ задано' : 'Ключ не задано');
  console.log('SUPABASE_SERVICE_KEY:', process.env.SUPABASE_SERVICE_KEY ? 'Ключ задано' : 'Ключ не задано');

  try {
    // Перевірка підключення з публічним ключем
    console.log('\n1. Перевірка доступу з публічним ключем:');
    const { data: profilesData, error: profilesError } = await supabase
      .from('profiles')
      .select('*')
      .limit(1);

    if (profilesError) {
      console.error('  ❌ Помилка доступу до таблиці profiles:', profilesError.message);
    } else {
      console.log('  ✅ Успішний доступ до таблиці profiles');
      console.log('  📊 Дані:', JSON.stringify(profilesData, null, 2));
    }

    // Перевірка Auth API
    console.log('\n2. Перевірка Auth API:');
    const { data: authData, error: authError } = await supabase.auth.getSession();

    if (authError) {
      console.error('  ❌ Помилка Auth API:', authError.message);
    } else {
      console.log('  ✅ Auth API працює коректно');
      console.log('  🔑 Поточна сесія:', authData.session ? 'Активна' : 'Відсутня');
    }

    // Перевірка із сервісним ключем, якщо він заданий
    if (supabaseAdmin) {
      console.log('\n3. Перевірка доступу із сервісним ключем:');
      try {
        const { data: adminData, error: adminError } = await supabaseAdmin
          .from('profiles')
          .select('*')
          .limit(1);

        if (adminError) {
          console.error('  ❌ Помилка доступу із сервісним ключем:', adminError.message);
        } else {
          console.log('  ✅ Успішний доступ із сервісним ключем');
          console.log('  📊 Дані:', JSON.stringify(adminData, null, 2));
        }

        // Спробуємо скористатися адміністративним API
        const { data: userList, error: userListError } = await supabaseAdmin.auth.admin.listUsers();

        if (userListError) {
          console.error('  ❌ Помилка доступу до адміністративного API:', userListError.message);
        } else {
          console.log('  ✅ Адміністративний API працює коректно');
          console.log(`  👥 Кількість користувачів: ${userList.users ? userList.users.length : 'Н/Д'}`);
        }
      } catch (adminErr) {
        console.error('  ❌ Помилка при використанні сервісного ключа:', adminErr);
      }
    } else {
      console.log('\n3. Перевірка із сервісним ключем: ❌ Ключ не задано');
    }

    // Перевірка наявності необхідних таблиць
    console.log('\n4. Перевірка структури БД:');
    const client = supabaseAdmin || supabase;

    // Отримуємо список таблиць
    try {
      const { data: tablesData, error: tablesError } = await client.rpc('get_tables');

      if (tablesError) {
        console.error('  ❌ Помилка отримання списку таблиць:', tablesError.message);
      } else {
        const tables = tablesData || [];
        const requiredTables = ['profiles'];

        console.log('  📋 Знайдені таблиці:', tables.join(', '));

        for (const table of requiredTables) {
          if (tables.includes(table)) {
            console.log(`  ✅ Таблиця '${table}' існує`);
          } else {
            console.log(`  ❌ Таблиця '${table}' не знайдена`);
          }
        }
      }
    } catch (rpcErr) {
      console.log('  ℹ️ Не вдалося отримати список таблиць через RPC, пробуємо альтернативний метод');

      // Альтернативний спосіб перевірки таблиці profiles
      const { error: profilesCheckError } = await client
        .from('profiles')
        .select('count')
        .limit(1);

      if (profilesCheckError) {
        console.log('  ❌ Таблиця profiles недоступна:', profilesCheckError.message);
      } else {
        console.log('  ✅ Таблиця profiles існує і доступна');
      }
    }

    console.log('\n5. Підсумковий результат:');
    if (profilesError && authError) {
      console.log('  ❌ КРИТИЧНА ПОМИЛКА: Не вдалося підключитися до Supabase');
      return false;
    } else if (profilesError) {
      console.log('  ⚠️ ЧАСТКОВО ПРАЦЮЄ: Auth API працює, але є проблеми з доступом до даних');
      return true;
    } else {
      console.log('  ✅ УСПІШНО: Підключення до Supabase працює коректно');
      return true;
    }
  } catch (err) {
    console.error('\n❌ КРИТИЧНА ПОМИЛКА:', err);
    return false;
  }
}

// Запускаємо перевірку
testConnection().then(success => {
  console.log('\nПеревірку завершено', success ? 'успішно! 🎉' : 'з помилками ❌');
  process.exit(success ? 0 : 1);
});
