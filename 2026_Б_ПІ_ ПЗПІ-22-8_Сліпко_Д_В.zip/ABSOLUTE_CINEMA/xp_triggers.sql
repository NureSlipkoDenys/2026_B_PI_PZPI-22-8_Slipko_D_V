-- ============================================================
-- ABSOLUTE CINEMA — Тригери нарахування XP та досягнень
-- Файл: xp_triggers.sql
-- Застосовувати ПІСЛЯ achievements_migration.sql
-- ============================================================

-- ============================================================
-- ДОПОМІЖНА ФУНКЦІЯ: перевірка і видача досягнень
-- на основі поточної статистики користувача
-- ============================================================
CREATE OR REPLACE FUNCTION check_and_grant_achievements(p_user_id UUID)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_review_count     INTEGER;
    v_fav_count        INTEGER;
    v_watch_count      INTEGER;
    v_comment_count    INTEGER;
    v_discussion_count INTEGER;
    v_likes_received   INTEGER;
    v_level            INTEGER;
    v_no_spoiler_count INTEGER;
BEGIN
    -- Збираємо статистику користувача
    SELECT COUNT(*) INTO v_review_count
        FROM reviews WHERE user_id = p_user_id;

    SELECT COUNT(*) INTO v_no_spoiler_count
        FROM reviews WHERE user_id = p_user_id AND contains_spoilers = FALSE;

    SELECT COUNT(*) INTO v_fav_count
        FROM favorites WHERE user_id = p_user_id;

    SELECT COUNT(*) INTO v_watch_count
        FROM watch_history WHERE user_id = p_user_id;

    SELECT COUNT(*) INTO v_comment_count
        FROM discussion_comments WHERE user_id = p_user_id;

    SELECT COUNT(*) INTO v_discussion_count
        FROM discussions WHERE creator_id = p_user_id;

    SELECT COALESCE(SUM(rl.cnt), 0) INTO v_likes_received
        FROM (
            SELECT COUNT(*) AS cnt
            FROM review_likes rl
            JOIN reviews r ON r.id = rl.review_id
            WHERE r.user_id = p_user_id
        ) rl;

    SELECT get_level_from_xp(COALESCE(xp, 0)) INTO v_level
        FROM user_xp WHERE user_id = p_user_id;

    -- === РЕЦЕНЗІЇ ===
    IF v_review_count >= 1   THEN PERFORM grant_achievement(p_user_id, 'first_review');   END IF;
    IF v_review_count >= 5   THEN PERFORM grant_achievement(p_user_id, 'review_5');        END IF;
    IF v_review_count >= 10  THEN PERFORM grant_achievement(p_user_id, 'review_10');       END IF;
    IF v_review_count >= 25  THEN PERFORM grant_achievement(p_user_id, 'review_25');       END IF;
    IF v_review_count >= 50  THEN PERFORM grant_achievement(p_user_id, 'review_50');       END IF;
    IF v_review_count >= 100 THEN PERFORM grant_achievement(p_user_id, 'review_100');      END IF;

    IF v_no_spoiler_count >= 10 THEN PERFORM grant_achievement(p_user_id, 'spoiler_master'); END IF;

    -- === ЛАЙКИ НА РЕЦЕНЗІЇ ===
    IF v_likes_received >= 10  THEN PERFORM grant_achievement(p_user_id, 'liked_review_10');  END IF;
    IF v_likes_received >= 50  THEN PERFORM grant_achievement(p_user_id, 'liked_review_50');  END IF;
    IF v_likes_received >= 100 THEN PERFORM grant_achievement(p_user_id, 'liked_review_100'); END IF;

    -- === ОБРАНЕ ===
    IF v_fav_count >= 1   THEN PERFORM grant_achievement(p_user_id, 'first_favorite'); END IF;
    IF v_fav_count >= 10  THEN PERFORM grant_achievement(p_user_id, 'favorites_10');   END IF;
    IF v_fav_count >= 25  THEN PERFORM grant_achievement(p_user_id, 'favorites_25');   END IF;
    IF v_fav_count >= 50  THEN PERFORM grant_achievement(p_user_id, 'favorites_50');   END IF;
    IF v_fav_count >= 100 THEN PERFORM grant_achievement(p_user_id, 'favorites_100');  END IF;

    -- === ІСТОРІЯ ПЕРЕГЛЯДІВ ===
    IF v_watch_count >= 1   THEN PERFORM grant_achievement(p_user_id, 'first_watch');   END IF;
    IF v_watch_count >= 10  THEN PERFORM grant_achievement(p_user_id, 'watched_10');    END IF;
    IF v_watch_count >= 50  THEN PERFORM grant_achievement(p_user_id, 'watched_50');    END IF;
    IF v_watch_count >= 100 THEN PERFORM grant_achievement(p_user_id, 'watched_100');   END IF;
    IF v_watch_count >= 250 THEN PERFORM grant_achievement(p_user_id, 'watched_250');   END IF;

    -- === КОМЕНТАРІ ===
    IF v_comment_count >= 1   THEN PERFORM grant_achievement(p_user_id, 'first_comment'); END IF;
    IF v_comment_count >= 50  THEN PERFORM grant_achievement(p_user_id, 'comment_50');    END IF;
    IF v_comment_count >= 100 THEN PERFORM grant_achievement(p_user_id, 'comment_100');   END IF;

    -- === ОБГОВОРЕННЯ ===
    IF v_discussion_count >= 1  THEN PERFORM grant_achievement(p_user_id, 'first_discussion'); END IF;
    IF v_discussion_count >= 10 THEN PERFORM grant_achievement(p_user_id, 'discussion_10');    END IF;

    -- === РІВНІ ===
    IF v_level >= 5   THEN PERFORM grant_achievement(p_user_id, 'level_5');   END IF;
    IF v_level >= 15  THEN PERFORM grant_achievement(p_user_id, 'level_15');  END IF;
    IF v_level >= 30  THEN PERFORM grant_achievement(p_user_id, 'level_30');  END IF;
    IF v_level >= 50  THEN PERFORM grant_achievement(p_user_id, 'level_50');  END IF;
    IF v_level >= 75  THEN PERFORM grant_achievement(p_user_id, 'level_75');  END IF;
    IF v_level >= 100 THEN PERFORM grant_achievement(p_user_id, 'level_100'); END IF;

END;
$$;

-- ============================================================
-- ТРИГЕР 1: Нова рецензія → +30 XP
-- Приховане досягнення «Нічна сова» (🦉) — рецензія після 00:00
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_review_insert()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    -- Нараховуємо XP
    PERFORM add_xp(NEW.user_id, 30);

    -- Перевіряємо досягнення
    PERFORM check_and_grant_achievements(NEW.user_id);

    -- Приховане: написав рецензію після півночі (00:00–05:00 за UTC+3)
    IF EXTRACT(HOUR FROM (NEW.created_at AT TIME ZONE 'Europe/Kiev')) BETWEEN 0 AND 4 THEN
        PERFORM grant_achievement(NEW.user_id, 'night_owl');
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_review ON reviews;
CREATE TRIGGER trg_xp_review
    AFTER INSERT ON reviews
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_review_insert();

-- ============================================================
-- ТРИГЕР 2: Лайк на рецензію → +5 XP автору рецензії
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_review_like()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_author_id UUID;
BEGIN
    -- Знаходимо автора рецензії
    SELECT user_id INTO v_author_id
        FROM reviews WHERE id = NEW.review_id;

    -- Не нараховуємо XP за лайк власної рецензії
    IF v_author_id IS NOT NULL AND v_author_id <> NEW.user_id THEN
        PERFORM add_xp(v_author_id, 5);
        PERFORM check_and_grant_achievements(v_author_id);
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_review_like ON review_likes;
CREATE TRIGGER trg_xp_review_like
    AFTER INSERT ON review_likes
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_review_like();

-- ============================================================
-- ТРИГЕР 3: Додавання в обране → +5 XP
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_favorite()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    PERFORM add_xp(NEW.user_id, 5);
    PERFORM check_and_grant_achievements(NEW.user_id);
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_favorite ON favorites;
CREATE TRIGGER trg_xp_favorite
    AFTER INSERT ON favorites
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_favorite();

-- ============================================================
-- ТРИГЕР 4: Додавання в історію переглядів → +10 XP
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_watch()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    PERFORM add_xp(NEW.user_id, 10);
    PERFORM check_and_grant_achievements(NEW.user_id);
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_watch ON watch_history;
CREATE TRIGGER trg_xp_watch
    AFTER INSERT ON watch_history
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_watch();

-- ============================================================
-- ТРИГЕР 5: Нове обговорення → +20 XP
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_discussion()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF NEW.creator_id IS NOT NULL THEN
        PERFORM add_xp(NEW.creator_id, 20);
        PERFORM check_and_grant_achievements(NEW.creator_id);
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_discussion ON discussions;
CREATE TRIGGER trg_xp_discussion
    AFTER INSERT ON discussions
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_discussion();

-- ============================================================
-- ТРИГЕР 6: Новий коментар в обговоренні → +10 XP
-- ============================================================
CREATE OR REPLACE FUNCTION trg_xp_on_comment()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF NEW.user_id IS NOT NULL THEN
        PERFORM add_xp(NEW.user_id, 10);
        PERFORM check_and_grant_achievements(NEW.user_id);
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_xp_comment ON discussion_comments;
CREATE TRIGGER trg_xp_comment
    AFTER INSERT ON discussion_comments
    FOR EACH ROW EXECUTE FUNCTION trg_xp_on_comment();

-- ============================================================
-- ТРИГЕР 7: Перевірка рівнів при кожній зміні XP
-- Потрібен для досягнень level_5, level_15 і т.д.
-- ============================================================
CREATE OR REPLACE FUNCTION trg_check_level_achievements()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_old_level INTEGER;
    v_new_level INTEGER;
BEGIN
    v_old_level := get_level_from_xp(OLD.xp);
    v_new_level := get_level_from_xp(NEW.xp);

    -- Перевіряємо досягнення лише якщо рівень зріс
    IF v_new_level > v_old_level THEN
        IF v_new_level >= 5   THEN PERFORM grant_achievement(NEW.user_id, 'level_5');   END IF;
        IF v_new_level >= 15  THEN PERFORM grant_achievement(NEW.user_id, 'level_15');  END IF;
        IF v_new_level >= 30  THEN PERFORM grant_achievement(NEW.user_id, 'level_30');  END IF;
        IF v_new_level >= 50  THEN PERFORM grant_achievement(NEW.user_id, 'level_50');  END IF;
        IF v_new_level >= 75  THEN PERFORM grant_achievement(NEW.user_id, 'level_75');  END IF;
        IF v_new_level >= 100 THEN PERFORM grant_achievement(NEW.user_id, 'level_100'); END IF;
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_level_achievements ON user_xp;
CREATE TRIGGER trg_level_achievements
    AFTER UPDATE OF xp ON user_xp
    FOR EACH ROW EXECUTE FUNCTION trg_check_level_achievements();

-- ============================================================
-- СПЕЦІАЛЬНА ФУНКЦІЯ: видати досягнення «Першовідкривач»
-- першим 100 зареєстрованим користувачам
-- Викликається автоматично при створенні профілю
-- ============================================================
CREATE OR REPLACE FUNCTION trg_check_early_bird()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_profile_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO v_profile_count FROM profiles;

    IF v_profile_count <= 100 THEN
        PERFORM grant_achievement(NEW.user_id, 'early_bird');
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_early_bird ON profiles;
CREATE TRIGGER trg_early_bird
    AFTER INSERT ON profiles
    FOR EACH ROW EXECUTE FUNCTION trg_check_early_bird();

-- ============================================================
-- ПЕРЕВІРОЧНІ ЗАПИТИ (розкоментуй після застосування)
-- ============================================================

-- Перевірити, що тригери створені:
-- SELECT trigger_name, event_object_table, event_manipulation
-- FROM information_schema.triggers
-- WHERE trigger_schema = 'public'
-- ORDER BY event_object_table;

-- Вручну нарахувати XP тестовому користувачу:
-- SELECT add_xp('YOUR-UUID-HERE', 1500);
-- SELECT * FROM user_ranks WHERE user_id = 'YOUR-UUID-HERE';

-- Вручну видати досягнення:
-- SELECT grant_achievement('YOUR-UUID-HERE', 'first_review');
-- SELECT * FROM user_achievements WHERE user_id = 'YOUR-UUID-HERE';
