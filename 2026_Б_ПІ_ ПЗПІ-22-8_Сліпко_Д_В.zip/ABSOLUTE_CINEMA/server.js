const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
require('dotenv').config();
const { initWebSocket, notifyMessageRead } = require('./server/websocket');

// Ініціалізація застосунку Express
const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

// Ініціалізація WebSocket сервера
initWebSocket(server);

// Ініціалізація клієнта Supabase
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY // Використовуємо Service Key для обходу RLS на бекенді
);

// Створюємо клієнт Supabase із сервісним ключем для адміністративних операцій
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

// Налаштування CORS для дозволу крос-доменних запитів
app.use(cors({
  origin: true, // Дозволяємо запити з будь-якого джерела (у продакшені варто обмежити)
  credentials: true, // Дозволяємо передачу кукі при крос-доменних запитах
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Парсинг тіла запиту та кукі
app.use(bodyParser.json());
app.use(cookieParser(process.env.COOKIE_SECRET));

// --- ДОДАЮ ПРОМІЖНИЙ MIDDLEWARE ДЛЯ ПРОПУСКУ WEBSOCKET ---
app.use((req, res, next) => {
  if (req.headers.upgrade && req.headers.upgrade.toLowerCase() === 'websocket') {
    return next();
  }
  next();
});

// Застосовуємо middleware автентифікації до всіх запитів
const authMiddleware = async (req, res, next) => {
  const accessToken = req.signedCookies.access_token;
  const refreshToken = req.signedCookies.refresh_token;
  
  if (!accessToken) {
    return next();
  }

  try {
    // Перевірка дійсності сесії
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error) {
      if (refreshToken) {
        // Спроба оновити токен, якщо є refresh_token
        const { data, error: refreshError } = await supabase.auth.refreshSession({
          refresh_token: refreshToken
        });
        
        if (refreshError || !data.session) {
          clearAuthCookies(res);
          return next();
        }
        
        // Оновлюємо кукі новими токенами
        setAuthCookies(res, data.session);
        req.user = data.user;
      } else {
        clearAuthCookies(res);
      }
    } else {
      req.user = user;
    }
  } catch (err) {
    console.error('Помилка автентифікації:', err);
    clearAuthCookies(res);
  }
  
  next();
};

// Функція для встановлення кукі автентифікації
const setAuthCookies = (res, session) => {
  const maxAge = parseInt(process.env.COOKIE_MAX_AGE) || 604800000; // 7 днів за замовчуванням

  // Встановлення access_token в кукі
  res.cookie('access_token', session.access_token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production', // у продакшені лише через HTTPS
    signed: true,
    maxAge: maxAge,
    sameSite: 'lax'
  });
  
  // Встановлення refresh_token в кукі
  if (session.refresh_token) {
    res.cookie('refresh_token', session.refresh_token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      signed: true,
      maxAge: maxAge,
      sameSite: 'lax'
    });
  }
};

// Функція для очищення кукі автентифікації
const clearAuthCookies = (res) => {
  res.clearCookie('access_token');
  res.clearCookie('refresh_token');
};

// Застосовуємо middleware автентифікації до всіх запитів
app.use(authMiddleware);

// Middleware для зберігання даних сесії
app.use((req, res, next) => {
  // Зберігаємо дані користувача в req.session
  if (req.user) {
    req.session = {
      user: {
        id: req.user.id,
        email: req.user.email
      }
    };
  }
  next();
});

// --- ПОЧАТОК БЛОКУ API-МАРШРУТІВ ---
// API для перевірки стану авторизації
app.get('/api/auth/status', (req, res) => {
  if (req.user) {
    return res.json({
      authenticated: true,
      user: {
        id: req.user.id,
        email: req.user.email
      }
    });
  } else {
    return res.json({
      authenticated: false
    });
  }
});

// API для отримання токена для WebSocket
app.get('/api/auth/token', (req, res) => {
  const accessToken = req.signedCookies.access_token;
  
  if (!accessToken) {
    return res.status(401).json({ error: 'Не авторизований' });
  }

  res.json({ token: accessToken });
});

// API для отримання даних профілю
app.get('/api/profile', async (req, res) => {
  try {
    // Перевірка наявності користувача
    if (!req.user) {
      console.log('Запит до /api/profile без авторизації - повертаю 401');
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    console.log('Запит даних профілю для користувача:', userId);

    // Отримуємо дані профілю з Supabase
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();
    
    if (error) {
      console.error('Помилка при отриманні профілю з БД:', error);

      // Якщо профіль не існує, створюємо його
      if (error.code === 'PGRST116') {
        console.log('Профіль не знайдено, створюю новий профіль для користувача:', userId);

        // Створюємо базовий профіль
        const { data: newProfile, error: createError } = await supabase
          .from('profiles')
          .insert([{
            user_id: userId,
            username: req.user.email.split('@')[0], // Базове ім'я з email
            created_at: new Date()
          }])
          .select()
          .single();

        if (createError) {
          console.error('Помилка при створенні нового профілю:', createError);
          return res.status(500).json({ error: 'Помилка при створенні профілю', details: createError.message });
        }

        // Використовуємо новий профіль
        data = newProfile;
      } else {
        return res.status(500).json({ error: 'Помилка при отриманні профілю', details: error.message });
      }
    }

    // Отримуємо статистику користувача
    const [reviews, favorites, comments] = await Promise.all([
      // Кількість рецензій
      supabase.from('reviews').select('id', { count: 'exact' }).eq('user_id', userId),
      // Кількість обраного
      supabase.from('favorites').select('media_id', { count: 'exact' }).eq('user_id', userId),
      // Кількість коментарів
      supabase.from('discussion_comments').select('id', { count: 'exact' }).eq('user_id', userId)
    ]);

    // Формуємо об'єкт з даними профілю та статистикою
    const profileData = {
      profile: data || null,
      stats: {
        reviews: reviews.count || 0,
        favorites: favorites.count || 0,
        comments: comments.count || 0
      }
    };

    console.log('Дані профілю успішно завантажено для користувача:', userId);
    res.json(profileData);
  } catch (error) {
    console.error('Помилка при отриманні даних профілю:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для оновлення профілю
app.put('/api/profile', async (req, res) => {
  try {
    // Перевірка наявності користувача
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const { username, bio, social_links } = req.body;

    // Перевірка унікальності імені користувача
    if (username) {
      const { data: existingUser, error: checkError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('username', username)
        .neq('user_id', userId)
        .single();
      
      if (existingUser) {
        return res.status(400).json({ error: 'Це ім\'я користувача вже зайняте' });
      }
    }

    // Оновлюємо профіль
    const updateData = {};
    if (username) updateData.username = username;
    if (bio !== undefined) updateData.bio = bio;
    if (social_links) updateData.social_links = social_links;
    
    const { data, error } = await supabase
      .from('profiles')
      .update(updateData)
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error('Помилка при оновленні профілю:', error);
      return res.status(500).json({ error: 'Помилка при оновленні профілю', details: error.message });
    }

    console.log('Профіль успішно оновлено для користувача:', userId);
    res.json({ profile: data });
  } catch (error) {
    console.error('Помилка при оновленні профілю:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для реєстрації
app.post('/api/auth/register', async (req, res) => {
  try {
    console.log('Розпочато спробу реєстрації...');
    const { username, email, password } = req.body;

    // Валідація вхідних даних
    if (!username || !email || !password) {
      console.log('Помилка: не всі поля заповнені');
      return res.status(400).json({ error: 'Усі поля обов\'язкові для заповнення' });
    }

    console.log(`Реєстрація користувача: ${username}, ${email.slice(0, 3)}***@${email.split('@')[1]}`);

    // Перевіряємо, чи існує користувач з таким username
    try {
      const { data: existingUser, error: usernameError } = await supabase
        .from('profiles')
        .select('username')
        .eq('username', username)
        .single();
      
      if (usernameError && usernameError.code !== 'PGRST116') {
        console.log('Помилка при перевірці існуючого username:', usernameError);
        return res.status(500).json({ error: 'Помилка при перевірці імені користувача', details: usernameError.message });
      }

      if (existingUser) {
        console.log('Користувач з таким ім\'ям вже існує');
        return res.status(400).json({ error: 'Користувач з таким ім\'ям вже існує' });
      }
    } catch (checkErr) {
      console.error('Помилка при перевірці існуючого користувача:', checkErr);
      return res.status(500).json({ error: 'Помилка сервера при перевірці існуючого користувача' });
    }

    // Реєстрація користувача через Supabase Auth
    let authData, authError;
    try {
      const authResult = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: username
          }
        }
      });
      
      authData = authResult.data;
      authError = authResult.error;
      
      if (authError) {
        console.log('Помилка при реєстрації в Auth:', authError);
        return res.status(400).json({ error: authError.message });
      }
    } catch (authErr) {
      console.error('Необроблена помилка при виклику Auth API:', authErr);
      return res.status(500).json({ error: 'Помилка сервера при зверненні до Auth API', details: authErr.message });
    }

    // Якщо успішно зареєстровано, додаємо запис у таблицю profiles
    if (authData.user) {
      console.log('Користувача створено в Auth, ID:', authData.user.id);
      
      try {
        const { error: profileError } = await supabase
          .from('profiles')
          .insert([
            { 
              user_id: authData.user.id, 
              username: username,
              created_at: new Date()
            }
          ]);
        
        if (profileError) {
          console.error('Помилка створення профілю:', profileError);

          // Можна додати видалення користувача auth, якщо не вдалося створити профіль
          // але для цього потрібен адміністративний доступ
          if (supabaseAdmin) {
            try {
              await supabaseAdmin.auth.admin.deleteUser(authData.user.id);
              console.log('Користувача видалено з Auth через помилку створення профілю');
            } catch (deleteErr) {
              console.error('Не вдалося видалити користувача після помилки:', deleteErr);
            }
          }

          return res.status(500).json({ error: 'Помилка при створенні профілю', details: profileError.message });
        }
      } catch (profileErr) {
        console.error('Необроблена помилка при створенні профілю:', profileErr);
        return res.status(500).json({ error: 'Помилка сервера при створенні профілю', details: profileErr.message });
      }

      // Встановлюємо кукі сесії, якщо є
      if (authData.session) {
        console.log('Встановлюємо кукі сесії для нового користувача');
        setAuthCookies(res, authData.session);
      } else {
        console.log('Немає сесії для нового користувача (можливо, потрібне підтвердження email)');
      }

      console.log('Реєстрація успішно завершена');
      return res.status(201).json({
        success: true,
        message: 'Реєстрація успішна',
        user: {
          id: authData.user.id,
          email: authData.user.email
        }
      });
    } else {
      console.log('Немає даних користувача після реєстрації');
      return res.status(400).json({
        error: 'Реєстрація не завершена, перевірте email для підтвердження'
      });
    }
  } catch (err) {
    console.error('Необроблена помилка реєстрації:', err);
    return res.status(500).json({
      error: 'Помилка сервера при реєстрації',
      details: err.message
    });
  }
});

// API для авторизації
app.post('/api/auth/login', async (req, res) => {
  try {
    const { emailOrUsername, password, remember } = req.body;

    if (!emailOrUsername || !password) {
      return res.status(400).json({ error: 'Необхідно вказати email/ім\'я користувача та пароль' });
    }

    let email = emailOrUsername;

    // Якщо користувач ввів ім'я користувача, знайти відповідний email
    if (!emailOrUsername.includes('@')) {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('username', emailOrUsername)
        .single();

      if (profileError || !profileData) {
        return res.status(400).json({ error: 'Користувача не знайдено' });
      }

      // Отримуємо email за user_id, використовуючи адміністративний доступ
      const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(
        profileData.user_id
      );

      if (userError || !userData) {
        return res.status(400).json({ error: 'Користувача не знайдено' });
      }

      email = userData.user.email;
    }

    // Авторизація через Supabase
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      return res.status(401).json({ error: 'Невірні облікові дані' });
    }

    // Встановлення кукі
    setAuthCookies(res, data.session);
    
    return res.json({ 
      success: true, 
      user: {
        id: data.user.id,
        email: data.user.email
      }
    });
  } catch (err) {
    console.error('Помилка входу:', err);
    return res.status(500).json({ error: 'Помилка сервера при вході' });
  }
});

// API для виходу
app.post('/api/auth/logout', async (req, res) => {
  try {
    // Вихід із Supabase Auth
    const { error } = await supabase.auth.signOut();

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    // Очищення кукі
    clearAuthCookies(res);

    return res.json({ success: true });
  } catch (err) {
    console.error('Помилка виходу:', err);
    return res.status(500).json({ error: 'Помилка сервера при виході' });
  }
});

// API для відновлення пароля
app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email обов\'язковий' });
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${req.protocol}://${req.get('host')}/reset-password`,
    });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    return res.json({
      success: true,
      message: 'Інструкції щодо скидання пароля надіслано на вказаний email'
    });
  } catch (err) {
    console.error('Помилка скидання пароля:', err);
    return res.status(500).json({ error: 'Помилка сервера при скиданні пароля' });
  }
});

// API для оновлення аватара
app.put('/api/profile/avatar', async (req, res) => {
  try {
    // Перевірка наявності користувача
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const { avatar_url } = req.body;

    if (!avatar_url) {
      return res.status(400).json({ error: 'URL аватара не вказано' });
    }

    // Оновлюємо аватар
    const { data, error } = await supabase
      .from('profiles')
      .update({ avatar_url })
      .eq('user_id', userId)
      .select()
      .single();
    
    if (error) {
      console.error('Помилка при оновленні аватара:', error);
      return res.status(500).json({ error: 'Помилка при оновленні аватара', details: error.message });
    }

    res.json({ profile: data });
  } catch (error) {
    console.error('Помилка при оновленні аватара:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// ============================================================
// API: РАНГ КОРИСТУВАЧА
// ============================================================
app.get('/api/profile/rank/:userId', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { userId } = req.params;

    const { data, error } = await supabaseAdmin
      .from('user_ranks')
      .select('user_id, xp, level, xp_for_next_level, rank_title, rank_icon, rank_color')
      .eq('user_id', userId)
      .single();

    if (error) {
      console.error('Помилка при отриманні рангу:', error);
      return res.status(500).json({ error: 'Помилка при отриманні рангу', details: error.message });
    }

    res.json({ rank: data || null });
  } catch (err) {
    console.error('Помилка /api/profile/rank:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// ============================================================
// API: ВСІ ДОСЯГНЕННЯ (каталог)
// ============================================================
app.get('/api/achievements/all', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { data, error } = await supabaseAdmin
      .from('achievements')
      .select('id, code, title, description, icon, xp_reward, category, is_hidden')
      .order('category')
      .order('id');

    if (error) {
      return res.status(500).json({ error: 'Помилка при отриманні досягнень', details: error.message });
    }

    res.json({ achievements: data || [] });
  } catch (err) {
    console.error('Помилка /api/achievements/all:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// ============================================================
// API: ДОСЯГНЕННЯ КОРИСТУВАЧА
// ============================================================
app.get('/api/achievements/user/:userId', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { userId } = req.params;

    const { data, error } = await supabaseAdmin
      .from('user_achievements')
      .select('id, achievement_id, earned_at')
      .eq('user_id', userId)
      .order('earned_at', { ascending: false });

    if (error) {
      return res.status(500).json({ error: 'Помилка при отриманні досягнень користувача', details: error.message });
    }

    res.json({ achievements: data || [] });
  } catch (err) {
    console.error('Помилка /api/achievements/user:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// ============================================================
// API: НОВІ ДОСЯГНЕННЯ (для polling тостів)
// ============================================================
app.get('/api/achievements/recent/:userId', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { userId } = req.params;
    const { since } = req.query;

    if (!since) {
      return res.status(400).json({ error: 'Параметр since обов\'язковий' });
    }

    // Використовуємо supabaseAdmin, щоб ігнорувати RLS за потреби
    const { data, error } = await supabaseAdmin
      .from('user_achievements')
      .select('id, achievement_id, earned_at, achievements(title, description, icon, xp_reward)')
      .eq('user_id', userId)
      .gt('earned_at', since)
      .order('earned_at', { ascending: true });

    if (error) {
      return res.status(500).json({ error: 'Помилка отримання нових досягнень', details: error.message });
    }

    res.json({ achievements: data || [] });
  } catch (err) {
    console.error('Помилка /api/achievements/recent:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// ============================================================
// API: ЗАПИС ЩОДЕННОГО ВХОДУ (STREAK)
// ============================================================
app.post('/api/profile/record-login', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { data, error } = await supabaseAdmin.rpc('record_daily_login', {
      p_user_id: req.user.id
    });

    if (error) {
      return res.status(500).json({ error: 'Помилка запису входу', details: error.message });
    }

    res.json(data);
  } catch (err) {
    console.error('Помилка /api/profile/record-login:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// API для отримання рецензій користувача
app.get('/api/reviews/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    // Перевірка авторизації - будь-який авторизований користувач може переглядати рецензії будь-якого користувача
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }
    console.log(`Запит рецензій користувача ${userId}`);
    // Отримуємо рецензії з Supabase
    const { data, error } = await supabase
      .from('reviews')
      .select(`
        id,
        content,
        rating,
        created_at,
        updated_at,
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date,
          imdb_rating
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) {
      console.error('Помилка при отриманні рецензій:', error);
      return res.status(500).json({ error: 'Помилка при отриманні рецензій' });
    }
    // Повертаємо список рецензій
    res.json({ reviews: data || [] });
  } catch (error) {
    console.error('Помилка при отриманні рецензій користувача:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для отримання обраного користувача
app.get('/api/favorites/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;

    // Перевірка авторизації - користувач може отримувати лише своє обране
    // або адмін може отримувати будь-яке обране
    if (!req.user || (req.user.id !== userId && !req.user.is_admin)) {
      return res.status(403).json({ error: 'Доступ заборонено' });
    }

    console.log(`Запит обраного користувача ${userId}`);

    // Отримуємо обране з Supabase
    const { data, error } = await supabase
      .from('favorites')
      .select(`
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date,
          imdb_rating
        )
      `)
      .eq('user_id', userId);
      
    if (error) {
      console.error('Помилка при отриманні обраного:', error);
      return res.status(500).json({ error: 'Помилка при отриманні обраного' });
    }

    // Повертаємо список обраного
    res.json({ favorites: data || [] });
  } catch (error) {
    console.error('Помилка при отриманні обраного користувача:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для видалення з обраного
app.delete('/api/favorites/:mediaId', async (req, res) => {
  try {
    const mediaId = parseInt(req.params.mediaId, 10);

    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    if (isNaN(mediaId)) {
      return res.status(400).json({ error: 'Некоректний ID фільму' });
    }

    // Видаляємо за user_id + media_id (власник визначається токеном)
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('user_id', req.user.id)
      .eq('media_id', mediaId);

    if (error) {
      console.error('Помилка при видаленні з обраного:', error);
      return res.status(500).json({ error: 'Помилка при видаленні з обраного' });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Помилка при видаленні з обраного:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для отримання історії перегляду користувача
app.get('/api/history/user/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;

    // Перевірка авторизації - користувач може отримувати лише свою історію
    // або адмін може отримувати будь-яку історію
    if (!req.user || (req.user.id !== userId && !req.user.is_admin)) {
      return res.status(403).json({ error: 'Доступ заборонено' });
    }

    console.log(`Запит історії перегляду користувача ${userId}`);

    // Отримуємо історію перегляду з Supabase
    const { data, error } = await supabase
      .from('viewing_history')
      .select(`
        id,
        viewed_at,
        media_id,
        media:media_id (
          id,
          title,
          poster_url,
          release_date
        )
      `)
      .eq('user_id', userId)
      .order('viewed_at', { ascending: false })
      .limit(100); // Обмежуємо кількість записів

    if (error) {
      console.error('Помилка при отриманні історії перегляду:', error);
      return res.status(500).json({ error: 'Помилка при отриманні історії перегляду' });
    }

    // Повертаємо історію перегляду
    res.json({ history: data || [] });
  } catch (error) {
    console.error('Помилка при отриманні історії перегляду користувача:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для отримання новинок
app.get('/api/latest-movies', async (req, res) => {
  try {
    // limit задається параметром запиту (використовується і банером-каруселлю,
    // і блоком "Новинки"), за замовчуванням 10, максимум 20.
    const requestedLimit = parseInt(req.query.limit, 10);
    const limit = Number.isFinite(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 20) : 10;

    // Отримуємо останні фільми з бази даних
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating
      `)
      .eq('type', 'movie')
      .order('release_date', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('Помилка при отриманні новинок:', error);
      console.error('Деталі помилки:', error);
      return res.status(500).json({ error: 'Помилка при отриманні новинок' });
    }

    // Підвантажуємо жанри для кожного фільму (потрібно каруселі банера і карткам "Новинки")
    const moviesWithGenres = await Promise.all((data || []).map(async (movie) => {
      try {
        const { data: genresData } = await supabase
          .from('media_genres')
          .select('genres:genre_id(name)')
          .eq('media_id', movie.id);
        const genres = genresData ? genresData.map(g => g.genres && g.genres.name).filter(Boolean) : [];
        return { ...movie, genres };
      } catch {
        return { ...movie, genres: [] };
      }
    }));

    // Повертаємо список новинок
    res.json({ movies: moviesWithGenres });
  } catch (error) {
    console.error('Помилка при отриманні новинок:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для отримання популярних фільмів за рейтингом IMDB
app.get('/api/popular-movies', async (req, res) => {
  try {
    // Отримуємо фільми з високим рейтингом IMDB
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating,
        description
      `)
      .eq('type', 'movie')
      .not('imdb_rating', 'is', null)
      .order('imdb_rating', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Помилка при отриманні популярних фільмів:', error);
      return res.status(500).json({ error: 'Помилка при отриманні популярних фільмів' });
    }

    // Для кожного фільму отримуємо його жанри та середню оцінку глядачів
    const moviesWithGenresAndRating = await Promise.all(data.map(async (movie) => {
      // Жанри
      let genres = [];
      try {
        const { data: genresData } = await supabase
          .from('media_genres')
          .select('genres:genre_id(name)')
          .eq('media_id', movie.id);
        genres = genresData ? genresData.map(g => g.genres.name) : [];
      } catch {}

      // Середня оцінка глядачів
      let average_rating = null;
      try {
        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('rating')
          .eq('media_id', movie.id);
        if (reviewsData && reviewsData.length > 0) {
          const sum = reviewsData.reduce((acc, r) => acc + (typeof r.rating === 'number' ? r.rating : 0), 0);
          average_rating = Math.round((sum / reviewsData.length) * 10) / 10;
        }
      } catch {}

      return { ...movie, genres: genres.join(', '), average_rating };
    }));

    // Повертаємо список популярних фільмів
    res.json({ movies: moviesWithGenresAndRating || [] });
  } catch (error) {
    console.error('Помилка при отриманні популярних фільмів:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для отримання детальної інформації про фільм
app.get('/api/movie/:id', async (req, res) => {
  const movieId = req.params.id;
  const { data, error } = await supabase
    .from('media')
    .select('*')
    .eq('id', movieId)
    .single();
  if (error || !data) {
    return res.status(404).json({ error: 'Фільм не знайдено' });
  }
  res.json(data);
});

// API для отримання жанрів фільму за його ID
app.get('/api/movie/:id/genres', async (req, res) => {
  const movieId = req.params.id;
  try {
    // Отримуємо жанри фільму з таблиці media_genres
    const { data, error } = await supabase
      .from('media_genres')
      .select(`
        genres:genre_id(name)
      `)
      .eq('media_id', movieId);

    if (error) {
      console.error(`Помилка при отриманні жанрів для фільму ${movieId}:`, error);
      return res.status(500).json({ error: 'Помилка при отриманні жанрів фільму' });
    }

    // Витягуємо назви жанрів з даних
    const genres = data.map(g => g.genres.name);

    // Повертаємо масив жанрів
    res.json({ genres });
  } catch (error) {
    console.error(`Необроблена помилка при отриманні жанрів для фільму ${movieId}:`, error);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// API для отримання акторів фільму за його ID
app.get('/api/movie/:id/cast', async (req, res) => {
  const movieId = req.params.id;
  try {
    const { data, error } = await supabase
      .from('media_people')
      .select(`
        person:person_id(full_name, photo_url),
        character_name
      `)
      .eq('media_id', movieId)
      .eq('role', 'actor');
    if (error) {
      return res.status(500).json({ error: 'Помилка при отриманні акторів' });
    }
    const cast = data.map(item => ({
      full_name: item.person.full_name,
      photo_url: item.person.photo_url,
      character_name: item.character_name
    }));
    res.json({ cast });
  } catch (err) {
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// Додаю endpoint для отримання рецензій фільму за його ID
app.get('/api/movie/:id/reviews', async (req, res) => {
  const movieId = req.params.id;
  const userId = req.user?.id;
  try {
    const { data, error } = await supabase
      .from('reviews')
      .select('id, content, rating, created_at, user_id, profiles: user_id (username)')
      .eq('media_id', Number(movieId))
      .order('created_at', { ascending: false });
    if (error) {
      console.error(`Помилка при отриманні рецензій для фільму ${movieId}:`, error);
      return res.status(500).json({ error: 'Помилка при отриманні рецензій фільму' });
    }
    const reviews = (data || []).map(r => ({
      ...r,
      username: Array.isArray(r.profiles) ? (r.profiles[0]?.username || 'Анонім') : (r.profiles?.username || 'Анонім')
    }));

    // Отримуємо id усіх рецензій
    const reviewIds = reviews.map(r => r.id);
    let likes = [];
    let userLikes = [];
    if (reviewIds.length > 0) {
      // Рахуємо лайки для кожної рецензії
      const { data: likesData } = await supabase
        .from('review_likes')
        .select('review_id')
        .in('review_id', reviewIds);
      likes = likesData || [];
      // Перевіряємо лайки поточного користувача
      if (userId) {
        const { data: userLikesData } = await supabase
          .from('review_likes')
          .select('review_id')
          .eq('user_id', userId)
          .in('review_id', reviewIds);
        userLikes = userLikesData ? userLikesData.map(l => l.review_id) : [];
      }
    }
    // Формуємо підсумковий масив
    const reviewsWithLikes = reviews.map(r => ({
      ...r,
      likes_count: likes.filter(l => l.review_id === r.id).length,
      is_liked: userLikes.includes(r.id)
    }));

    // Рахуємо середній рейтинг
    let average_rating = null;
    if (reviews.length > 0) {
      const sum = reviews.reduce((acc, r) => acc + (typeof r.rating === 'number' ? r.rating : 0), 0);
      average_rating = Math.round((sum / reviews.length) * 10) / 10; // округлюємо до 1 знака
    }

    res.json({ reviews: reviewsWithLikes, average_rating });
  } catch (err) {
    console.error(`Необроблена помилка при отриманні рецензій для фільму ${movieId}:`, err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// API для додавання фільму в обране
app.post('/api/favorites', async (req, res) => {
  console.log('Отримано запит на додавання в обране:', req.body);
  try {
    if (!req.user) {
      console.log('Помилка: користувач не авторизований');
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }
    const userId = req.user.id;
    console.log('ID користувача:', userId);

    let { movieId } = req.body;
    if (!movieId) {
      console.log('Помилка: не вказано ID фільму');
      return res.status(400).json({ error: 'Не вказано ID фільму' });
    }

    // Перетворюємо movieId на число, якщо він прийшов як рядок
    movieId = parseInt(movieId, 10);
    if (isNaN(movieId)) {
      console.log('Помилка: некоректний ID фільму:', req.body.movieId);
      return res.status(400).json({ error: 'Некоректний ID фільму' });
    }

    console.log('ID фільму для додавання в обране:', movieId);

    // Перевіряємо існування фільму в БД
    const { data: movie, error: movieError } = await supabase
      .from('media')
      .select('id')
      .eq('id', movieId)
      .single();

    if (movieError || !movie) {
      console.log('Помилка: фільм із вказаним ID не знайдено:', movieId);
      return res.status(404).json({ error: 'Фільм із вказаним ID не знайдено' });
    }

    // Перевіряємо, чи не додано вже цей фільм в обране
    const { data: existing, error: checkError } = await supabase
      .from('favorites')
      .select('*')
      .eq('user_id', userId)
      .eq('media_id', movieId)
      .single();

    if (checkError && checkError.code !== 'PGRST116') {
      console.error('Помилка при перевірці наявності фільму в обраному:', checkError);
      return res.status(500).json({ error: 'Помилка при перевірці наявності фільму в обраному' });
    }

    if (existing) {
      console.log('Фільм вже в обраному');
      return res.status(409).json({ error: 'Фільм вже в обраному' });
    }

    // Додаємо в обране
    console.log('Додаємо фільм в обране...');
    const { error } = await supabase
      .from('favorites')
      .insert([{ user_id: userId, media_id: movieId }]);

    if (error) {
      console.error('Помилка при додаванні в обране:', error);
      return res.status(500).json({ error: 'Помилка при додаванні в обране', details: error.message });
    }

    console.log('Фільм успішно додано в обране');
    res.json({ success: true, media_id: movieId });
  } catch (error) {
    console.error('Необроблена помилка при додаванні в обране:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// API для фільмів з високим рейтингом
app.get('/api/high-rated-movies', async (req, res) => {
  try {
    console.log('Запит фільмів з високим рейтингом');

    // Отримуємо фільми з рейтингом 8 або вище
    const { data, error } = await supabase
      .from('media')
      .select('id, title, poster_url, imdb_rating, description, release_date, type')
      .eq('type', 'movie')
      .order('imdb_rating', { ascending: false })  // Сортування за спаданням рейтингу
      .limit(20);             // Обмежуємо кількість результатів

    if (error) {
      console.error('Помилка при отриманні фільмів з високим рейтингом:', error);
      return res.status(500).json({ error: 'Помилка сервера при отриманні фільмів' });
    }

    console.log(`Отримано ${data ? data.length : 0} фільмів з бази даних`);

    if (!data || data.length === 0) {
      console.log('Фільми не знайдено в базі даних');
      return res.status(404).json({ error: 'Фільми не знайдено' });
    }

    // Відфільтруємо, щоб гарантувати наявність усіх необхідних полів
    const validMovies = data.filter(movie => movie.id && movie.title && movie.poster_url);

    if (validMovies.length === 0) {
      console.log('Немає фільмів з повними даними');
      return res.status(404).json({ error: 'Немає фільмів з повними даними' });
    }

    // Для кожного фільму отримуємо його жанри
    const moviesWithGenres = await Promise.all(validMovies.map(async (movie) => {
      try {
        const { data: genresData, error: genresError } = await supabase
          .from('media_genres')
          .select(`
            genres:genre_id(name)
          `)
          .eq('media_id', movie.id);

        if (genresError || !genresData) {
          console.error(`Помилка при отриманні жанрів для фільму ${movie.id}:`, genresError);
          return { ...movie, genres: [] };
        }

        const genres = genresData.map(g => {
          return g.genres && g.genres.name ? g.genres.name : null;
        }).filter(Boolean);

        // Перевіряємо наявність усіх необхідних даних і встановлюємо значення за замовчуванням за потреби
        if (!movie.description || movie.description.trim() === '') {
          movie.description = 'Опис відсутній';
        }

        if (!movie.imdb_rating) {
          movie.imdb_rating = '?';
        }

        return { ...movie, genres };
      } catch (error) {
        console.error(`Помилка при обробці фільму ${movie.id}:`, error);
        return { ...movie, genres: [] };
      }
    }));

    // Перемішуємо фільми для більшої випадковості (для блоку випадкового фільму)
    // Використовуємо алгоритм Fisher-Yates для перемішування
    for (let i = moviesWithGenres.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [moviesWithGenres[i], moviesWithGenres[j]] = [moviesWithGenres[j], moviesWithGenres[i]];
    }

    // Повертаємо список фільмів із жанрами
    res.json({ movies: moviesWithGenres || [] });
  } catch (error) {
    console.error('Необроблена помилка при отриманні фільмів з високим рейтингом:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', message: error.message });
  }
});

// API для випадкового фільму
app.get('/api/random-movie', async (req, res) => {
  try {
    console.log('Запит випадкового фільму');

    // Запитуємо всі фільми без обмеження за рейтингом
    const { data, error } = await supabase
      .from('media')
      .select('id, title, poster_url, imdb_rating, description, release_date, type')
      .eq('type', 'movie')
      .limit(100); // Обмежуємо вибірку для продуктивності

    if (error) {
      console.error('Помилка при отриманні фільмів:', error);
      return res.status(500).json({ error: 'Помилка сервера при отриманні випадкового фільму' });
    }

    console.log(`Отримано ${data ? data.length : 0} фільмів з бази даних`);

    if (!data || data.length === 0) {
      console.log('Фільми не знайдено в базі даних');
      return res.status(404).json({ error: 'Фільми не знайдено' });
    }

    // Відфільтруємо, щоб гарантувати наявність усіх необхідних полів
    const validMovies = data.filter(movie => movie.id && movie.title && movie.poster_url);

    if (validMovies.length === 0) {
      console.log('Немає фільмів з повними даними');
      return res.status(404).json({ error: 'Немає фільмів з повними даними' });
    }

    // Обираємо випадковий фільм з масиву
    const randomIndex = Math.floor(Math.random() * validMovies.length);
    const randomMovie = validMovies[randomIndex];

    console.log('Обрано випадковий фільм:', randomMovie.title, 'ID:', randomMovie.id);

    // Отримуємо жанри для випадкового фільму
    try {
      const { data: genresData, error: genresError } = await supabase
        .from('media_genres')
        .select(`
          genres:genre_id(name)
        `)
        .eq('media_id', randomMovie.id);

      if (!genresError && genresData && genresData.length > 0) {
        console.log(`Отримано ${genresData.length} жанрів для фільму`);
        const genres = genresData.map(g => g.genres && g.genres.name ? g.genres.name : null).filter(Boolean);
        randomMovie.genres = genres;
      } else {
        console.log('Жанри не знайдено, використовуємо значення за замовчуванням');
        randomMovie.genres = [];
      }
    } catch (genresErr) {
      console.error('Помилка при отриманні жанрів для випадкового фільму:', genresErr);
      randomMovie.genres = [];
    }

    // Перевіряємо наявність усіх необхідних даних і встановлюємо значення за замовчуванням за потреби
    if (!randomMovie.description || randomMovie.description.trim() === '') {
      randomMovie.description = 'Опис відсутній';
    }

    if (!randomMovie.imdb_rating) {
      randomMovie.imdb_rating = '?';
    }

    // Налагоджувальне повідомлення перед надсиланням
    console.log('Надсилаємо випадковий фільм у відповіді:', JSON.stringify(randomMovie, null, 2));

    // Повертаємо випадковий фільм
    res.json(randomMovie);
  } catch (error) {
    console.error('Необроблена помилка при отриманні випадкового фільму:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', message: error.message });
  }
});

// API для роботи з чатами
app.get('/api/chats', async (req, res) => {
  try {
    // Перевірка авторизації
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;

    // Отримуємо список чатів користувача
    const { data: chatsData, error: chatsError } = await supabase
      .from('chats')
      .select(`
        id,
        user1_id,
        user2_id,
        created_at,
        user1:user1_id(user_id, username, avatar_url),
        user2:user2_id(user_id, username, avatar_url)
      `)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .order('created_at', { ascending: false });

    if (chatsError) {
      console.error('Помилка при отриманні чатів:', chatsError);
      return res.status(500).json({ error: 'Помилка при отриманні чатів', details: chatsError.message });
    }

    // Отримуємо останні повідомлення та кількість непрочитаних для кожного чату
    const chatsWithDetails = await Promise.all(chatsData.map(async (chat) => {
      // Отримуємо останнє повідомлення
      const { data: lastMessageData, error: lastMessageError } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('chat_id', chat.id)
        .order('sent_at', { ascending: false })
        .limit(1)
        .single();

      // Отримуємо кількість непрочитаних повідомлень
      const { count: unreadCount, error: unreadError } = await supabase
        .from('chat_messages')
        .select('*', { count: 'exact' })
        .eq('chat_id', chat.id)
        .eq('is_read', false)
        .neq('sender_id', userId);

      return {
        ...chat,
        last_message: lastMessageData || null,
        unread_count: unreadCount || 0
      };
    }));

    res.json({ chats: chatsWithDetails });
  } catch (error) {
    console.error('Помилка при отриманні чатів:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.post('/api/chats', async (req, res) => {
  try {
    console.log('Запит на створення нового чату');

    // Перевірка авторизації
    if (!req.user) {
      console.log('Відмова: користувач не авторизований');
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const { user_id: otherUserId } = req.body;

    console.log(`Створення чату між користувачами ${userId} та ${otherUserId}`);

    if (!otherUserId) {
      console.log('Відмова: не вказано ID співрозмовника');
      return res.status(400).json({ error: 'Необхідно вказати ID співрозмовника' });
    }

    if (userId === otherUserId) {
      console.log('Відмова: спроба створити чат із самим собою');
      return res.status(400).json({ error: 'Не можна створити чат із самим собою' });
    }

    // Визначаємо user_min та user_max для унікального обмеження
    const userMin = userId < otherUserId ? userId : otherUserId;
    const userMax = userId < otherUserId ? otherUserId : userId;

    console.log(`Перевірка існуючого чату між ${userMin} та ${userMax}`);

    // Перевіряємо, чи існує вже чат між користувачами
    const { data: existingChat, error: existingChatError } = await supabase
      .from('chats')
      .select('id')
      .eq('user_min', userMin)
      .eq('user_max', userMax)
      .single();

    if (existingChatError && existingChatError.code !== 'PGRST116') {
      console.error('Помилка при перевірці існуючого чату:', existingChatError);
      return res.status(500).json({ error: 'Помилка при перевірці існуючого чату', details: existingChatError.message });
    }

    // Якщо чат вже існує, повертаємо його
    if (existingChat) {
      console.log(`Чат вже існує, ID: ${existingChat.id}`);
      return res.json({ chat: existingChat });
    }

    console.log('Створення нового чату в базі даних');

    // Створюємо новий чат
    const { data: newChat, error: newChatError } = await supabase
      .from('chats')
      .insert([{
        user1_id: userId,
        user2_id: otherUserId,
        user_min: userMin,
        user_max: userMax,
        created_at: new Date()
      }])
      .select()
      .single();

    if (newChatError) {
      console.error('Помилка при створенні чату:', newChatError);
      return res.status(500).json({ error: 'Помилка при створенні чату', details: newChatError.message });
    }

    console.log(`Новий чат успішно створено, ID: ${newChat.id}`);
    res.status(201).json({ chat: newChat });
  } catch (error) {
    console.error('Помилка при створенні чату:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.get('/api/chats/:chatId/messages', async (req, res) => {
  try {
    // Перевірка авторизації
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const chatId = req.params.chatId;

    // Перевіряємо, чи має користувач доступ до чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не знайдено або доступ заборонено' });
    }

    // Отримуємо повідомлення чату
    const { data: messages, error: messagesError } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('chat_id', chatId)
      .order('sent_at', { ascending: true });

    if (messagesError) {
      console.error('Помилка при отриманні повідомлень:', messagesError);
      return res.status(500).json({ error: 'Помилка при отриманні повідомлень', details: messagesError.message });
    }

    // Збагачуємо повідомлення даними про відповідь (reply_to)
    const enriched = await Promise.all((messages || []).map(async msg => {
      if (msg.reply_to_id) {
        const { data: replyMsg } = await supabase
          .from('chat_messages')
          .select('id, content, sender_id')
          .eq('id', msg.reply_to_id)
          .single();
        if (replyMsg) {
          // Отримуємо username відправника оригіналу
          const { data: senderProfile } = await supabaseAdmin
            .from('profiles')
            .select('username')
            .eq('user_id', replyMsg.sender_id)
            .single();
          return { ...msg, reply_to: { ...replyMsg, sender_username: senderProfile?.username || 'Користувач' } };
        }
      }
      return msg;
    }));

    res.json({ messages: enriched });
  } catch (error) {
    console.error('Помилка при отриманні повідомлень:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.post('/api/chats/:chatId/messages', async (req, res) => {
  try {
    const chatId = req.params.chatId;
    console.log(`Запит на надсилання повідомлення в чат ${chatId}`);

    // Перевірка авторизації
    if (!req.user) {
      console.log('Відмова: користувач не авторизований');
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const { content, reply_to_id } = req.body;

    console.log(`Надсилання повідомлення від користувача ${userId} в чат ${chatId}`);
    console.log('Зміст повідомлення:', content);

    if (!content || !content.trim()) {
      console.log('Відмова: порожнє повідомлення');
      return res.status(400).json({ error: 'Повідомлення не може бути порожнім' });
    }

    console.log(`Перевірка доступу користувача ${userId} до чату ${chatId}`);

    // Перевіряємо, чи має користувач доступ до чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError) {
      console.error(`Помилка при перевірці доступу до чату ${chatId}:`, chatError);
    }

    if (chatError || !chat) {
      console.log(`Відмова: чат ${chatId} не знайдено або доступ заборонено`);
      return res.status(404).json({ error: 'Чат не знайдено або доступ заборонено' });
    }

    console.log(`Вставка повідомлення в базу даних (chat_id: ${chatId}, sender_id: ${userId})`);

    // Формуємо об'єкт для вставки
    const insertObj = {
      chat_id: chatId,
      sender_id: userId,
      content,
      is_read: false,
      sent_at: new Date()
    };
    if (reply_to_id) insertObj.reply_to_id = parseInt(reply_to_id);

    // Створюємо нове повідомлення
    const { data: newMessage, error: newMessageError } = await supabase
      .from('chat_messages')
      .insert([insertObj])
      .select()
      .single();

    if (newMessageError) {
      console.error('Помилка при надсиланні повідомлення:', newMessageError);
      return res.status(500).json({ error: 'Помилка при надсиланні повідомлення', details: newMessageError.message });
    }

    // Якщо є reply — збагачуємо відповідь
    let replyData = null;
    if (reply_to_id) {
      const { data: replyMsg } = await supabase
        .from('chat_messages')
        .select('id, content, sender_id')
        .eq('id', parseInt(reply_to_id))
        .single();
      if (replyMsg) {
        const { data: senderProfile } = await supabaseAdmin
          .from('profiles')
          .select('username')
          .eq('user_id', replyMsg.sender_id)
          .single();
        replyData = { ...replyMsg, sender_username: senderProfile?.username || 'Користувач' };
      }
    }

    console.log(`Повідомлення успішно надіслано, ID: ${newMessage.id}`);
    res.status(201).json({ message: { ...newMessage, reply_to: replyData } });
  } catch (error) {
    console.error('Помилка при надсиланні повідомлення:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.post('/api/chats/:chatId/read', authMiddleware, async (req, res) => {
  try {
    const chatId = req.params.chatId;
    console.log(`Запит на прочитання повідомлень у чаті ${chatId}`);

    // Перевірка авторизації
    if (!req.user) {
      console.log('Відмова: користувач не авторизований');
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    console.log(`Користувач ${userId} читає чат ${chatId}`);

    // Перевіряємо, чи має користувач доступ до чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не знайдено або доступ заборонено' });
    }

    // Позначаємо повідомлення як прочитані
    const { error: updateError } = await supabase
      .from('chat_messages')
      .update({ is_read: true })
      .eq('chat_id', parseInt(chatId))
      .eq('is_read', false)
      .neq('sender_id', userId);

    if (updateError) {
      console.error('Помилка при позначенні повідомлень як прочитаних:', updateError);
      return res.status(500).json({ error: 'Помилка при позначенні повідомлень як прочитаних', details: updateError.message });
    }

    const otherUserId = chat.user1_id === userId ? chat.user2_id : chat.user1_id;
    if (typeof notifyMessageRead === 'function') notifyMessageRead(otherUserId, chatId);

    res.json({ success: true });
  } catch (error) {
    console.error('Помилка при позначенні повідомлень як прочитаних:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.delete('/api/chats/:chatId', authMiddleware, async (req, res) => {
  try {
    // Перевірка авторизації
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.user.id;
    const chatId = req.params.chatId;

    // Перевіряємо, чи має користувач доступ до чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chatId)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не знайдено або доступ заборонено' });
    }

    // Видаляємо повідомлення чату
    const { error: messagesDeleteError } = await supabase
      .from('chat_messages')
      .delete()
      .eq('chat_id', chatId);

    if (messagesDeleteError) {
      console.error('Помилка при видаленні повідомлень чату:', messagesDeleteError);
      return res.status(500).json({ error: 'Помилка при видаленні повідомлень чату', details: messagesDeleteError.message });
    }

    // Видаляємо сам чат
    const { error: chatDeleteError } = await supabase
      .from('chats')
      .delete()
      .eq('id', chatId);

    if (chatDeleteError) {
      console.error('Помилка при видаленні чату:', chatDeleteError);
      return res.status(500).json({ error: 'Помилка при видаленні чату', details: chatDeleteError.message });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Помилка при видаленні чату:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// ============================================================
// API: ГРУПОВІ ЧАТИ
// ============================================================

// Отримати всі групові чати поточного юзера
app.get('/api/group-chats', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;

    // Знаходимо всі групи де є цей юзер (з last_read_at для лічильника непрочитаних)
    const { data: memberRows, error: memberError } = await supabaseAdmin
      .from('group_chat_members')
      .select('group_id, role, last_read_at')
      .eq('user_id', userId);

    if (memberError) return res.status(500).json({ error: memberError.message });
    if (!memberRows || memberRows.length === 0) return res.json({ groups: [] });

    const groupIds = memberRows.map(r => r.group_id);
    const myRoles = Object.fromEntries(memberRows.map(r => [r.group_id, r.role]));

    // Отримуємо дані груп
    const { data: groups, error: groupsError } = await supabaseAdmin
      .from('group_chats')
      .select('*')
      .in('id', groupIds);

    if (groupsError) return res.status(500).json({ error: groupsError.message });

    // Збагачуємо: останнє повідомлення, к-сть учасників, моя роль, кількість непрочитаних
    const enriched = await Promise.all((groups || []).map(async g => {
      // Отримуємо my last_read_at
      const myMemberRow = memberRows.find(r => r.group_id === g.id);
      const lastReadAt = myMemberRow?.last_read_at || null;

      const [lastMsgRes, membersCountRes, unreadRes] = await Promise.all([
        supabaseAdmin.from('group_chat_messages').select('*').eq('group_id', g.id)
          .order('sent_at', { ascending: false }).limit(1).single(),
        supabaseAdmin.from('group_chat_members').select('*', { count: 'exact', head: true }).eq('group_id', g.id),
        // Непрочитані: повідомлення після last_read_at, не від мене
        lastReadAt
          ? supabaseAdmin.from('group_chat_messages').select('*', { count: 'exact', head: true })
              .eq('group_id', g.id).neq('sender_id', userId).gt('sent_at', lastReadAt)
          : supabaseAdmin.from('group_chat_messages').select('*', { count: 'exact', head: true })
              .eq('group_id', g.id).neq('sender_id', userId)
      ]);
      return {
        ...g,
        my_role: myRoles[g.id] || 'member',
        last_message: lastMsgRes.data || null,
        members_count: membersCountRes.count || 0,
        unread_count: unreadRes.count || 0
      };
    }));

    res.json({ groups: enriched });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Позначити повідомлення групового чату як прочитані
app.post('/api/group-chats/:groupId/read', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);

    await supabaseAdmin
      .from('group_chat_members')
      .update({ last_read_at: new Date().toISOString() })
      .eq('group_id', groupId)
      .eq('user_id', userId);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Створити груповий чат
app.post('/api/group-chats', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const { name, member_ids } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ error: 'Назва групи обов\'язкова' });

    // Створюємо групу
    const { data: group, error: groupError } = await supabaseAdmin
      .from('group_chats')
      .insert([{ name: name.trim(), owner_id: userId }])
      .select().single();

    if (groupError) return res.status(500).json({ error: groupError.message });

    // Додаємо власника як owner
    const membersToInsert = [{ group_id: group.id, user_id: userId, role: 'owner' }];
    // Додаємо інших учасників
    if (Array.isArray(member_ids)) {
      member_ids.forEach(uid => {
        if (uid !== userId) {
          membersToInsert.push({ group_id: group.id, user_id: uid, role: 'member' });
        }
      });
    }

    const { error: membersError } = await supabaseAdmin
      .from('group_chat_members')
      .insert(membersToInsert);

    if (membersError) return res.status(500).json({ error: membersError.message });

    res.status(201).json({ group });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Отримати учасників групового чату
app.get('/api/group-chats/:groupId/members', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);

    // Перевірка доступу
    const { data: myMembership } = await supabaseAdmin
      .from('group_chat_members')
      .select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!myMembership) return res.status(403).json({ error: 'Ви не є учасником цієї групи' });

    const { data: members, error } = await supabaseAdmin
      .from('group_chat_members')
      .select('user_id, role, joined_at, last_read_at')
      .eq('group_id', groupId);

    if (error) return res.status(500).json({ error: error.message });

    // Збагачуємо профілями
    const enriched = await Promise.all((members || []).map(async m => {
      const { data: profile } = await supabaseAdmin
        .from('profiles').select('username, avatar_url').eq('user_id', m.user_id).single();
      return { ...m, profile: profile || { username: 'Користувач', avatar_url: null } };
    }));

    res.json({ members: enriched, my_role: myMembership.role });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Додати учасника до групи
app.post('/api/group-chats/:groupId/members', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const { user_id: newUserId } = req.body;

    if (!newUserId) return res.status(400).json({ error: 'user_id обов\'язковий' });

    // Перевірка що я власник або адмін
    const { data: myRole } = await supabaseAdmin
      .from('group_chat_members')
      .select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!myRole || !['owner', 'admin'].includes(myRole.role)) {
      return res.status(403).json({ error: 'Недостатньо прав для додавання учасників' });
    }

    // Перевірка що юзер ще не в групі
    const { data: existing } = await supabaseAdmin
      .from('group_chat_members')
      .select('id').eq('group_id', groupId).eq('user_id', newUserId).single();
    if (existing) return res.status(409).json({ error: 'Користувач вже є учасником групи' });

    const { error } = await supabaseAdmin
      .from('group_chat_members')
      .insert([{ group_id: groupId, user_id: newUserId, role: 'member' }]);

    if (error) return res.status(500).json({ error: error.message });

    // Системне повідомлення
    const { data: profile } = await supabaseAdmin
      .from('profiles').select('username').eq('user_id', newUserId).single();
    await supabaseAdmin.from('group_chat_messages').insert([{
      group_id: groupId, sender_id: userId,
      content: JSON.stringify({ type: 'system', text: `${profile?.username || 'Користувача'} додано до групи` })
    }]);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Видалити учасника / Вийти з групи
app.delete('/api/group-chats/:groupId/members/:targetUserId', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const targetUserId = req.params.targetUserId;
    const isSelf = targetUserId === userId;

    // Отримуємо інфо про групу і мою роль
    const [groupRes, myMemberRes, targetMemberRes] = await Promise.all([
      supabaseAdmin.from('group_chats').select('owner_id').eq('id', groupId).single(),
      supabaseAdmin.from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single(),
      supabaseAdmin.from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', targetUserId).single()
    ]);

    const group = groupRes.data;
    const myRole = myMemberRes.data?.role;
    const targetRole = targetMemberRes.data?.role;

    if (!group) return res.status(404).json({ error: 'Група не знайдена' });
    if (!myRole) return res.status(403).json({ error: 'Ви не є учасником цієї групи' });
    if (!targetRole) return res.status(404).json({ error: 'Цільовий користувач не є учасником групи' });

    // Якщо виходить власник — потрібно передати права
    if (isSelf && myRole === 'owner') {
      const { count } = await supabaseAdmin
        .from('group_chat_members').select('*', { count: 'exact', head: true }).eq('group_id', groupId);
      if (count === 1) {
        return res.status(400).json({
          error: 'Ви єдиний учасник. Видаліть групу замість виходу.',
          code: 'LAST_MEMBER'
        });
      }
      return res.status(400).json({
        error: 'Ви є власником. Передайте права власника іншому учаснику перед виходом.',
        code: 'MUST_TRANSFER'
      });
    }

    // Адмін не може видалити власника або іншого адміна (якщо сам не власник)
    if (!isSelf && myRole === 'admin' && targetRole !== 'member') {
      return res.status(403).json({ error: 'Адмін може видаляти тільки звичайних учасників' });
    }
    // Звичайний член не може видаляти інших
    if (!isSelf && myRole === 'member') {
      return res.status(403).json({ error: 'Недостатньо прав' });
    }

    const { error } = await supabaseAdmin
      .from('group_chat_members')
      .delete().eq('group_id', groupId).eq('user_id', targetUserId);

    if (error) return res.status(500).json({ error: error.message });

    // Системне повідомлення
    const { data: profile } = await supabaseAdmin
      .from('profiles').select('username').eq('user_id', targetUserId).single();
    const sysText = isSelf
      ? `${profile?.username || 'Користувач'} покинув(ла) групу`
      : `${profile?.username || 'Користувача'} виключено з групи`;
    await supabaseAdmin.from('group_chat_messages').insert([{
      group_id: groupId, sender_id: userId,
      content: JSON.stringify({ type: 'system', text: sysText })
    }]);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Змінити роль учасника (призначити/зняти адміна)
app.put('/api/group-chats/:groupId/members/:targetUserId/role', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const targetUserId = req.params.targetUserId;
    const { role } = req.body;

    if (!['admin', 'member'].includes(role)) {
      return res.status(400).json({ error: 'Роль може бути admin або member' });
    }

    // Тільки власник може змінювати ролі
    const { data: myRole } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!myRole || myRole.role !== 'owner') {
      return res.status(403).json({ error: 'Тільки власник може змінювати ролі' });
    }

    // Не можна змінити роль власника
    const { data: targetMember } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', targetUserId).single();
    if (!targetMember) return res.status(404).json({ error: 'Учасник не знайдений' });
    if (targetMember.role === 'owner') return res.status(400).json({ error: 'Неможливо змінити роль власника' });

    const { error } = await supabaseAdmin
      .from('group_chat_members')
      .update({ role }).eq('group_id', groupId).eq('user_id', targetUserId);

    if (error) return res.status(500).json({ error: error.message });

    // Системне повідомлення
    const { data: profile } = await supabaseAdmin
      .from('profiles').select('username').eq('user_id', targetUserId).single();
    const roleText = role === 'admin' ? 'призначено адміністратором' : 'знято з посади адміністратора';
    await supabaseAdmin.from('group_chat_messages').insert([{
      group_id: groupId, sender_id: userId,
      content: JSON.stringify({ type: 'system', text: `${profile?.username || 'Користувача'} ${roleText}` })
    }]);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Передати права власника
app.post('/api/group-chats/:groupId/transfer-ownership', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const { new_owner_id } = req.body;

    if (!new_owner_id) return res.status(400).json({ error: 'new_owner_id обов\'язковий' });

    // Тільки власник може передати права
    const { data: myRole } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!myRole || myRole.role !== 'owner') {
      return res.status(403).json({ error: 'Тільки власник може передати права' });
    }

    // Перевірка що новий власник є учасником
    const { data: newOwnerMember } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', new_owner_id).single();
    if (!newOwnerMember) return res.status(404).json({ error: 'Новий власник не є учасником групи' });

    // Передаємо права
    await Promise.all([
      supabaseAdmin.from('group_chat_members').update({ role: 'owner' }).eq('group_id', groupId).eq('user_id', new_owner_id),
      supabaseAdmin.from('group_chat_members').update({ role: 'admin' }).eq('group_id', groupId).eq('user_id', userId),
      supabaseAdmin.from('group_chats').update({ owner_id: new_owner_id }).eq('id', groupId)
    ]);

    // Системне повідомлення
    const [{ data: oldProfile }, { data: newProfile }] = await Promise.all([
      supabaseAdmin.from('profiles').select('username').eq('user_id', userId).single(),
      supabaseAdmin.from('profiles').select('username').eq('user_id', new_owner_id).single()
    ]);
    await supabaseAdmin.from('group_chat_messages').insert([{
      group_id: groupId, sender_id: userId,
      content: JSON.stringify({
        type: 'system',
        text: `${oldProfile?.username || 'Власник'} передав права групи ${newProfile?.username || 'новому власнику'}`
      })
    }]);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Перейменувати групу
app.put('/api/group-chats/:groupId', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const { name } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ error: 'Назва не може бути порожньою' });

    const { data: myRole } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!myRole || !['owner', 'admin'].includes(myRole.role)) {
      return res.status(403).json({ error: 'Недостатньо прав для перейменування' });
    }

    const { error } = await supabaseAdmin
      .from('group_chats').update({ name: name.trim() }).eq('id', groupId);

    if (error) return res.status(500).json({ error: error.message });

    await supabaseAdmin.from('group_chat_messages').insert([{
      group_id: groupId, sender_id: userId,
      content: JSON.stringify({ type: 'system', text: `Група перейменована на "${name.trim()}"` })
    }]);

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Видалити групу (тільки власник)
app.delete('/api/group-chats/:groupId', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);

    const { data: group } = await supabaseAdmin
      .from('group_chats').select('owner_id').eq('id', groupId).single();
    if (!group) return res.status(404).json({ error: 'Група не знайдена' });
    if (group.owner_id !== userId) return res.status(403).json({ error: 'Тільки власник може видалити групу' });

    // Видаляємо (cascade видалить members та messages)
    const { error } = await supabaseAdmin.from('group_chats').delete().eq('id', groupId);
    if (error) return res.status(500).json({ error: error.message });

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Отримати повідомлення групового чату
app.get('/api/group-chats/:groupId/messages', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);

    const { data: member } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!member) return res.status(403).json({ error: 'Ви не є учасником цієї групи' });

    const { data: messages, error } = await supabaseAdmin
      .from('group_chat_messages').select('*').eq('group_id', groupId).order('sent_at', { ascending: true });

    if (error) return res.status(500).json({ error: error.message });

    // Збагачуємо: sender profile + reply_to
    const enriched = await Promise.all((messages || []).map(async msg => {
      const [profileRes, replyRes] = await Promise.all([
        supabaseAdmin.from('profiles').select('user_id, username, avatar_url').eq('user_id', msg.sender_id).single(),
        msg.reply_to_id
          ? supabaseAdmin.from('group_chat_messages').select('id, content, sender_id').eq('id', msg.reply_to_id).single()
          : Promise.resolve({ data: null })
      ]);

      let replyData = null;
      if (replyRes.data) {
        const { data: replySender } = await supabaseAdmin
          .from('profiles').select('username').eq('user_id', replyRes.data.sender_id).single();
        replyData = { ...replyRes.data, sender_username: replySender?.username || 'Користувач' };
      }

      return {
        ...msg,
        sender_profile: profileRes.data || { username: 'Користувач', avatar_url: null },
        reply_to: replyData
      };
    }));

    res.json({ messages: enriched });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Відправити повідомлення в груповий чат
app.post('/api/group-chats/:groupId/messages', authMiddleware, async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    const userId = req.user.id;
    const groupId = parseInt(req.params.groupId);
    const { content, reply_to_id } = req.body;

    if (!content || !content.trim()) return res.status(400).json({ error: 'Повідомлення не може бути порожнім' });

    const { data: member } = await supabaseAdmin
      .from('group_chat_members').select('role').eq('group_id', groupId).eq('user_id', userId).single();
    if (!member) return res.status(403).json({ error: 'Ви не є учасником цієї групи' });

    const insertObj = { group_id: groupId, sender_id: userId, content: content.trim() };
    if (reply_to_id) insertObj.reply_to_id = parseInt(reply_to_id);

    const { data: newMsg, error } = await supabaseAdmin
      .from('group_chat_messages').insert([insertObj]).select().single();

    if (error) return res.status(500).json({ error: error.message });

    // Профіль відправника
    const { data: senderProfile } = await supabaseAdmin
      .from('profiles').select('user_id, username, avatar_url').eq('user_id', userId).single();

    res.status(201).json({
      message: {
        ...newMsg,
        sender_profile: senderProfile || { username: 'Користувач', avatar_url: null },
        reply_to: null
      }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ============================================================
// API: РЕПОСТ ФІЛЬМУ В ЧАТ
// ============================================================

// Отримати кількість репостів фільму
app.get('/api/movie/:movieId/reposts/count', async (req, res) => {
  try {
    const movieId = parseInt(req.params.movieId);
    const { count, error } = await supabaseAdmin
      .from('movie_reposts')
      .select('*', { count: 'exact', head: true })
      .eq('media_id', movieId);

    if (error) {
      return res.status(500).json({ error: 'Помилка при отриманні кількості репостів', details: error.message });
    }
    res.json({ count: count || 0 });
  } catch (e) {
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: e.message });
  }
});

// Репостнути фільм у чат
app.post('/api/movie/:movieId/repost', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const movieId = parseInt(req.params.movieId);
    const userId = req.user.id;
    const { chat_id } = req.body;

    if (!chat_id) {
      return res.status(400).json({ error: 'Необхідно вказати ID чату' });
    }

    // Перевіряємо доступ до чату
    const { data: chat, error: chatError } = await supabase
      .from('chats')
      .select('*')
      .eq('id', chat_id)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .single();

    if (chatError || !chat) {
      return res.status(404).json({ error: 'Чат не знайдено або доступ заборонено' });
    }

    // Отримуємо дані фільму
    const { data: movie, error: movieError } = await supabaseAdmin
      .from('media')
      .select('id, title, poster_url, release_date, imdb_rating, description')
      .eq('id', movieId)
      .single();

    if (movieError || !movie) {
      return res.status(404).json({ error: 'Фільм не знайдено' });
    }

    // Формуємо спеціальний JSON-контент для повідомлення
    const messageContent = JSON.stringify({
      type: 'movie_repost',
      movie_id: movie.id,
      title: movie.title,
      poster_url: movie.poster_url,
      release_date: movie.release_date,
      imdb_rating: movie.imdb_rating,
      url: `/movie/${movie.id}`
    });

    const now = new Date();

    // Відправляємо картку фільму у чат
    const { data: newMessage, error: msgError } = await supabase
      .from('chat_messages')
      .insert([{
        chat_id: parseInt(chat_id),
        sender_id: userId,
        content: messageContent,
        is_read: false,
        sent_at: now
      }])
      .select()
      .single();

    if (msgError) {
      return res.status(500).json({ error: 'Помилка при відправці повідомлення', details: msgError.message });
    }

    // Якщо є необов'язкове текстове повідомлення — відправляємо його окремо
    const { message } = req.body;
    if (message && typeof message === 'string' && message.trim()) {
      await supabase
        .from('chat_messages')
        .insert([{
          chat_id: parseInt(chat_id),
          sender_id: userId,
          content: message.trim(),
          is_read: false,
          sent_at: new Date(now.getTime() + 1) // +1ms щоб гарантувати порядок
        }]);
    }

    // Записуємо репост у таблицю movie_reposts
    await supabaseAdmin
      .from('movie_reposts')
      .insert([{ media_id: movieId, user_id: userId, chat_id: parseInt(chat_id) }]);

    res.status(201).json({ success: true, message: newMessage });
  } catch (e) {
    console.error('Помилка при репості фільму:', e);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: e.message });
  }
});

app.get('/api/users/search', async (req, res) => {
  try {
  // Перевірка авторизації
  if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
  }

    const query = req.query.query;

    if (!query) {
      return res.status(400).json({ error: 'Необхідно вказати пошуковий запит' });
  }

    // Шукаємо користувачів за іменем користувача
    const { data: users, error } = await supabase
      .from('profiles')
      .select('user_id, username, avatar_url, bio')
      .ilike('username', `%${query}%`)
      .limit(10);

    if (error) {
      console.error('Помилка при пошуку користувачів:', error);
      return res.status(500).json({ error: 'Помилка при пошуку користувачів', details: error.message });
    }

    res.json({ users });
  } catch (error) {
    console.error('Помилка при пошуку користувачів:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.get('/api/users/:userId', async (req, res) => {
  try {
    // Перевірка авторизації
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }

    const userId = req.params.userId;

    // Отримуємо профіль користувача
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (profileError || !profile) {
      console.error('Помилка при отриманні профілю користувача:', profileError);
      return res.status(404).json({ error: 'Профіль не знайдено' });
    }

    // Отримуємо статистику користувача
    const [reviews, favorites, comments] = await Promise.all([
      supabase.from('reviews').select('id', { count: 'exact' }).eq('user_id', userId),
      supabase.from('favorites').select('media_id', { count: 'exact' }).eq('user_id', userId),
      supabase.from('discussion_comments').select('id', { count: 'exact' }).eq('user_id', userId)
    ]);

    // Формуємо об'єкт з даними профілю та статистикою
    const profileData = {
      profile: profile,
      stats: {
        reviews: reviews.count || 0,
        favorites: favorites.count || 0,
        comments: comments.count || 0
      }
    };

    res.json(profileData);
  } catch (error) {
    console.error('Помилка при отриманні профілю користувача:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// Маршрут для створення нової рецензії
app.post('/api/reviews', async (req, res) => {
    try {
        const { mediaId, content, rating, containsSpoilers } = req.body;

        // Перевірка авторизації
        if (!req.user) {
            return res.status(401).json({ error: 'Потрібна авторизація' });
        }

        const userId = req.user.id;

        const { error } = await supabase
            .from('reviews')
            .insert([
                {
                    user_id: userId,
                    media_id: mediaId,
                    content,
                    rating,
                    contains_spoilers: containsSpoilers,
                    created_at: new Date()
                }
            ]);

        if (error) throw error;

        res.json({ success: true });
    } catch (error) {
        console.error('Помилка при створенні рецензії:', error);
        res.status(500).json({ error: 'Помилка при створенні рецензії' });
    }
});

// Видалення рецензії за id
app.delete('/api/reviews/:id', async (req, res) => {
  try {
    const reviewId = Number(req.params.id);
    // Перевірка авторизації
    if (!req.user) {
      return res.status(401).json({ error: 'Потрібна авторизація' });
    }
    // Перевіряємо, що рецензія належить користувачу
    const { data: review, error: reviewError } = await supabase
      .from('reviews')
      .select('user_id')
      .eq('id', reviewId)
      .single();
    if (reviewError || !review) {
      return res.status(404).json({ error: 'Рецензія не знайдена' });
    }
    if (review.user_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ error: 'Видалення заборонено' });
    }
    // Видаляємо рецензію
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId);
    if (error) {
      return res.status(500).json({ error: 'Помилка при видаленні рецензії' });
    }
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// API для лайков рецензий
app.post('/api/review-likes', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }
    const userId = req.user.id;
    const reviewId = req.body.reviewId || req.body.review_id;
    if (!reviewId) {
      return res.status(400).json({ error: 'Не вказано ID рецензії' });
    }

    const { data: existing } = await supabaseAdmin
      .from('review_likes').select('review_id').eq('user_id', userId).eq('review_id', reviewId).single();

    if (existing) {
      return res.status(409).json({ error: 'Рецензія вже лайкнута' });
    }

    const { error } = await supabaseAdmin
      .from('review_likes').insert([{ user_id: userId, review_id: reviewId }]);

    if (error) return res.status(500).json({ error: 'Помилка при додаванні лайку', details: error.message });

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

app.delete('/api/review-likes', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Користувач не авторизований' });
    }
    const userId = req.user.id;
    const reviewId = req.body.reviewId || req.body.review_id;
    if (!reviewId) {
      return res.status(400).json({ error: 'Не вказано ID рецензії' });
    }

    const { error } = await supabaseAdmin
      .from('review_likes').delete().eq('user_id', userId).eq('review_id', reviewId);

    if (error) return res.status(500).json({ error: 'Помилка при видаленні лайку', details: error.message });

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});

// --- КІНЕЦЬ БЛОКУ API-МАРШРУТІВ ---

// --- API перегляду обговорень ---
app.get('/api/discussions/preview', async (req, res) => {
  try {
    // Отримуємо 3 найновіші обговорення
    const { data: discussions, error: discussionsError } = await supabaseAdmin
      .from('discussions')
      .select('id, title, creator_id, description, created_at')
      .order('created_at', { ascending: false })
      .limit(3);

    if (discussionsError) {
      return res.status(500).json({ error: 'Помилка при отриманні обговорень', details: discussionsError.message });
    }

    // Для кожного обговорення отримуємо автора, кількість коментарів та перший коментар
    const result = await Promise.all(discussions.map(async (discussion) => {
      // Отримуємо автора
      const { data: author } = await supabaseAdmin
        .from('profiles')
        .select('username, avatar_url')
        .eq('user_id', discussion.creator_id)
        .single();

      // Отримуємо кількість коментарів
      const { count: commentsCount } = await supabaseAdmin
        .from('discussion_comments')
        .select('id', { count: 'exact' })
        .eq('discussion_id', discussion.id);

      // Отримуємо перший коментар (за датою)
      const { data: firstComment } = await supabaseAdmin
        .from('discussion_comments')
        .select('content, user_id')
        .eq('discussion_id', discussion.id)
        .order('created_at', { ascending: true })
        .limit(1)
        .single();

      let commentData = null;
      if (firstComment) {
        // Отримуємо ім'я автора коментаря
        const { data: commentAuthor } = await supabaseAdmin
          .from('profiles')
          .select('username')
          .eq('user_id', firstComment.user_id)
          .single();
        commentData = {
          username: commentAuthor ? commentAuthor.username : 'Анонім',
          content: firstComment.content
        };
      }

      return {
        id: discussion.id,
        title: discussion.title,
        author: {
          username: author ? author.username : 'Анонім',
          avatar_url: author && author.avatar_url ? author.avatar_url : 'https://randomuser.me/api/portraits/men/1.jpg'
        },
        description: discussion.description || '',
        comments_count: commentsCount || 0,
        first_comment: commentData
      };
    }));

    res.json({ discussions: result });
  } catch (error) {
    res.status(500).json({ error: 'Внутрішня помилка сервера', details: error.message });
  }
});
// ... існуючий код ...

// --- API: отримати всі обговорення для discussions.html ---
app.get('/api/discussions/all', async (req, res) => {
  try {
    // Отримуємо всі обговорення
    const { data: discussions, error: discussionsError } = await supabaseAdmin
      .from('discussions')
      .select('id, title, description, creator_id, created_at')
      .order('created_at', { ascending: false });

    if (discussionsError) {
      return res.status(500).json({ error: 'Помилка при отриманні обговорень', details: discussionsError.message });
    }

    // Отримуємо авторів та кількість коментарів для кожного обговорення
    const result = await Promise.all(discussions.map(async (discussion) => {
      // Автор
      const { data: author } = await supabaseAdmin
        .from('profiles')
        .select('user_id, username, avatar_url')
        .eq('user_id', discussion.creator_id)
        .single();
      // Кількість коментарів
      const { count: comments_count } = await supabaseAdmin
        .from('discussion_comments')
        .select('id', { count: 'exact', head: true })
        .eq('discussion_id', discussion.id);
      return {
        ...discussion,
        author: author || { username: 'Невідомий', avatar_url: '/img/avatar-default.png' },
        comments_count: comments_count || 0
      };
    }));
    res.json({ discussions: result });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});
// ... існуючий код ...

// --- ADMIN MIDDLEWARE ---
const adminMiddleware = async (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Не авторизований' });
  }
  
  // Використовуємо user_metadata з Supabase Auth замість таблиці profiles
  if (!req.user.user_metadata || !req.user.user_metadata.is_admin) {
    return res.status(403).json({ error: 'Доступ заборонено (потрібні права адміністратора)' });
  }
  
  req.user.is_admin = true;
  next();
};

// --- ADMIN API ROUTES ---
app.post('/api/admin/promote', async (req, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'Не авторизований' });
    
    const { secret_key } = req.body;
    const ADMIN_SECRET = process.env.ADMIN_SECRET || 'ABSOLUTE_ADMIN_2025';
    
    if (secret_key !== ADMIN_SECRET) {
      return res.status(403).json({ error: 'Невірний секретний ключ' });
    }
    
    // Оновлюємо метадані користувача
    const { error } = await supabaseAdmin.auth.admin.updateUserById(
      req.user.id,
      { user_metadata: { is_admin: true } }
    );
      
    if (error) throw error;
    
    res.json({ success: true, message: 'Права адміністратора надано успішно!' });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

app.get('/api/admin/check', adminMiddleware, (req, res) => {
  res.json({ is_admin: true });
});

app.get('/api/admin/stats', adminMiddleware, async (req, res) => {
  try {
    const [usersCount, moviesCount, reviewsCount, discussionsCount] = await Promise.all([
      supabase.from('profiles').select('*', { count: 'exact', head: true }),
      supabase.from('media').select('*', { count: 'exact', head: true }),
      supabase.from('reviews').select('*', { count: 'exact', head: true }),
      supabase.from('discussions').select('*', { count: 'exact', head: true })
    ]);
    
    res.json({
      users: usersCount.count || 0,
      movies: moviesCount.count || 0,
      reviews: reviewsCount.count || 0,
      discussions: discussionsCount.count || 0
    });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

app.get('/api/admin/users', adminMiddleware, async (req, res) => {
  try {
    const { data: profiles, error: profileError } = await supabase
      .from('profiles')
      .select('user_id, username, created_at')
      .order('created_at', { ascending: false });
      
    if (profileError) throw profileError;
    
    const { data: { users }, error: authError } = await supabaseAdmin.auth.admin.listUsers();
    if (authError) throw authError;
    
    const adminMap = {};
    users.forEach(u => {
      adminMap[u.id] = u.user_metadata?.is_admin || false;
    });
    
    const result = profiles.map(p => ({
      ...p,
      is_admin: adminMap[p.user_id] || false
    }));
    
    res.json({ users: result });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера' });
  }
});

app.post('/api/admin/users/:id/toggle-admin', adminMiddleware, async (req, res) => {
  try {
    const userId = req.params.id;
    const { is_admin } = req.body;
    
    const { error } = await supabaseAdmin.auth.admin.updateUserById(
      userId,
      { user_metadata: { is_admin } }
    );
      
    if (error) throw error;
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера' });
  }
});

app.delete('/api/admin/users/:id', adminMiddleware, async (req, res) => {
  try {
    const userId = req.params.id;
    const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);
    if (error) throw error;
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Помилка при видаленні користувача', details: e.message });
  }
});

// Список усіх жанрів (для вибору при додаванні фільму)
app.get('/api/genres', async (req, res) => {
  try {
    const { data, error } = await supabase.from('genres').select('id, name').order('name');
    if (error) throw error;
    res.json({ genres: data });
  } catch (e) {
    res.status(500).json({ error: 'Помилка при отриманні жанрів', details: e.message });
  }
});

app.post('/api/admin/media', adminMiddleware, async (req, res) => {
  try {
    const { genre_ids, ...mediaData } = req.body;
    const { data, error } = await supabase.from('media').insert([mediaData]).select();
    if (error) throw error;
    const media = data[0];

    if (Array.isArray(genre_ids) && genre_ids.length > 0) {
      const rows = genre_ids.map(genreId => ({ media_id: media.id, genre_id: genreId }));
      const { error: genresError } = await supabase.from('media_genres').insert(rows);
      if (genresError) console.error('Помилка при прив\'язці жанрів:', genresError);
    }

    res.json({ media });
  } catch (e) {
    res.status(500).json({ error: 'Помилка при додаванні', details: e.message });
  }
});

app.delete('/api/admin/media/:id', adminMiddleware, async (req, res) => {
  try {
    const { error } = await supabase.from('media').delete().eq('id', req.params.id);
    if (error) throw error;
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Помилка при видаленні', details: e.message });
  }
});


// Статичні файли (після API-маршрутів)
app.use(express.static(path.join(__dirname)));

// Маршрут для сторінки профілю (після API та статики)
app.get('/profile', (req, res) => {
  console.log('Запит до маршруту /profile');
    if (!req.user) {
    console.log('Спроба доступу до сторінки профілю неавторизованим користувачем - перенаправлення на /login');
      return res.redirect('/login');
  }
  console.log('Надсилання HTML сторінки профілю для користувача:', req.user.id);
      const profilePath = path.resolve(__dirname, 'profile.html');
  console.log('Шлях до файлу профілю:', profilePath);
  res.sendFile(profilePath);
});

// Маршрут для сторінки детального перегляду фільму (після API та статики)
app.get('/movie/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'movie.html'));
});

// Маршрути адмін-панелі
app.get('/admin-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin-login.html'));
});

app.get('/admin', (req, res) => {
  if (!req.user) return res.redirect('/admin-login');
  if (req.user.user_metadata && req.user.user_metadata.is_admin) {
    return res.sendFile(path.join(__dirname, 'admin.html'));
  }
  return res.redirect('/admin-login');
});


// Маршрут для сторінки чатів (після API та статики)
app.get('/chats', (req, res) => {
  console.log('Обробка запиту до /chats');
  if (!req.user) {
    console.log('Користувач не авторизований, перенаправлення на /login');
    return res.redirect('/login');
  }
  const chatsPath = path.resolve(__dirname, 'chats.html');
  console.log('Надсилання chats.html:', chatsPath);
  return res.sendFile(chatsPath);
});

// Маршрут для сторінки онбордингу (ДО catch-all)
app.get('/onboarding', (req, res) => {
  res.sendFile(path.join(__dirname, 'onboarding.html'));
});

// Маршрут для всіх інших запитів - віддаємо index.html (в самому кінці)
app.get(/^\/(?!api).*/, (req, res, next) => {
  if (req.path.startsWith('/ws/chat')) {
    return next();
  }
  console.log('Запит до URL (catch-all):', req.path, '- надсилаємо index.html');
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Перевірка структури БД під час запуску сервера
async function checkDatabaseStructure() {
  try {
    console.log('Перевірка структури бази даних...');

    // Перевіряємо існування таблиці chat_messages
    const { count, error: countError } = await supabase
      .from('chat_messages')
      .select('*', { count: 'exact', head: true });

    if (countError) {
      console.error('Помилка при перевірці таблиці chat_messages:', countError);

      if (countError.code === '42P01') { // Код помилки "відношення не існує"
        console.log('Таблиця chat_messages не існує, створюємо її...');

        // Створюємо таблицю chat_messages
        const createTableQuery = `
          CREATE TABLE IF NOT EXISTS chat_messages (
            id SERIAL PRIMARY KEY,
            chat_id INTEGER REFERENCES chats(id) ON DELETE CASCADE,
            sender_id UUID REFERENCES profiles(user_id) ON DELETE CASCADE,
            content TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            sent_at TIMESTAMPTZ DEFAULT NOW()
          );
        `;
        
        const { error: createError } = await supabase.rpc('execute_sql', { sql: createTableQuery });
        
        if (createError) {
          console.error('Помилка при створенні таблиці chat_messages:', createError);
        } else {
          console.log('Таблицю chat_messages успішно створено');
        }
      }
    } else {
      console.log('Таблиця chat_messages існує');
    }

    // Додаємо колонку favorites_id у таблицю favorites, якщо вона відсутня
    const addIdColumnQuery = `
        DO $$ 
        BEGIN 
            IF NOT EXISTS (
                SELECT 1 
                FROM information_schema.columns 
                WHERE table_name = 'favorites' 
                AND column_name = 'favorites_id'
            ) THEN
                ALTER TABLE favorites ADD COLUMN favorites_id SERIAL PRIMARY KEY;
            END IF;
        END $$;
    `;

    await supabase.rpc('execute_sql', { sql: addIdColumnQuery });
    console.log('Перевірку колонки favorites_id у таблиці favorites виконано');

    // Додаємо колонку is_admin у таблицю profiles, якщо вона відсутня
    const addAdminColumnQuery = `
        DO $$ 
        BEGIN 
            IF NOT EXISTS (
                SELECT 1 
                FROM information_schema.columns 
                WHERE table_name = 'profiles' 
                AND column_name = 'is_admin'
            ) THEN
                ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT FALSE;
            END IF;
        END $$;
    `;
    await supabase.rpc('execute_sql', { sql: addAdminColumnQuery });
    console.log('Перевірку колонки is_admin у таблиці profiles виконано');

  } catch (error) {
    console.error('Помилка при перевірці структури БД:', error);
  }
}

// Запуск сервера
server.listen(PORT, async () => {
  console.log(`Сервер запущено на порту ${PORT}`);

  // Перевіряємо структуру БД під час запуску
  await checkDatabaseStructure();
});

app.get('/api/discussions/:id/comments', async (req, res) => {
  try {
    const discussionId = req.params.id;
    const { data: comments, error } = await supabaseAdmin
    .from('discussion_comments')
    .select('id, user_id, content, created_at, parent_id')
    .eq('discussion_id', discussionId)
    .order('created_at', { ascending: true });

    if (error) {
      return res.status(500).json({ error: 'Помилка при отриманні коментарів', details: error.message });
    }

    // Отримуємо авторів коментарів
    const userIds = [...new Set(comments.map(c => c.user_id))];
    let usersMap = {};
    if (userIds.length > 0) {
      const { data: users } = await supabaseAdmin
        .from('profiles')
        .select('user_id, username, avatar_url')
        .in('user_id', userIds);
      (users || []).forEach(u => { usersMap[u.user_id] = u; });
    }

    const result = comments.map(c => ({
      ...c,
      author: usersMap[c.user_id] ? {
        username: usersMap[c.user_id].username,
        avatar_url: usersMap[c.user_id].avatar_url
      } : { username: 'Невідомий', avatar_url: '/img/avatar-default.png' }
    }));

    res.json({ comments: result });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

app.post('/api/discussions', async (req, res) => {
  try {
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Не авторизований' });

    const { title, description } = req.body;
    if (!title || !description) return res.status(400).json({ error: 'Заповніть усі поля' });

    // Використовуємо supabaseAdmin для обходу RLS
    const { data, error } = await supabaseAdmin
      .from('discussions')
      .insert([{ title, description, creator_id: user.id }])
      .select()
      .single();

    if (error) return res.status(500).json({ error: 'Помилка при створенні обговорення', details: error.message });

    res.json({ discussion: data });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

app.post('/api/discussions/:id/comments', async (req, res) => {
  try {
    // Перевірка авторизації
    const user = req.user;
    if (!user) return res.status(401).json({ error: 'Не авторизований' });

    const discussionId = req.params.id;
    const { content, parent_id } = req.body;
    if (!content || !discussionId) return res.status(400).json({ error: 'Введіть текст коментаря' });

    const insertObj = { discussion_id: discussionId, user_id: user.id, content };
    if (parent_id !== undefined && parent_id !== null && parent_id !== '') insertObj.parent_id = parent_id;

    const { data, error } = await supabaseAdmin
      .from('discussion_comments')
      .insert([insertObj])
      .single();

    if (error) return res.status(500).json({ error: 'Помилка при додаванні коментаря', details: error.message });

    res.json({ comment: data });
  } catch (e) {
    res.status(500).json({ error: 'Помилка сервера', details: e.message });
  }
});

// Видалення коментаря обговорення
app.delete('/api/discussions/:discussionId/comments/:commentId', async (req, res) => {
  try {
      const { discussionId, commentId } = req.params;
      // Перевірка авторизації
      const user = req.user;
      if (!user) return res.status(401).json({ error: 'Не авторизований' });
        // Отримуємо коментар
        const { data: comment, error: getErr } = await supabaseAdmin
            .from('discussion_comments')
            .select('id, user_id')
            .eq('id', commentId)
            .eq('discussion_id', discussionId)
            .single();
        if (getErr || !comment) {
            return res.status(404).json({ error: 'Коментар не знайдено' });
        }
        if (comment.user_id !== user.id && comment.user_id !== user.user_id) {
            return res.status(403).json({ error: 'Ви не можете видалити цей коментар' });
        }
        // Видаляємо коментар
        const { error: delErr } = await supabaseAdmin
            .from('discussion_comments')
            .delete()
            .eq('id', commentId)
            .eq('discussion_id', discussionId);
        if (delErr) {
            return res.status(500).json({ error: 'Помилка при видаленні коментаря', details: delErr.message });
        }
        return res.json({ success: true });
    } catch (e) {
        return res.status(500).json({ error: 'Внутрішня помилка сервера', details: e.message });
    }
});

// Видалення обговорення
app.delete('/api/discussions/:discussionId', async (req, res) => {
    try {
        const { discussionId } = req.params;
        // Перевірка авторизації
        const { user } = await authCheck(req, res);
        if (!user) return; // authCheck сам надішле 401
        // Отримуємо обговорення
        const { data: discussion, error: getErr } = await supabaseAdmin
            .from('discussions')
            .select('id, user_id')
            .eq('id', discussionId)
            .single();
        if (getErr || !discussion) {
            return res.status(404).json({ error: 'Обговорення не знайдено' });
        }
        if (discussion.user_id !== user.id && discussion.user_id !== user.user_id) {
            return res.status(403).json({ error: 'Ви не автор цього обговорення' });
        }
        // Видаляємо всі коментарі до обговорення
        await supabaseAdmin
            .from('discussion_comments')
            .delete()
            .eq('discussion_id', discussionId);
        // Видаляємо саме обговорення
        const { error: delErr } = await supabaseAdmin
            .from('discussions')
            .delete()
            .eq('id', discussionId);
        if (delErr) {
            return res.status(500).json({ error: 'Помилка при видаленні обговорення' });
        }
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: 'Помилка сервера' });
    }
});

// API для пошуку фільмів
app.get('/api/search', async (req, res) => {
  try {
    const query = req.query.query;
    if (!query) {
      return res.json({ movies: [] });
    }

    // Отримуємо фільми з бази даних
    const { data, error } = await supabase
      .from('media')
      .select(`
        id,
        title,
        poster_url,
        release_date,
        type,
        imdb_rating,
        description
      `)
      .eq('type', 'movie')
      .ilike('title', `%${query}%`)
      .limit(5);

    if (error) {
      console.error('Помилка при пошуку фільмів:', error);
      return res.status(500).json({ error: 'Помилка при пошуку фільмів' });
    }

    // Для кожного фільму отримуємо його жанри
    const moviesWithGenres = await Promise.all(data.map(async (movie) => {
      try {
        const { data: genresData } = await supabase
          .from('media_genres')
          .select(`
            genres:genre_id(name)
          `)
          .eq('media_id', movie.id);

        const genres = genresData ? genresData.map(g => g.genres.name) : [];
        return { ...movie, genres };
      } catch (error) {
        console.error(`Помилка при отриманні жанрів для фільму ${movie.id}:`, error);
        return { ...movie, genres: [] };
      }
    }));

    res.json({ movies: moviesWithGenres });
  } catch (error) {
    console.error('Помилка при пошуку фільмів:', error);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// ============================================================
// ONBOARDING & PERSONALIZED RECOMMENDATIONS
// ============================================================

// GET /api/onboarding/movies — return ~10 diverse movies for swipe game
app.get('/api/onboarding/movies', async (req, res) => {
  try {
    // Fetch movies with variety across genres
    const { data, error } = await supabaseAdmin
      .from('media')
      .select('id, title, poster_url, imdb_rating, description, release_date')
      .eq('type', 'movie')
      .not('poster_url', 'is', null)
      .not('imdb_rating', 'is', null)
      .order('imdb_rating', { ascending: false })
      .limit(60);

    if (error) {
      console.error('Onboarding movies error:', error);
      return res.status(500).json({ error: 'Помилка завантаження фільмів для онбордингу' });
    }

    // Filter valid movies
    const valid = (data || []).filter(m => m.poster_url && m.title);

    // Enrich with genres
    const withGenres = await Promise.all(valid.map(async (movie) => {
      try {
        const { data: gd } = await supabaseAdmin
          .from('media_genres')
          .select('genres:genre_id(name)')
          .eq('media_id', movie.id);
        const genres = (gd || []).map(g => g.genres?.name).filter(Boolean);
        return { ...movie, genres };
      } catch {
        return { ...movie, genres: [] };
      }
    }));

    // Shuffle and pick 10 diverse movies (try to vary genres)
    const shuffled = withGenres.sort(() => Math.random() - 0.5);
    const selected = [];
    const usedGenres = new Set();

    for (const movie of shuffled) {
      if (selected.length >= 10) break;
      const hasNew = movie.genres.some(g => !usedGenres.has(g));
      if (hasNew || selected.length < 3) {
        selected.push(movie);
        movie.genres.forEach(g => usedGenres.add(g));
      }
    }

    // If we don't have 10, fill with remaining
    if (selected.length < 10) {
      for (const movie of shuffled) {
        if (selected.length >= 10) break;
        if (!selected.find(m => m.id === movie.id)) {
          selected.push(movie);
        }
      }
    }

    res.json({ movies: selected });
  } catch (err) {
    console.error('Onboarding movies error:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// POST /api/onboarding/complete — save genre preferences, mark onboarding done
app.post('/api/onboarding/complete', async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ error: 'Не авторизований' });
    }

    const { genres, min_rating } = req.body;
    if (!genres || !Array.isArray(genres)) {
      return res.status(400).json({ error: 'genres обов\'язковий (масив)' });
    }

    const prefs = {
      genres: genres,
      min_rating: typeof min_rating === 'number' ? Math.round(min_rating * 10) / 10 : 5.0,
      updated_at: new Date().toISOString()
    };

    const { error } = await supabaseAdmin
      .from('profiles')
      .update({
        genre_preferences: prefs,
        onboarding_completed: true
      })
      .eq('user_id', req.user.id);

    if (error) {
      console.error('Error saving onboarding prefs:', error);
      return res.status(500).json({ error: 'Помилка збереження налаштувань', details: error.message });
    }

    res.json({ success: true });
  } catch (err) {
    console.error('Onboarding complete error:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// POST /api/onboarding/skip — mark onboarding as completed without preferences
app.post('/api/onboarding/skip', async (req, res) => {
  try {
    if (!req.user) return res.json({ success: true }); // Not logged in, just skip

    await supabaseAdmin
      .from('profiles')
      .update({ onboarding_completed: true })
      .eq('user_id', req.user.id);

    res.json({ success: true });
  } catch (err) {
    console.error('Onboarding skip error:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// GET /api/onboarding/status — check if user needs onboarding
app.get('/api/onboarding/status', async (req, res) => {
  try {
    if (!req.user) {
      return res.json({ needs_onboarding: false, authenticated: false });
    }

    const { data, error } = await supabaseAdmin
      .from('profiles')
      .select('onboarding_completed, genre_preferences')
      .eq('user_id', req.user.id)
      .single();

    if (error || !data) {
      return res.json({ needs_onboarding: true, authenticated: true });
    }

    res.json({
      needs_onboarding: !data.onboarding_completed,
      authenticated: true,
      genre_preferences: data.genre_preferences || null
    });
  } catch (err) {
    console.error('Onboarding status error:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// GET /api/recommendations/personal — personalized movie recommendations
// Logic:
//   1. Take genre preferences from onboarding
//   2. Also look at last 5 favorites to update genre weights dynamically
//   3. Return movies where: at least 1 genre matches AND imdb_rating >= min_rating
//   4. Sort by imdb_rating desc
app.get('/api/recommendations/personal', async (req, res) => {
  try {
    if (!req.user) {
      // Fall back to top-rated movies
      const { data } = await supabaseAdmin
        .from('media')
        .select('id, title, poster_url, imdb_rating, release_date')
        .eq('type', 'movie')
        .not('imdb_rating', 'is', null)
        .order('imdb_rating', { ascending: false })
        .limit(6);

      const movies = await enrichWithGenres(data || []);
      return res.json({ movies, personalized: false });
    }

    const userId = req.user.id;

    // Get user profile with preferences
    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('genre_preferences')
      .eq('user_id', userId)
      .single();

    // Get last 5 favorites and their genres
    const { data: recentFavs } = await supabaseAdmin
      .from('favorites')
      .select('media_id, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(5);

    // Build genre score map from onboarding prefs
    const genreScores = {};
    let minRating = 5.0;

    if (profile?.genre_preferences?.genres) {
      profile.genre_preferences.genres.forEach((genre, idx) => {
        // Higher-ranked genres get higher weight
        genreScores[genre] = (genreScores[genre] || 0) + (10 - idx);
      });
      minRating = profile.genre_preferences.min_rating || 5.0;
    }

    // Boost genres from last 5 favorites
    if (recentFavs && recentFavs.length > 0) {
      const favIds = recentFavs.map(f => f.media_id);

      const { data: favGenres } = await supabaseAdmin
        .from('media_genres')
        .select('media_id, genres:genre_id(name)')
        .in('media_id', favIds);

      (favGenres || []).forEach(fg => {
        const genreName = fg.genres?.name;
        if (genreName) {
          // Recent favorites have high weight (boosts existing preferences)
          genreScores[genreName] = (genreScores[genreName] || 0) + 5;
        }
      });
    }

    // If no preferences at all, return top-rated
    if (Object.keys(genreScores).length === 0) {
      const { data } = await supabaseAdmin
        .from('media')
        .select('id, title, poster_url, imdb_rating, release_date')
        .eq('type', 'movie')
        .not('imdb_rating', 'is', null)
        .order('imdb_rating', { ascending: false })
        .limit(6);

      const movies = await enrichWithGenres(data || []);
      return res.json({ movies, personalized: false });
    }

    const preferredGenres = Object.keys(genreScores);
    const minRatingFloat = parseFloat(minRating);

    // Get all movies meeting minimum rating
    const { data: allMovies, error: moviesError } = await supabaseAdmin
      .from('media')
      .select('id, title, poster_url, imdb_rating, release_date')
      .eq('type', 'movie')
      .not('imdb_rating', 'is', null)
      .gte('imdb_rating', minRatingFloat)
      .order('imdb_rating', { ascending: false })
      .limit(200);

    if (moviesError) {
      console.error('Personal recommendations error:', moviesError);
      return res.status(500).json({ error: 'Помилка завантаження рекомендацій' });
    }

    // Get already-favorited movie IDs to exclude
    const { data: allFavs } = await supabaseAdmin
      .from('favorites')
      .select('media_id')
      .eq('user_id', userId);

    const favIdSet = new Set((allFavs || []).map(f => f.media_id));

    // For each movie, get genres and compute score
    const scoredMovies = [];

    for (const movie of (allMovies || [])) {
      if (favIdSet.has(movie.id)) continue; // Skip already favorited

      const { data: gd } = await supabaseAdmin
        .from('media_genres')
        .select('genres:genre_id(name)')
        .eq('media_id', movie.id);

      const genres = (gd || []).map(g => g.genres?.name).filter(Boolean);

      // Check if at least one genre matches preferred genres
      const matchingGenres = genres.filter(g => preferredGenres.includes(g));
      if (matchingGenres.length === 0) continue;

      // Compute recommendation score
      let score = 0;
      matchingGenres.forEach(g => {
        score += genreScores[g] || 0;
      });
      // Boost by rating
      score += parseFloat(movie.imdb_rating || 0) * 2;

      scoredMovies.push({ ...movie, genres, _score: score });
    }

    // Sort by score and return top 6
    scoredMovies.sort((a, b) => b._score - a._score);
    const top = scoredMovies.slice(0, 6).map(({ _score, ...m }) => m);

    res.json({
      movies: top,
      personalized: true,
      preferred_genres: preferredGenres.slice(0, 5),
      min_rating: minRatingFloat
    });
  } catch (err) {
    console.error('Personal recommendations error:', err);
    res.status(500).json({ error: 'Внутрішня помилка сервера' });
  }
});

// Route: Onboarding page
app.get('/onboarding', (req, res) => {
  res.sendFile(path.join(__dirname, 'onboarding.html'));
});

// Helper: enrich movies with genre names
async function enrichWithGenres(movies) {
  return Promise.all(movies.map(async (movie) => {
    try {
      const { data: gd } = await supabaseAdmin
        .from('media_genres')
        .select('genres:genre_id(name)')
        .eq('media_id', movie.id);
      const genres = (gd || []).map(g => g.genres?.name).filter(Boolean);
      return { ...movie, genres };
    } catch {
      return { ...movie, genres: [] };
    }
  }));
}

