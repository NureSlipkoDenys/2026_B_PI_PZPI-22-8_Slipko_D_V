-- ================================================================
-- ABSOLUTE CINEMA: Заповнення бази даних фільмами
-- Скопіюйте та виконайте цей запит в Supabase SQL Editor
-- ================================================================

-- 1. Додаємо стандартні жанри (якщо вони ще не створені)
INSERT INTO genres (name)
SELECT name_to_insert
FROM (
  VALUES 
    ('Бойовик'),
    ('Фантастика'),
    ('Драма'),
    ('Комедія'),
    ('Жахи'),
    ('Трилер'),
    ('Пригоди'),
    ('Фентезі'),
    ('Мелодрама'),
    ('Детектив'),
    ('Анімація')
) AS new_genres(name_to_insert)
WHERE NOT EXISTS (
  SELECT 1 FROM genres WHERE name = new_genres.name_to_insert
);

-- 2. Вставка фільмів та прив'язка їх до жанрів

-- Фільм 1: Початок (Inception)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Початок (Inception)', 
    'Професійний злодій, який викрадає корпоративні таємниці за допомогою технології обміну снами, отримує шанс повернути своє колишнє життя.', 
    '2010-07-16', 
    'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&auto=format&fit=crop&q=80', -- красивий кіно-плейсхолдер
    'movie', 
    8.8
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Бойовик', 'Фантастика', 'Трилер');

-- Фільм 2: Темний лицар (The Dark Knight)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Темний лицар (The Dark Knight)', 
    'Коли загроза, відома як Джокер, сіє хаос і безлад у Готемі, Бетмен повинен прийняти один з найбільших психологічних та фізичних викликів.', 
    '2008-07-18', 
    'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=500&auto=format&fit=crop&q=80',
    'movie', 
    9.0
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Бойовик', 'Драма', 'Трилер');

-- Фільм 3: Інтерстеллар (Interstellar)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Інтерстеллар (Interstellar)', 
    'Команда дослідників подорожує крізь червоточину в космосі, намагаючись забезпечити виживання людства.', 
    '2014-11-07', 
    'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.7
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Фантастика', 'Драма', 'Пригоди');

-- Фільм 4: Кримінальне чтиво (Pulp Fiction)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Кримінальне чтиво (Pulp Fiction)', 
    'Життя двох кілерів, боксера, дружини гангстера та двох дрібних грабіжників переплітаються в чотирьох історіях насильства та спокути.', 
    '1994-10-14', 
    'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.9
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Трилер', 'Драма', 'Комедія');

-- Фільм 5: Матриця (The Matrix)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Матриця (The Matrix)', 
    'Комп’ютерний хакер дізнається від таємничих повстанців про справжню природу його реальності та його роль у війні проти її контролерів.', 
    '1999-03-31', 
    'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.7
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Бойовик', 'Фантастика');

-- Фільм 6: Форрест Гамп (Forrest Gump)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Форрест Гамп (Forrest Gump)', 
    'Історія про чоловіка з низьким IQ, який стає свідком та мимохідь учасником найважливіших історичних подій США другої половини XX століття.', 
    '1994-07-06', 
    'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.8
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Драма', 'Мелодрама', 'Комедія');

-- Фільм 7: Володар перснів: Хранителі персня (The Lord of the Rings: The Fellowship of the Ring)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Володар перснів: Хранителі персня', 
    'Хоббіт із Ширу та вісім його супутників вирушають у подорож, щоб знищити Єдиний Перстень та врятувати Середзем’я.', 
    '2001-12-19', 
    'https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.9
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Фентезі', 'Пригоди', 'Драма');

-- Фільм 8: Віднесені примарами (Spirited Away)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Віднесені примарами (Spirited Away)', 
    'Під час переїзду в передмістя 10-річна дівчинка блукає у світі, де правлять боги, відьми та звірі, а люди перетворюються на тварин.', 
    '2001-07-20', 
    'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.6
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Анімація', 'Фентезі', 'Пригоди');

-- Фільм 9: Бійцівський клуб (Fight Club)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Бійцівський клуб (Fight Club)', 
    'Офісний працівник, який страждає на безсоння, і миловар-бунтар створюють підпільний бійцівський клуб, що переростає в щось значно більше.', 
    '1999-10-15', 
    'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.8
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Драма', 'Трилер');

-- Фільм 10: Зелена миля (The Green Mile)
WITH new_media AS (
  INSERT INTO media (title, description, release_date, poster_url, type, imdb_rating)
  VALUES (
    'Зелена миля (The Green Mile)', 
    'Наглядачі федеральної тюрми стикаються з незвичайним ув’язненим, який володіє дивовижним даром зцілення.', 
    '1999-12-10', 
    'https://images.unsplash.com/photo-1542204172-e7052809f852?w=500&auto=format&fit=crop&q=80',
    'movie', 
    8.6
  )
  RETURNING id
)
INSERT INTO media_genres (media_id, genre_id)
SELECT new_media.id, genres.id 
FROM new_media, genres 
WHERE genres.name IN ('Драма', 'Фентезі');
