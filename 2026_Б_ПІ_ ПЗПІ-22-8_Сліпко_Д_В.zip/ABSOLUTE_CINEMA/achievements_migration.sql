-- ============================================================
-- ABSOLUTE CINEMA — Система досягнень і рангів
-- Міграція: achievements_migration.sql
-- ============================================================

-- ============================================================
-- 1. ТАБЛИЦЯ ДОСВІДУ КОРИСТУВАЧІВ (user_xp)
-- Зберігає накопичений XP кожного профілю.
-- Рівень і ранг обчислюються динамічно через VIEW.
-- ============================================================
CREATE TABLE IF NOT EXISTS user_xp (
    user_id   UUID PRIMARY KEY REFERENCES profiles(user_id) ON DELETE CASCADE,
    xp        INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Автоматично створюємо запис xp при реєстрації нового профілю
CREATE OR REPLACE FUNCTION create_user_xp_on_profile_insert()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    INSERT INTO user_xp (user_id, xp)
    VALUES (NEW.user_id, 0)
    ON CONFLICT (user_id) DO NOTHING;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_create_user_xp ON profiles;
CREATE TRIGGER trg_create_user_xp
    AFTER INSERT ON profiles
    FOR EACH ROW EXECUTE FUNCTION create_user_xp_on_profile_insert();

-- Додаємо записи для вже існуючих профілів
INSERT INTO user_xp (user_id, xp)
SELECT user_id, 0 FROM profiles
ON CONFLICT (user_id) DO NOTHING;

-- ============================================================
-- 2. ДОПОМІЖНА ФУНКЦІЯ: обчислення рівня за XP
-- Формула: level = floor(sqrt(xp / 50))
-- Приклади:
--   0 XP    → Рівень 1
--   200 XP  → Рівень 2
--   1250 XP → Рівень 5
--   11250 XP→ Рівень 15
--   45000 XP→ Рівень 30
-- ============================================================
CREATE OR REPLACE FUNCTION get_level_from_xp(p_xp INTEGER)
RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT GREATEST(1, FLOOR(SQRT(p_xp::FLOAT / 50))::INTEGER);
$$;

-- Функція: XP, необхідний для наступного рівня
CREATE OR REPLACE FUNCTION get_xp_for_next_level(p_level INTEGER)
RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT ((p_level + 1) * (p_level + 1) * 50);
$$;

-- ============================================================
-- 3. VIEW: РАНГИ КОРИСТУВАЧІВ (user_ranks)
-- Інші частини застосунку читають ранг звідси.
-- ============================================================
CREATE OR REPLACE VIEW user_ranks AS
SELECT
    p.user_id,
    p.username,
    p.avatar_url,
    COALESCE(x.xp, 0)                              AS xp,
    get_level_from_xp(COALESCE(x.xp, 0))           AS level,
    get_xp_for_next_level(
        get_level_from_xp(COALESCE(x.xp, 0))
    )                                               AS xp_for_next_level,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 100 THEN 'Absolute Cinema'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 75  THEN 'Маестро Екрану'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 50  THEN 'Кіновед'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 30  THEN 'Критик'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15  THEN 'Синефіл'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5   THEN 'Кіноман'
        ELSE                                              'Глядач'
    END                                             AS rank_title,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 100 THEN '🎖️'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 75  THEN '🎭'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 50  THEN '🌟'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 30  THEN '🏆'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15  THEN '🎬'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5   THEN '🍿'
        ELSE                                              '🎞️'
    END                                             AS rank_icon,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 100 THEN '#FFD700'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 75  THEN '#C0392B'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 50  THEN '#8E44AD'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 30  THEN '#2980B9'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15  THEN '#27AE60'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5   THEN '#E67E22'
        ELSE                                              '#7F8C8D'
    END                                             AS rank_color
FROM profiles p
LEFT JOIN user_xp x ON x.user_id = p.user_id;

-- ============================================================
-- 4. ТАБЛИЦЯ ДОСЯГНЕНЬ (achievements) — довідник
-- ============================================================
CREATE TABLE IF NOT EXISTS achievements (
    id          SERIAL PRIMARY KEY,
    code        TEXT NOT NULL UNIQUE,          -- унікальний ідентифікатор для коду
    title       TEXT NOT NULL,                 -- назва
    description TEXT NOT NULL,                 -- опис умови
    icon        TEXT NOT NULL DEFAULT '🏅',    -- емодзі-іконка
    xp_reward   INTEGER NOT NULL DEFAULT 0,    -- скільки XP видати при отриманні
    category    TEXT NOT NULL DEFAULT 'general', -- категорія: reviews | favorites | social | special
    is_hidden   BOOLEAN NOT NULL DEFAULT FALSE  -- приховані досягнення (сюрприз)
);

-- ============================================================
-- 5. ТАБЛИЦЯ ОТРИМАНИХ ДОСЯГНЕНЬ (user_achievements)
-- ============================================================
CREATE TABLE IF NOT EXISTS user_achievements (
    id             SERIAL PRIMARY KEY,
    user_id        UUID NOT NULL REFERENCES profiles(user_id) ON DELETE CASCADE,
    achievement_id INTEGER NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    earned_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (user_id, achievement_id)   -- кожне досягнення видається лише 1 раз
);

CREATE INDEX IF NOT EXISTS idx_user_achievements_user ON user_achievements(user_id);

-- ============================================================
-- 6. ДАНІ: наповнення довідника досягнень
-- ============================================================
INSERT INTO achievements (code, title, description, icon, xp_reward, category, is_hidden) VALUES

-- === РЕЦЕНЗІЇ ===
('first_review',       'Перше слово',            'Напишіть свою першу рецензію',                   '✍️',  30,  'reviews', FALSE),
('review_5',           'Починаючий критик',       'Напишіть 5 рецензій',                            '📝',  75,  'reviews', FALSE),
('review_10',          'Критик',                  'Напишіть 10 рецензій',                           '🖊️', 150, 'reviews', FALSE),
('review_25',          'Досвідчений критик',      'Напишіть 25 рецензій',                           '📰',  300, 'reviews', FALSE),
('review_50',          'Майстер рецензій',        'Напишіть 50 рецензій',                           '📜',  500, 'reviews', FALSE),
('review_100',         'Легенда критики',         'Напишіть 100 рецензій',                          '🏆', 1000, 'reviews', FALSE),
('liked_review_10',    'Популярна думка',         'Отримайте 10 лайків на свої рецензії',           '❤️',  100, 'reviews', FALSE),
('liked_review_50',    'Голос спільноти',         'Отримайте 50 лайків на свої рецензії',           '💫',  300, 'reviews', FALSE),
('liked_review_100',   'Авторитет',               'Отримайте 100 лайків на свої рецензії',          '⭐',  600, 'reviews', FALSE),
('spoiler_master',     'Хранитель секретів',      'Напишіть 10 рецензій без спойлерів',             '🤫',  150, 'reviews', FALSE),

-- === ОБРАНЕ ===
('first_favorite',     'Перша любов',             'Додайте перший фільм в обране',                  '💖',  10,  'favorites', FALSE),
('favorites_10',       'Колекціонер',             'Додайте 10 фільмів в обране',                    '🗂️',  50,  'favorites', FALSE),
('favorites_25',       'Бібліотекар',             'Додайте 25 фільмів в обране',                    '📚',  100, 'favorites', FALSE),
('favorites_50',       'Архіваріус',              'Додайте 50 фільмів в обране',                    '🗃️',  200, 'favorites', FALSE),
('favorites_100',      'Синематека',              'Додайте 100 фільмів в обране',                   '🎥',  400, 'favorites', FALSE),

-- === ПЕРЕГЛЯДИ ===
('first_watch',        'Перший перегляд',         'Додайте перший фільм до історії переглядів',     '👁️',  10,  'favorites', FALSE),
('watched_10',         'Кіноаматор',              'Перегляньте 10 фільмів',                         '🎞️',  80,  'favorites', FALSE),
('watched_50',         'Справжній кіноман',       'Перегляньте 50 фільмів',                         '🍿',  200, 'favorites', FALSE),
('watched_100',        'Кіноголік',               'Перегляньте 100 фільмів',                        '📽️',  400, 'favorites', FALSE),
('watched_250',        'Синефіл',                 'Перегляньте 250 фільмів',                        '🎬',  800, 'favorites', FALSE),

-- === СОЦІАЛЬНЕ ===
('first_discussion',   'Ініціатор',               'Створіть перше обговорення',                     '💬',  20,  'social', FALSE),
('discussion_10',      'Організатор',             'Створіть 10 обговорень',                         '🗣️', 150,  'social', FALSE),
('first_comment',      'Перший коментар',         'Залиште свій перший коментар в обговоренні',     '💭',  10,  'social', FALSE),
('comment_50',         'Активний учасник',        'Залиште 50 коментарів',                          '🔥',  200, 'social', FALSE),
('comment_100',        'Серцевина спільноти',     'Залиште 100 коментарів',                         '🌐',  400, 'social', FALSE),

-- === СПЕЦІАЛЬНІ ===
('early_bird',         'Першовідкривач',          'Зареєструватися одним з перших 100 учасників',   '🐦',  200, 'special', FALSE),
('level_5',            'Досвідчений кіноман',     'Досягніть 5 рівня',                              '🍿',  0,   'special', FALSE),
('level_15',           'Синефіл',                 'Досягніть 15 рівня',                             '🎬',  0,   'special', FALSE),
('level_30',           'Критик',                  'Досягніть 30 рівня',                             '🏆',  0,   'special', FALSE),
('level_50',           'Кіновед',                 'Досягніть 50 рівня',                             '🌟',  0,   'special', FALSE),
('level_75',           'Маестро Екрану',          'Досягніть 75 рівня',                             '🎭',  0,   'special', FALSE),
('level_100',          'Absolute Cinema',         'Досягніть 100 рівня — вищий титул',              '🎖️',  0,   'special', FALSE),
('night_owl',          'Нічна сова',              'Напишіть рецензію після опівночі',               '🦉',  50,  'special', TRUE),   -- приховане!
('comeback',           'Повернення легенди',      'Не заходили 30 днів, а потім повернулися',       '👻',  100, 'special', TRUE),   -- приховане!
('perfectionist',      'Перфекціоніст',           'Поставте оцінку 10/10 та 1/10 одному й тому ж жанру', '🎯', 75, 'special', TRUE) -- приховане!

ON CONFLICT (code) DO NOTHING;

-- ============================================================
-- 7. ДОПОМІЖНА ФУНКЦІЯ: додати XP користувачу
-- Використовується з Edge Functions / тригерів
-- ============================================================
CREATE OR REPLACE FUNCTION add_xp(p_user_id UUID, p_amount INTEGER)
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    INSERT INTO user_xp (user_id, xp, updated_at)
    VALUES (p_user_id, GREATEST(0, p_amount), now())
    ON CONFLICT (user_id) DO UPDATE
        SET xp         = user_xp.xp + GREATEST(0, p_amount),
            updated_at = now();
END;
$$;

-- ============================================================
-- 8. ФУНКЦІЯ: видати досягнення + нарахувати XP-нагороду
-- ============================================================
CREATE OR REPLACE FUNCTION grant_achievement(p_user_id UUID, p_achievement_code TEXT)
RETURNS BOOLEAN LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_achievement achievements%ROWTYPE;
    v_inserted    BOOLEAN := FALSE;
BEGIN
    SELECT * INTO v_achievement
    FROM achievements WHERE code = p_achievement_code;

    IF NOT FOUND THEN
        RETURN FALSE;
    END IF;

    INSERT INTO user_achievements (user_id, achievement_id)
    VALUES (p_user_id, v_achievement.id)
    ON CONFLICT (user_id, achievement_id) DO NOTHING;

    GET DIAGNOSTICS v_inserted = ROW_COUNT;

    -- Нараховуємо XP лише при першій видачі
    IF v_inserted THEN
        PERFORM add_xp(p_user_id, v_achievement.xp_reward);
    END IF;

    RETURN v_inserted;
END;
$$;

-- ============================================================
-- ПЕРЕВІРОЧНИЙ ЗАПИТ (розкоментуй після застосування):
-- SELECT * FROM user_ranks LIMIT 10;
-- SELECT * FROM achievements ORDER BY category, id;
-- ============================================================
