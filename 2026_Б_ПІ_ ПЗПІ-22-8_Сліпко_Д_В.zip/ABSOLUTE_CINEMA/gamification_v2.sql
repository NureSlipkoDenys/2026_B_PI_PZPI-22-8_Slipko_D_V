-- ============================================================
-- ABSOLUTE CINEMA — Gamification v2
-- Повний ребаланс: XP тільки через досягнення, нова формула рівнів
-- Виконувати в Supabase SQL Editor
-- ============================================================

-- ============================================================
-- 1. НОВА ФОРМУЛА РІВНІВ
-- level = FLOOR(SQRT(xp / 25))   → max level 20 при 10 000 XP
-- xp_for_next_level = (level+1)^2 * 25
-- ============================================================
CREATE OR REPLACE FUNCTION get_level_from_xp(p_xp INTEGER)
RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT GREATEST(1, FLOOR(SQRT(GREATEST(p_xp, 0)::FLOAT / 25))::INTEGER);
$$;

CREATE OR REPLACE FUNCTION get_xp_for_next_level(p_level INTEGER)
RETURNS INTEGER LANGUAGE sql IMMUTABLE AS $$
    SELECT ((p_level + 1) * (p_level + 1) * 25);
$$;

-- ============================================================
-- 2. ОНОВЛЕНИЙ VIEW user_ranks (нові пороги рівнів)
-- Рівні рангів скориговані під нову формулу
-- ============================================================
CREATE OR REPLACE VIEW user_ranks AS
SELECT
    p.user_id,
    p.username,
    p.avatar_url,
    COALESCE(x.xp, 0)                              AS xp,
    get_level_from_xp(COALESCE(x.xp, 0))           AS level,
    get_xp_for_next_level(
        get_level_from_xp(COALESCE(x.xp, 0))
    )                                               AS xp_for_next_level,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 19 THEN 'Absolute Cinema'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15 THEN 'Маестро Екрану'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 11 THEN 'Кіновед'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 8  THEN 'Критик'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5  THEN 'Синефіл'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 3  THEN 'Кіноман'
        ELSE                                              'Глядач'
    END                                             AS rank_title,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 19 THEN '🎖️'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15 THEN '🎭'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 11 THEN '🌟'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 8  THEN '🏆'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5  THEN '🎬'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 3  THEN '🍿'
        ELSE                                              '🎞️'
    END                                             AS rank_icon,
    CASE
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 19 THEN '#FFD700'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 15 THEN '#C0392B'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 11 THEN '#8E44AD'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 8  THEN '#2980B9'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 5  THEN '#27AE60'
        WHEN get_level_from_xp(COALESCE(x.xp, 0)) >= 3  THEN '#E67E22'
        ELSE                                              '#7F8C8D'
    END                                             AS rank_color
FROM profiles p
LEFT JOIN user_xp x ON x.user_id = p.user_id;

-- ============================================================
-- 3. РЕБАЛАНС XP ЗА ДОСЯГНЕННЯ
-- Нові значення: achievements дають більше XP, дії — нічого
-- ============================================================
UPDATE achievements SET xp_reward = 75   WHERE code = 'first_review';
UPDATE achievements SET xp_reward = 150  WHERE code = 'review_5';
UPDATE achievements SET xp_reward = 300  WHERE code = 'review_10';
UPDATE achievements SET xp_reward = 600  WHERE code = 'review_25';
UPDATE achievements SET xp_reward = 1000 WHERE code = 'review_50';
UPDATE achievements SET xp_reward = 2000 WHERE code = 'review_100';
UPDATE achievements SET xp_reward = 200  WHERE code = 'spoiler_master';
UPDATE achievements SET xp_reward = 150  WHERE code = 'liked_review_10';
UPDATE achievements SET xp_reward = 400  WHERE code = 'liked_review_50';
UPDATE achievements SET xp_reward = 750  WHERE code = 'liked_review_100';

UPDATE achievements SET xp_reward = 25   WHERE code = 'first_favorite';
UPDATE achievements SET xp_reward = 75   WHERE code = 'favorites_10';
UPDATE achievements SET xp_reward = 150  WHERE code = 'favorites_25';
UPDATE achievements SET xp_reward = 300  WHERE code = 'favorites_50';
UPDATE achievements SET xp_reward = 600  WHERE code = 'favorites_100';

UPDATE achievements SET xp_reward = 25   WHERE code = 'first_watch';
UPDATE achievements SET xp_reward = 75   WHERE code = 'watched_10';
UPDATE achievements SET xp_reward = 200  WHERE code = 'watched_50';
UPDATE achievements SET xp_reward = 400  WHERE code = 'watched_100';
UPDATE achievements SET xp_reward = 800  WHERE code = 'watched_250';

UPDATE achievements SET xp_reward = 50   WHERE code = 'first_discussion';
UPDATE achievements SET xp_reward = 300  WHERE code = 'discussion_10';
UPDATE achievements SET xp_reward = 25   WHERE code = 'first_comment';
UPDATE achievements SET xp_reward = 200  WHERE code = 'comment_50';
UPDATE achievements SET xp_reward = 400  WHERE code = 'comment_100';

UPDATE achievements SET xp_reward = 100  WHERE code = 'night_owl';
UPDATE achievements SET xp_reward = 100  WHERE code = 'comeback';
UPDATE achievements SET xp_reward = 75   WHERE code = 'perfectionist';
UPDATE achievements SET xp_reward = 200  WHERE code = 'early_bird';

-- Level achievements — лише бейдж, мінімум XP
UPDATE achievements SET xp_reward = 0 WHERE code IN ('level_5','level_15','level_30','level_50','level_75','level_100');

-- ============================================================
-- 4. НОВІ ДОСЯГНЕННЯ: стрік відвідувань
-- ============================================================
INSERT INTO achievements (code, title, description, icon, xp_reward, category, is_hidden) VALUES
('regular_visitor',    'Постійний гість',   'Відвідуйте сайт 7 днів поспіль',    '📅', 150, 'special', FALSE),
('regular_visitor_30', 'Відданий фанат',    'Відвідуйте сайт 30 днів поспіль',   '🔥', 500, 'special', FALSE)
ON CONFLICT (code) DO NOTHING;

-- ============================================================
-- 5. ДОДАЄМО ВІДСТЕЖЕННЯ СТРІКУ У user_xp
-- ============================================================
ALTER TABLE user_xp ADD COLUMN IF NOT EXISTS last_login_date  DATE;
ALTER TABLE user_xp ADD COLUMN IF NOT EXISTS current_streak   INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_xp ADD COLUMN IF NOT EXISTS max_streak       INTEGER NOT NULL DEFAULT 0;

-- ============================================================
-- 6. ФУНКЦІЯ: зберегти щоденний логін + перевірити стрік
-- ============================================================
CREATE OR REPLACE FUNCTION record_daily_login(p_user_id UUID)
RETURNS JSONB LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
    v_last_date     DATE;
    v_streak        INTEGER;
    v_today         DATE := CURRENT_DATE;
    v_new_ach_7     BOOLEAN := FALSE;
    v_new_ach_30    BOOLEAN := FALSE;
BEGIN
    SELECT last_login_date, current_streak
    INTO v_last_date, v_streak
    FROM user_xp WHERE user_id = p_user_id;

    IF v_last_date IS NULL THEN
        -- Перший логін
        v_streak := 1;
    ELSIF v_last_date = v_today THEN
        -- Вже логінився сьогодні — нічого не змінюємо
        RETURN jsonb_build_object('streak', v_streak, 'new_achievements', '[]'::jsonb);
    ELSIF v_last_date = v_today - INTERVAL '1 day' THEN
        -- Поспіль — збільшуємо стрік
        v_streak := v_streak + 1;
    ELSE
        -- Пропуск — скидаємо стрік
        v_streak := 1;
    END IF;

    UPDATE user_xp
    SET last_login_date = v_today,
        current_streak  = v_streak,
        max_streak      = GREATEST(max_streak, v_streak),
        updated_at      = now()
    WHERE user_id = p_user_id;

    -- Перевіряємо досягнення стріку
    IF v_streak >= 7 THEN
        v_new_ach_7 := grant_achievement(p_user_id, 'regular_visitor');
    END IF;
    IF v_streak >= 30 THEN
        v_new_ach_30 := grant_achievement(p_user_id, 'regular_visitor_30');
    END IF;

    RETURN jsonb_build_object('streak', v_streak, 'granted_7', v_new_ach_7, 'granted_30', v_new_ach_30);
END;
$$;

-- ============================================================
-- 7. ОНОВЛЮЄМО ТРИГЕРИ: ВИДАЛЯЄМО add_xp за одиночні дії
-- XP нараховується ТІЛЬКИ через grant_achievement (при milestone)
-- ============================================================

-- Тригер рецензій (тільки check, БЕЗ add_xp за дію)
CREATE OR REPLACE FUNCTION trg_xp_on_review_insert()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    PERFORM check_and_grant_achievements(NEW.user_id);
    IF EXTRACT(HOUR FROM (NEW.created_at AT TIME ZONE 'Europe/Kiev')) BETWEEN 0 AND 4 THEN
        PERFORM grant_achievement(NEW.user_id, 'night_owl');
    END IF;
    RETURN NEW;
END;
$$;

-- Тригер лайку рецензії (тільки check для автора, БЕЗ add_xp)
CREATE OR REPLACE FUNCTION trg_xp_on_review_like()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE v_author_id UUID;
BEGIN
    SELECT user_id INTO v_author_id FROM reviews WHERE id = NEW.review_id;
    IF v_author_id IS NOT NULL AND v_author_id <> NEW.user_id THEN
        PERFORM check_and_grant_achievements(v_author_id);
    END IF;
    RETURN NEW;
END;
$$;

-- Тригер обраного (тільки check, БЕЗ add_xp)
CREATE OR REPLACE FUNCTION trg_xp_on_favorite()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    PERFORM check_and_grant_achievements(NEW.user_id);
    RETURN NEW;
END;
$$;

-- Тригер перегляду (тільки check, БЕЗ add_xp)
CREATE OR REPLACE FUNCTION trg_xp_on_watch()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    PERFORM check_and_grant_achievements(NEW.user_id);
    RETURN NEW;
END;
$$;

-- Тригер обговорення (тільки check, БЕЗ add_xp)
CREATE OR REPLACE FUNCTION trg_xp_on_discussion()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF NEW.creator_id IS NOT NULL THEN
        PERFORM check_and_grant_achievements(NEW.creator_id);
    END IF;
    RETURN NEW;
END;
$$;

-- Тригер коментаря (тільки check, БЕЗ add_xp)
CREATE OR REPLACE FUNCTION trg_xp_on_comment()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    IF NEW.user_id IS NOT NULL THEN
        PERFORM check_and_grant_achievements(NEW.user_id);
    END IF;
    RETURN NEW;
END;
$$;

-- ============================================================
-- 8. ПЕРЕРАХУНОК XP ВСІХ ІСНУЮЧИХ КОРИСТУВАЧІВ
-- Скидаємо XP до 0 і перераховуємо через досягнення
-- ============================================================
UPDATE user_xp SET xp = 0, updated_at = now();

DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN SELECT user_id FROM profiles LOOP
        -- Видаляємо всі отримані досягнення щоб перевидати з новим XP
        DELETE FROM user_achievements WHERE user_id = r.user_id;
        -- Перевіряємо і видаємо заново (з новими XP-нагородами)
        PERFORM check_and_grant_achievements(r.user_id);
    END LOOP;
END;
$$;

-- ============================================================
-- Перевірка результату:
-- SELECT username, xp, level, rank_title FROM user_ranks;
-- ============================================================
