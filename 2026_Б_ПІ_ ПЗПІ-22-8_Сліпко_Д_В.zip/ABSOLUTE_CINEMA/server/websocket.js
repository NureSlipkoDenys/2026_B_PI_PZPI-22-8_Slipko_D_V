const WebSocket = require('ws');
const { createClient } = require('@supabase/supabase-js');
const cookieParser = require('cookie-parser');

// Ініціалізація клієнта Supabase
const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_ANON_KEY
);

// Створюємо клієнт Supabase із сервісним ключем для адміністративних операцій
const supabaseAdmin = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
);

// Сховище активних з'єднань
const clients = new Map();

// Ініціалізація WebSocket сервера
function initWebSocket(server) {
    const wss = new WebSocket.Server({
        server,
        path: '/ws/chat',
        verifyClient: (info, callback) => {
            callback(true);
        }
    });

    wss.on('connection', async (ws, req) => {
        console.log('Нове WebSocket з\'єднання');

        // Автентифікація користувача
        ws.on('message', async (message) => {
            try {
                const data = JSON.parse(message);
                console.log('Отримано WebSocket повідомлення:', data);

                if (data.type === 'auth') {
                    const token = data.token;
                    if (!token) {
                        console.log('Токен не знайдено в повідомленні');
                        ws.close(1008, 'Unauthorized');
                        return;
                    }

                    try {
                        // Перевіряємо токен через Supabase
                        const { data: { user }, error } = await supabase.auth.getUser(token);

                        if (error || !user) {
                            console.error('Помилка автентифікації:', error);
                            ws.close(1008, 'Unauthorized');
                            return;
                        }

                        console.log('Користувача успішно автентифіковано:', user.id);

                        // Зберігаємо з'єднання в Map
                        const userId = user.id.toLowerCase();
                        clients.set(userId, {
                            ws,
                            userId
                        });

                        console.log(`Користувач ${userId} підключений до WebSocket`);
                        console.log('Поточні підключені клієнти:', Array.from(clients.keys()));
                    } catch (error) {
                        console.error('Помилка автентифікації:', error);
                        ws.close(1008, 'Unauthorized');
                    }
                } else if (data.type === 'message') {
                    // Перевіряємо, чи автентифікований відправник
                    const sender = Array.from(clients.entries()).find(([id, client]) => client.ws === ws);
                    if (!sender) {
                        console.error('Відправник не автентифікований');
                        return;
                    }

                    console.log('Відправника знайдено:', sender[0]);
                    console.log('Поточні підключені клієнти:', Array.from(clients.keys()));

                    // Отримуємо інформацію про чат
                    const chat = await getChatInfo(data.chat_id);

                    if (!chat) {
                        console.error('Чат не знайдено:', data.chat_id);
                        return;
                    }

                    // Перевіряємо, чи є відправник учасником чату
                    if (chat.user1_id.toLowerCase() !== sender[0] && chat.user2_id.toLowerCase() !== sender[0]) {
                        console.error('Відправник не є учасником чату');
                        return;
                    }

                    // Визначаємо отримувача повідомлення
                    const recipientId = chat.user1_id.toLowerCase() === sender[0] ? chat.user2_id.toLowerCase() : chat.user1_id.toLowerCase();
                    console.log('ID отримувача:', recipientId);

                    // Отримуємо з'єднання отримувача
                    const recipient = clients.get(recipientId);
                    console.log('Знайдено отримувача:', recipient ? 'так' : 'ні');

                    if (recipient) {
                        try {
                            // Надсилаємо повідомлення отримувачу
                            recipient.ws.send(JSON.stringify({
                                type: 'message',
                                chat_id: data.chat_id,
                                content: data.content,
                                sender_id: sender[0],
                                sent_at: data.sent_at || new Date().toISOString()
                            }));
                            console.log(`Повідомлення надіслано користувачу ${recipientId}`);

                            // Надсилаємо підтвердження відправнику
                            ws.send(JSON.stringify({
                                type: 'message_sent',
                                chat_id: data.chat_id,
                                message_id: data.message_id
                            }));
                        } catch (error) {
                            console.error('Помилка при надсиланні повідомлення отримувачу:', error);
                            // Якщо не вдалося надіслати повідомлення, видаляємо з'єднання
                            clients.delete(recipientId);

                            // Надсилаємо помилку відправнику
                            ws.send(JSON.stringify({
                                type: 'message_error',
                                chat_id: data.chat_id,
                                error: 'Не вдалося надіслати повідомлення'
                            }));
                        }
                    } else {
                        console.log(`Отримувач ${recipientId} не підключений до WebSocket`);
                        // Надсилаємо сповіщення відправнику
                        ws.send(JSON.stringify({
                            type: 'message_status',
                            chat_id: data.chat_id,
                            status: 'recipient_offline'
                        }));
                    }
                }
            } catch (error) {
                console.error('Помилка обробки повідомлення:', error);
            }
        });

        // Обробка відключення
        ws.on('close', () => {
            // Видаляємо з'єднання з Map
            for (const [userId, client] of clients.entries()) {
                if (client.ws === ws) {
                    clients.delete(userId);
                    console.log(`Користувач ${userId} відключений від WebSocket`);
                    console.log('Залишені підключені клієнти:', Array.from(clients.keys()));
                    break;
                }
            }
        });

        // Обробка помилок з'єднання
        ws.on('error', (error) => {
            console.error('WebSocket помилка:', error);
            // Видаляємо з'єднання з Map при помилці
            for (const [userId, client] of clients.entries()) {
                if (client.ws === ws) {
                    clients.delete(userId);
                    console.log(`Користувач ${userId} відключений через помилку`);
                    console.log('Залишені підключені клієнти:', Array.from(clients.keys()));
                    break;
                }
            }
        });
    });

    return wss;
}

// Функція для отримання інформації про чат
async function getChatInfo(chatId) {
    try {
        const { data, error } = await supabaseAdmin
            .from('chats')
            .select('*')
            .eq('id', chatId)
            .single();

        if (error) {
            console.error('Помилка отримання інформації про чат:', error);
            return null;
        }

        return data;
    } catch (error) {
        console.error('Помилка отримання інформації про чат:', error);
        return null;
    }
}

// Функція для сповіщення про прочитання повідомлень
function notifyMessageRead(senderId, chatId) {
    if (!senderId) return;
    const sender = clients.get(senderId.toLowerCase());
    if (sender && sender.ws.readyState === WebSocket.OPEN) {
        sender.ws.send(JSON.stringify({
            type: 'message_read',
            chat_id: chatId
        }));
    }
}

module.exports = { initWebSocket, notifyMessageRead }; 