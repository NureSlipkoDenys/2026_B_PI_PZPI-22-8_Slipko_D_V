// Функція для завантаження новинок
async function loadLatestMovies() {
    try {
        const response = await fetch('/api/latest-movies');
        if (!response.ok) {
            throw new Error('Не вдалося завантажити новинки');
        }

        const data = await response.json();
        const movies = data.movies || [];

        // Отримуємо контейнер для новинок
        const latestMoviesTrack = document.getElementById('latestMoviesTrack');
        if (!latestMoviesTrack) return;

        // Очищаємо контейнер
        latestMoviesTrack.innerHTML = '';

        // Додаємо фільми в контейнер
        movies.forEach((movie, index) => {
            const movieCard = document.createElement('div');
            movieCard.className = 'movie-card';
            movieCard.setAttribute('data-index', index);

            // Форматуємо дату релізу
            const releaseDate = movie.release_date ? new Date(movie.release_date) : null;
            const releaseYear = releaseDate ? releaseDate.getFullYear() : '';
            const genreText = movie.genres && movie.genres.length > 0 ? movie.genres.slice(0, 2).join(', ') : '';

            // Рядок 1: рейтинг + рік, рядок 2: жанри — як на сторінці movies.html
            const metaLineParts = [];
            if (movie.imdb_rating) metaLineParts.push(`<span class="movie-card-rating">★ ${movie.imdb_rating}/10</span>`);
            if (releaseYear) metaLineParts.push(`${releaseYear}`);
            const metaLine = metaLineParts.join(' <span class="movie-card-dot">·</span> ');

            movieCard.innerHTML = `
                <div class="movie-card-poster">
                    <img src="${movie.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${movie.title}">
                    <div class="movie-card-overlay">
                        <button class="watch-button">Детальніше</button>
                        <div class="movie-card-meta">
                            ${metaLine ? `<div class="movie-card-meta-line">${metaLine}</div>` : ''}
                            ${genreText ? `<div class="movie-card-meta-line">${genreText}</div>` : ''}
                        </div>
                    </div>
                </div>
                <div class="movie-card-title" title="${movie.title}">${movie.title}</div>
            `;

            // Додаємо обробник кліку для перегляду фільму
            const watchButton = movieCard.querySelector('.watch-button');
            watchButton.addEventListener('click', () => {
                window.location.href = `/movie/${movie.id}`;
            });

            latestMoviesTrack.appendChild(movieCard);
        });

        // Викликаємо ініціалізацію каруселі, якщо є фільми
        try {
            if (typeof window.initLatestMoviesCarousel === 'function' && movies.length > 0) {
                window.initLatestMoviesCarousel();
            }
        } catch (carouselError) {
            console.error('Помилка ініціалізації каруселі:', carouselError);
        }
    } catch (error) {
        console.error('Помилка при завантаженні новинок:', error);
        const latestMoviesTrack = document.getElementById('latestMoviesTrack');
        if (latestMoviesTrack) {
            latestMoviesTrack.innerHTML = `
                <div class="error-container">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Помилка при завантаженні новинок: ${error.message}</p>
                </div>
            `;
        }
    }
}

// Завантажуємо новинки при завантаженні сторінки
document.addEventListener('DOMContentLoaded', loadLatestMovies);

// Видаляємо цю заглушку, щоб не конфліктувала з основною функцією в script.js
// function initLatestMoviesCarousel() {} 