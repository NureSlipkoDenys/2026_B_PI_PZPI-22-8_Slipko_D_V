// particles.js - Анімація геометричних фігур на фоні сторінки профілю

document.addEventListener('DOMContentLoaded', function() {
    initParticlesAnimation();
});

function initParticlesAnimation() {
    // Анімація частинок в основному канвасі
    const canvas = document.getElementById('particles-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Встановлення розмірів canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();

    // Налаштування частинок
    const particles = [];
    const particleCount = 180; // Збільшено кількість частинок
    const minSize = 1;
    const maxSize = 3;
    const repelRadius = 100;
    const repelForce = 0.3;

    // Створення частинок
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            size: Math.random() * (maxSize - minSize) + minSize,
            color: getRandomColor(),
            shape: Math.floor(Math.random() * 3)
        });
    }

    // Функція для генерації випадкового кольору
    function getRandomColor() {
        // Обираємо з палітри жовто-золотистих відтінків
        const colors = [
            `hsla(51, 50%, 70%, ${Math.random() * 0.3 + 0.2})`, // Світлий хакі
            `hsla(43, 74%, 49%, ${Math.random() * 0.3 + 0.2})`, // Золотистий
            `hsla(54, 76%, 60%, ${Math.random() * 0.3 + 0.2})`, // Жовтий
            `hsla(48, 90%, 58%, ${Math.random() * 0.3 + 0.2})` // Гірчичний
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    // Обробник руху миші
    let mouseX = null;
    let mouseY = null;
    
    window.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });
    
    window.addEventListener('mouseout', function() {
        mouseX = null;
        mouseY = null;
    });
    
    // Анімація
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            // Відштовхування від курсора
            if (mouseX !== null && mouseY !== null) {
                const dx = p.x - mouseX;
                const dy = p.y - mouseY;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < repelRadius) {
                    const angle = Math.atan2(dy, dx);
                    const force = (repelRadius - distance) / repelRadius * repelForce;

                    p.vx += Math.cos(angle) * force * 2;
                    p.vy += Math.sin(angle) * force * 2;
                }
            }

            // Рух частинок
            p.x += p.vx;
            p.y += p.vy;

            // Відбиття від меж
            if (p.x < 0 || p.x > canvas.width) p.vx *= -0.8;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -0.8;

            // Обмеження позицій
            p.x = Math.max(0, Math.min(canvas.width, p.x));
            p.y = Math.max(0, Math.min(canvas.height, p.y));

            // Малювання частинок
            ctx.fillStyle = p.color;

            switch (p.shape) {
                case 0: // Коло
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case 1: // Квадрат
                    ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
                    break;
                case 2: // Трикутник
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y - p.size);
                    ctx.lineTo(p.x + p.size, p.y + p.size);
                    ctx.lineTo(p.x - p.size, p.y + p.size);
                    ctx.closePath();
                    ctx.fill();
                    break;
            }
        });

        requestAnimationFrame(animate);
    }

    animate();

    window.addEventListener('resize', function() {
        resizeCanvas();
    });

    // Видалення анімації з модального вікна - залишаємо тільки на основній сторінці
    // Знаходимо і видаляємо canvas з модального вікна
    const modalCanvas = document.getElementById('modal-particles-canvas');
    if (modalCanvas) {
        modalCanvas.remove();
    }
} 