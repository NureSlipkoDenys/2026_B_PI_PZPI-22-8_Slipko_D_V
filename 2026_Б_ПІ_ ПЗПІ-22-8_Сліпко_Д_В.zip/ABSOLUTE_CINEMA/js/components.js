/* components.js - Компоненти UI для ABSOLUTE CINEMA */

// Функція ініціалізації компонентів
function initComponents() {
  // Перевіряємо, чи завантажений хедер
  const headerContainer = document.getElementById('header-container');

  if (headerContainer && !headerContainer.innerHTML.trim()) {
    // Завантажуємо хедер, якщо контейнер порожній
    loadHeader();
  }

  // Обробник скролу для затемнення хедера
  setupScrollEffects();
}

// Функція для обробки скролу та ефектів
function setupScrollEffects() {
  window.addEventListener('scroll', function() {
    const header = document.getElementById('main-header');
    if (header) {
      if (window.scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }
  });
  
  // Запускаємо один раз при завантаженні сторінки для встановлення поточного стану
  const header = document.getElementById('main-header');
  if (header && window.scrollY > 50) {
    header.classList.add('scrolled');
  }
}

// Функція завантаження хедера
async function loadHeader() {
  try {
    const headerContainer = document.getElementById('header-container');
    if (!headerContainer) return;

    console.log('Завантаження хедера...');

    try {
      // Завантажуємо HTML хедера з файлу компонента
      const response = await fetch('/components/header.html');

      // Перевіряємо успішність завантаження
      if (response.ok) {
        const html = await response.text();
        headerContainer.innerHTML = html;
        console.log('Хедер успішно завантажено');
        if (window.initSearch) window.initSearch();
        if (window.initAuthModal) window.initAuthModal();
      } else {
        throw new Error(`Не вдалося завантажити хедер: ${response.status} ${response.statusText}`);
      }
    } catch (fetchError) {
      console.error('Помилка під час завантаження хедера:', fetchError);
      
      // Резервний варіант хедера у разі помилки
      headerContainer.innerHTML = `
        <header id="main-header">
          <div class="header-container">
            <div class="logo">
              <a href="/" id="logo-link">ABSOLUTE CINEMA</a>
            </div>
            <nav class="main-nav">
              <ul>
                <li><a href="/" class="nav-link"><i class="fas fa-home"></i>ГОЛОВНА</a></li>
                <li class="dropdown">
                  <a href="/movies.html"><i class="fas fa-film"></i>ФІЛЬМИ <i class="fas fa-chevron-down"></i></a>
                  <div class="dropdown-content">
                    <a href="/movies.html?genre=Бойовик">БОЙОВИКИ</a>
                    <a href="/movies.html?genre=Комедія">КOMЕДІЇ</a>
                    <a href="/movies.html?genre=Драма">ДРАМИ</a>
                    <a href="/movies.html?genre=Жахи">ЖАХИ</a>
                    <a href="/movies.html?genre=Фантастика">ФАНТАСТИКА</a>
                    <a href="/movies.html?genre=Трилер">ТРИЛЕРИ</a>
                    <a href="/movies.html?genre=Мультфільм">МУЛЬТФІЛЬМИ</a>
                    <a href="/movies.html?genre=Документальний">ДОКУМЕНТАЛЬНІ</a>
                    <a href="/movies.html?genre=Аніме">АНІМЕ</a>
                    <a href="/movies.html?genre=Артхаус">АРТХАУСИ</a>
                    <a href="/movies.html?genre=Детектив">ДЕТЕКТИВИ</a>
                    <a href="/movies.html?genre=Мелодрама">МЕЛОДРАМИ</a>
                  </div>
                </li>
                <li class="dropdown">
                  <a href="/series.html"><i class="fas fa-tv"></i>СЕРІАЛИ <i class="fas fa-chevron-down"></i></a>
                  <div class="dropdown-content">
                    <a href="/series/drama">ДРАМИ</a>
                    <a href="/series/comedy">КОМЕДІЇ</a>
                    <a href="/series/crime">КРИМІНАЛ</a>
                  </div>
                </li>
                <li><a href="/chats.html" class="nav-link"><i class="fas fa-comments"></i>ЧАТИ</a></li>
                <li><a href="/discussions.html" class="nav-link"><i class="fas fa-users"></i>ОБГОВОРЕННЯ</a></li>
                <li><a href="/ratings.html" class="nav-link"><i class="fas fa-star"></i>РЕЙТИНГИ</a></li>
              </ul>
            </nav>
            <div class="header-icons">
              <div class="history-icon" id="history-icon">
                <i class="fas fa-history"></i>
              </div>
              <div class="search-icon" id="search-icon">
                <i class="fas fa-search"></i>
              </div>
              <div class="login-button">
                <a href="/login">ВХІД / РЕЄСТРАЦІЯ</a>
              </div>
            </div>
          </div>
        </header>
        <div class="search-popup" id="search-popup">
          <div class="search-container">
            <input type="text" placeholder="Пошук фільмів...">
          </div>
          <div class="search-results"></div>
        </div>
      `;
      console.log('Завантажено резервний хедер');
      if (window.initSearch) window.initSearch();
      if (window.initAuthModal) window.initAuthModal();
    }

    // Обробники для елементів хедера
    setupHeaderEvents();

    // Якщо користувач авторизований, оновлюємо UI
    if (window.authManager) {
      window.authManager.updateUI();
    }
    // Приховуємо лупу, якщо це movies.html
    hideSearchIconOnMoviesPage();
  } catch (error) {
    console.error('Загальна помилка під час ініціалізації хедера:', error);
  }
}

// Налаштування обробників подій хедера
function setupHeaderEvents() {
  // Обробник мобільного меню
  const mobileMenuButton = document.querySelector('.mobile-menu-button');
  const mainNav = document.querySelector('.main-nav');
  
  if (mobileMenuButton && mainNav) {
    mobileMenuButton.addEventListener('click', () => {
      mainNav.classList.toggle('active');
      mobileMenuButton.classList.toggle('active');
    });
  }
  
  // Обробник для іконки історії
  const historyIcon = document.getElementById('history-icon');
  const historyPopup = document.getElementById('history-popup');
  
  if (historyIcon && historyPopup) {
    historyIcon.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      historyPopup.classList.toggle('active');
    });
    
    // Закриття попапу при кліку поза ним
    document.addEventListener('click', (e) => {
      if (historyPopup && !historyIcon.contains(e.target) && !historyPopup.contains(e.target) && historyPopup.classList.contains('active')) {
        historyPopup.classList.remove('active');
      }
    });
  }
  
  // Пошук ініціалізується в search.js (window.initSearch), щоб не плодити
  // конфліктуючі обробники кліку на тій самій іконці/попапі

  // Обробник активного посилання в меню
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.main-nav a');

  navLinks.forEach(link => {
    // Визначаємо активне посилання за шляхом
    const linkPath = link.getAttribute('href');

    if (currentPath === linkPath ||
        (linkPath !== '/' && currentPath.startsWith(linkPath))) {
      // Прибираємо активний клас з усіх посилань
      navLinks.forEach(l => l.classList.remove('active'));
      // Додаємо активний клас поточному посиланню
      link.classList.add('active');
    }
  });
}

// Після завантаження хедера, приховую лупу, якщо це movies.html
function hideSearchIconOnMoviesPage() {
  if (window.location.pathname.endsWith('/movies.html')) {
    const searchIcon = document.querySelector('.search-icon');
    if (searchIcon) searchIcon.style.display = 'none';
  }
}

// Виклик після завантаження хедера
window.addEventListener('DOMContentLoaded', () => {
  hideSearchIconOnMoviesPage();
});

// Експортуємо функції для використання в інших модулях
window.initComponents = initComponents;
window.loadHeader = loadHeader;

// Ініціалізація компонентів при завантаженні сторінки
document.addEventListener('DOMContentLoaded', initComponents); 