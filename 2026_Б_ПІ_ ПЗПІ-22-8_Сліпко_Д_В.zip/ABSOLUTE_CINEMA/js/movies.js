document.addEventListener('DOMContentLoaded', function() {
  const allMoviesList = document.getElementById('allMoviesList');
  const typeFilter = document.getElementById('typeFilter');
  const sortMovies = document.getElementById('sortMovies');
  const genreFilter = document.getElementById('genreFilter');
  const yearFilter = document.getElementById('yearFilter');
  const resetFilters = document.getElementById('resetFilters');
  const movieSearch = document.getElementById('movieSearch');

  const VISIBLE_ROWS = 2;

  // Підганяє max-height списку під реальну висоту картки, щоб обмеження
  // по рядах не обрізало картки посередині (висота картки залежить від
  // ширини колонки, тому фіксоване число тут не підходить).
  function updateMoviesListMaxHeight() {
    const firstCard = allMoviesList.querySelector('.movies-grid-card');
    if (!firstCard) {
      allMoviesList.style.maxHeight = '';
      return;
    }
    const cardHeight = firstCard.getBoundingClientRect().height;
    const gap = parseFloat(getComputedStyle(allMoviesList).rowGap) || 0;
    allMoviesList.style.maxHeight = (cardHeight * VISIBLE_ROWS + gap * (VISIBLE_ROWS - 1)) + 'px';
  }

  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(updateMoviesListMaxHeight, 150);
  });

  // Зіставлення однини і множини для жанрів
  const genrePluralMap = {
    'Бойовик': 'Бойовики',
    'Комедія': 'Комедії',
    'Драма': 'Драми',
    'Жахи': 'Жахи',
    'Фантастика': 'Фантастика',
    'Трилер': 'Трилери',
    'Мультфільм': 'Мультфільми',
    'Документальний': 'Документальні',
    'Аніме': 'Аніме',
    'Артхаус': 'Артхауси',
    'Детектив': 'Детективи',
    'Мелодрама': 'Мелодрами'
  };

  function updateMoviesTitle() {
    const titleEl = document.querySelector('.movies-page-title');
    if (!titleEl) return;
    const type = typeFilter.value;
    const genre = genreFilter.value;
    const year = yearFilter.value;
    const plural = genrePluralMap[genre] || genre;
    
    let title = '';
    
    if (type === 'latest' && genre !== 'all') {
      title = `Новинки: ${plural}`;
    } else if (type === 'popular' && genre !== 'all') {
      title = `Популярні: ${plural}`;
    } else if (type === 'latest') {
      title = 'Новинки';
    } else if (type === 'popular') {
      title = 'Популярні';
    } else if (genre !== 'all') {
      title = `Усі фільми: ${plural}`;
    } else {
      title = 'Усі фільми';
    }

    // Додаємо рік до заголовка, якщо він обраний
    if (year !== 'all') {
      if (year === 'older') {
        title += ' (до 2015)';
      } else {
        title += ` (${year})`;
      }
    }

    titleEl.textContent = title;
  }

  typeFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });
  sortMovies.addEventListener('change', () => {
    loadAndRenderAllMovies();
  });
  genreFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });
  yearFilter.addEventListener('change', () => {
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });

  // Обробник для пошуку
  let searchTimeout;
  movieSearch.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      updateMoviesTitle();
      loadAndRenderAllMovies();
    }, 300); // Затримка 300мс для оптимізації
  });

  // Обробник для кнопки скидання фільтрів
  resetFilters.addEventListener('click', () => {
    // Скидаємо всі фільтри до значень за замовчуванням
    typeFilter.value = 'all';
    sortMovies.value = 'default';
    genreFilter.value = 'all';
    yearFilter.value = 'all';
    movieSearch.value = ''; // Очищаємо поле пошуку

    // Очищаємо URL від параметрів фільтрації
    const url = new URL(window.location.href);
    url.search = '';
    window.history.pushState({}, '', url);

    // Оновлюємо заголовок і список фільмів
    updateMoviesTitle();
    loadAndRenderAllMovies();
  });

  // Встановлюємо фільтри з query-параметрів
  function setFiltersFromQuery() {
    const params = new URLSearchParams(window.location.search);
    const sort = params.get('sort');
    // Нове: підтримка ?sort=latest і ?sort=popular для автоматичного вибору фільтра
    if (sort === 'latest') {
      typeFilter.value = 'latest';
    } else if (sort === 'popular') {
      typeFilter.value = 'popular';
    }
    const type = params.get('type');
    const genre = params.get('genre');
    const year = params.get('year');
    const search = params.get('search');
    if (type && (type === 'popular' || type === 'latest' || type === 'all')) {
      typeFilter.value = type;
    }
    if (sort && (sort === 'default' || sort === 'year_desc' || sort === 'year_asc' || sort === 'rating_desc' || sort === 'rating_asc')) {
      sortMovies.value = sort;
    }
    if (genre && genreFilter.querySelector(`option[value="${genre}"]`)) {
      genreFilter.value = genre;
    }
    if (year && yearFilter.querySelector(`option[value="${year}"]`)) {
      yearFilter.value = year;
    }
    if (search) {
      movieSearch.value = search;
    }
  }

  setFiltersFromQuery();
  updateMoviesTitle();
  loadAndRenderAllMovies();

  async function loadAndRenderAllMovies() {
    allMoviesList.style.maxHeight = '';
    allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Завантаження...</div>';
    let movies = [];
    try {
      const res = await fetch('/api/high-rated-movies');
      if (res.ok) {
        const data = await res.json();
        movies = data.movies || [];
      } else {
        allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
        return;
      }
    } catch {
      allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
      return;
    }

    // Фільтрація за типом
    const type = typeFilter.value;
    const sort = sortMovies.value;
    const genre = genreFilter.value;
    const year = yearFilter.value;
    const searchQuery = movieSearch.value.toLowerCase().trim();

    // Пошук за назвою
    if (searchQuery) {
      movies = movies.filter(m => m.title.toLowerCase().includes(searchQuery));
    }

    // Фільтрація за типом
    if (type === 'latest') {
      // Новинки: фільми за останній місяць
      const now = new Date();
      const monthAgo = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      movies = movies.filter(m => {
        if (!m.release_date) return false;
        const d = new Date(m.release_date);
        return d >= monthAgo && d <= now;
      });
    } else if (type === 'popular') {
      // Популярні: тільки з рейтингом >= 8
      movies = movies.filter(m => Number(m.imdb_rating) >= 8);
    }

    // Сортування
    if (sort === 'year_desc') {
      // Сортування за роком (нові спочатку)
      movies.sort((a,b) => {
        const yearA = a.release_date ? new Date(a.release_date).getFullYear() : 0;
        const yearB = b.release_date ? new Date(b.release_date).getFullYear() : 0;
        return yearB - yearA;
      });
    } else if (sort === 'year_asc') {
      // Сортування за роком (старі спочатку)
      movies.sort((a,b) => {
        const yearA = a.release_date ? new Date(a.release_date).getFullYear() : 0;
        const yearB = b.release_date ? new Date(b.release_date).getFullYear() : 0;
        return yearA - yearB;
      });
    } else if (sort === 'rating_desc') {
      // Сортування за рейтингом (високий спочатку)
      movies.sort((a,b) => (b.imdb_rating||0)-(a.imdb_rating||0));
    } else if (sort === 'rating_asc') {
      // Сортування за рейтингом (низький спочатку)
      movies.sort((a,b) => (a.imdb_rating||0)-(b.imdb_rating||0));
    }

    // Фільтрація за жанром
    if (genre !== 'all') {
      movies = movies.filter(m => (m.genres||[]).includes(genre));
    }

    // Фільтрація за роком
    if (year !== 'all') {
      movies = movies.filter(m => {
        if (!m.release_date) return false;
        const movieYear = new Date(m.release_date).getFullYear();
        if (year === 'older') {
          return movieYear < 2015;
        }
        return movieYear === parseInt(year);
      });
    }

    // Оновлюємо URL з параметрами пошуку
    const url = new URL(window.location.href);
    if (searchQuery) {
      url.searchParams.set('search', searchQuery);
    } else {
      url.searchParams.delete('search');
    }
    window.history.pushState({}, '', url);

    // Рендер
    if (!movies.length) {
      allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Фільмів не знайдено</div>';
      return;
    }
    allMoviesList.innerHTML = movies.map(m => {
      const rating = (m.imdb_rating !== undefined && m.imdb_rating !== null && m.imdb_rating !== '' && m.imdb_rating !== '?') ? m.imdb_rating : null;
      const year = (m.release_date || '').slice(0, 4);
      const genreText = (m.genres || []).slice(0, 2).join(', ');
      const poster = m.poster_url || 'https://via.placeholder.com/200x300?text=No+Poster';

      // Рядок 1: оцінка + рік, рядок 2: жанри
      const line1Parts = [];
      if (rating !== null) line1Parts.push(`<span class="movies-grid-card-rating">★ ${rating}/10</span>`);
      if (year) line1Parts.push(`<span>${year}</span>`);
      const line1 = line1Parts.join(' <span class="movies-grid-card-dot">·</span> ');

      const metaHtml = (line1 || genreText) ? `
        ${line1 ? `<div class="movies-grid-card-line">${line1}</div>` : ''}
        ${genreText ? `<div class="movies-grid-card-line">${genreText}</div>` : ''}
      ` : '';

      return `
        <div class="movies-grid-card" onclick="window.location='/movie/${m.id}'">
          <div class="movies-grid-card-poster">
            <img src="${poster}" alt="${m.title}" loading="lazy">
            <div class="movies-grid-card-overlay">
              <button class="movies-grid-card-btn">ДЕТАЛЬНІШЕ</button>
              ${metaHtml ? `<div class="movies-grid-card-meta">${metaHtml}</div>` : ''}
            </div>
          </div>
          <div class="movies-grid-card-title">${m.title}</div>
        </div>
      `;
    }).join('');
    updateMoviesListMaxHeight();
  }

  // Оновлення UI авторизації після завантаження хедера
  if (window.authManager && typeof window.authManager.updateUI === 'function') {
    window.authManager.updateUI();
  }
}); 