/* script.js – основний JavaScript файл проєкту ABSOLUTE CINEMA */

document.addEventListener('DOMContentLoaded', function() {
    // ======= ЗАГАЛЬНІ ФУНКЦІЇ ТА ОБРОБНИКИ =======

    // Зміна фону шапки при прокрутці
    window.addEventListener('scroll', function() {
        const header = document.getElementById('main-header');
        if (window.scrollY > 20) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Обробка кліку по логотипу
    const logoLink = document.getElementById('logo-link');
    if (logoLink) {
        logoLink.addEventListener('click', function(e) {
            if (window.location.pathname === '/') {
                e.preventDefault();
            }
        });
    }
    
    // ======= ФУНКЦІЇ ПОШУКУ =======

    // Покращений код для пошукового попапу
    const searchIcon = document.getElementById('search-icon');
    const searchPopup = document.getElementById('search-popup');
    
    if (searchIcon && searchPopup) {
        searchIcon.addEventListener('click', function() {
            searchPopup.classList.toggle('active');
            searchIcon.classList.toggle('active');
            
            // Автофокус на поле пошуку, коли відкривається попап
            if (searchPopup.classList.contains('active')) {
                setTimeout(() => {
                    const searchInput = searchPopup.querySelector('input');
                    if (searchInput) searchInput.focus();
                }, 300); // Затримка відповідає часу анімації
            }
        });

        // Закриття пошуку при кліку поза попапом
        document.addEventListener('click', function(e) {
            if (!searchIcon.contains(e.target) && !searchPopup.contains(e.target)) {
                searchPopup.classList.remove('active');
                searchIcon.classList.remove('active');
            }
        });
        
        // Закриття пошуку при натисканні Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && searchPopup.classList.contains('active')) {
                searchPopup.classList.remove('active');
                searchIcon.classList.remove('active');
            }
        });
        
        // Обробка вводу в пошуку
        const searchInput = document.querySelector('.search-container input');
        const searchResults = document.querySelector('.search-results');
        
        if (searchInput && searchResults) {
            // Демонстраційні дані для пошуку
            const movieData = [
                { title: 'Початок', year: 2010, image: 'https://via.placeholder.com/50x70' },
                { title: 'Втеча з Шоушенка', year: 1994, image: 'https://via.placeholder.com/50x70' },
                { title: 'Темний лицар', year: 2008, image: 'https://via.placeholder.com/50x70' },
                { title: 'Кримінальне чтиво', year: 1994, image: 'https://via.placeholder.com/50x70' },
                { title: 'Бійцівський клуб', year: 1999, image: 'https://via.placeholder.com/50x70' }
            ];
            
            searchInput.addEventListener('input', function() {
                const searchTerm = searchInput.value.toLowerCase().trim();
                
                if (searchTerm.length > 2) {
                    // Фільтрація результатів
                    const filteredMovies = movieData.filter(movie =>
                        movie.title.toLowerCase().includes(searchTerm)
                    );

                    // Відображення результатів
                    displaySearchResults(filteredMovies);
                } else {
                    searchResults.innerHTML = '';
                }
            });
            
            function displaySearchResults(movies) {
                searchResults.innerHTML = '';
                
                if (movies.length === 0) {
                    searchResults.innerHTML = '<div class="no-results">Фільми не знайдені</div>';
                    return;
                }
                
                movies.forEach(movie => {
                    const resultItem = document.createElement('div');
                    resultItem.className = 'search-result-item';
                    
                    resultItem.innerHTML = `
                        <div class="search-result-img">
                            <img src="${movie.image}" alt="${movie.title}">
                        </div>
                        <div class="search-result-info">
                            <div class="search-result-title">${movie.title}</div>
                            <div class="search-result-year">${movie.year}</div>
                        </div>
                    `;
                    
                    resultItem.addEventListener('click', () => {
                        // Перенаправлення на сторінку фільму (заглушка)
                        console.log(`Перехід до фільму: ${movie.title}`);
                    });
                    
                    searchResults.appendChild(resultItem);
                });
            }
        }
    }
    
    // ======= ОБРОБКА ІСТОРІЇ ПЕРЕГЛЯДІВ =======

    // Код для обробки значка історії переглядів
    const historyIcon = document.getElementById('history-icon');
    const historyPopup = document.getElementById('history-popup');
    
    if (historyIcon && historyPopup) {
        // Відкриття/закриття спливаючого вікна історії при наведенні
        historyIcon.addEventListener('mouseenter', function() {
            historyPopup.classList.add('active');
        });
        
        historyIcon.addEventListener('mouseleave', function(e) {
            // Затримка перед закриттям, щоб користувач міг перевести курсор на вікно
            setTimeout(() => {
                if (!historyPopup.matches(':hover')) {
                    historyPopup.classList.remove('active');
                }
            }, 300);
        });
        
        historyPopup.addEventListener('mouseleave', function() {
            historyPopup.classList.remove('active');
        });
        
        // Обробник для очищення історії
        const historyClearBtn = document.querySelector('.history-clear-btn');
        if (historyClearBtn) {
            historyClearBtn.addEventListener('click', function() {
                const historyItems = document.querySelector('.history-items');
                historyItems.innerHTML = '<p style="text-align: center; color: #777; padding: 20px;">Історія переглядів порожня</p>';
                this.style.display = 'none';
            });
        }
        
        // Обробка кліків по елементах історії
        const historyItems = document.querySelectorAll('.history-item');
        historyItems.forEach(item => {
            item.addEventListener('click', function() {
                const title = this.querySelector('.history-item-title').textContent;
                console.log(`Перехід до фільму: ${title}`);
                // Тут можна додати код для переходу на сторінку фільму
            });
        });
    }

    // ======= ФУНКЦІЇ ДЛЯ РОЗДІЛУ ОБГОВОРЕНЬ =======
    async function loadDiscussionsPreview() {
        const grid = document.querySelector('.discussions-grid');
        if (!grid) return;
        grid.innerHTML = '<div class="loading-discussions">Завантаження обговорень...</div>';
        try {
            const res = await fetch('/api/discussions/preview');
            const data = await res.json();
            if (!data.discussions || !Array.isArray(data.discussions)) throw new Error('Некоректна відповідь сервера');
            if (data.discussions.length === 0) {
                grid.innerHTML = '<div class="no-discussions">Обговорень поки немає</div>';
                return;
            }
            grid.innerHTML = '';
            data.discussions.forEach(discussion => {
                const card = document.createElement('div');
                card.className = 'discussion-card';
                card.innerHTML = `
                    <h3 class="discussion-title">${discussion.title}</h3>
                    <div class="discussion-description">${discussion.description ? discussion.description : ''}</div>
                    <div class="discussion-author">
                        <img src="${discussion.author.avatar_url}" alt="Автор">
                        <span>${discussion.author.username}</span>
                    </div>
                    <div class="comments-count">
                        <i class="fas fa-comments"></i> ${discussion.comments_count} коментар${discussion.comments_count === 1 ? '': (discussion.comments_count < 5 ? 'і' : 'ів')}
                    </div>
                `;
                grid.appendChild(card);
            });
            // Анімація карток при завантаженні (залишаємо як було)
            const discussionCards = document.querySelectorAll('.discussion-card');
            discussionCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 + index * 100);
            });
        } catch (e) {
            grid.innerHTML = '<div class="error-discussions">Помилка завантаження обговорень</div>';
        }
    }

    function initDiscussionsSection() {
        const grid = document.querySelector('.discussions-grid');
        if (!grid) return;

        grid.addEventListener('click', function(e) {
            const card = e.target.closest('.discussion-card');
            if (card && e.button === 0) {
                window.location.href = '/discussions.html';
            }
        });

        // Анімація карток при завантаженні
        const discussionCards = grid.querySelectorAll('.discussion-card');
        discussionCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100 + index * 100);
        });
    }

    // ======= ІНІЦІАЛІЗАЦІЯ ВСІХ КОМПОНЕНТІВ =======
    // Ініціалізація слайдера: спочатку підвантажуємо актуальні прем'єри з БД
    // (поки йде запит — показуємо skeleton-заглушки), і лише потім ставимо
    // безкінечну карусель на вже готовий контент (вона клонує слайди один раз
    // при ініціалізації, тому виклик має бути рівно один — після завантаження).
    loadHeroCarouselMovies().finally(initInfiniteCarousel);

    // Ініціалізація блоку Новинки
    initLatestMoviesCarousel();

    // Ініціалізація блоку популярних фільмів
    initPopularMoviesCarousel();

    // Ініціалізація розділу обговорень
    loadDiscussionsPreview();
    initDiscussionsSection();

    // Ініціалізація анімацій
    initScrollAnimations();

    // Ініціалізація модального вікна авторизації
    initAuthModal();

    // Ініціалізація анімації часток
    initParticlesAnimation();

    // === МОДАЛЬНЕ ВІКНО ВСІХ ФІЛЬМІВ ===
    const allMoviesBtn = document.querySelector('button, .all-movies-btn, .all-movies-link, .all-movies-cta, .all-movies-show-btn, .all-movies-show');
    const allMoviesModal = document.getElementById('all-movies-modal');
    const closeAllMoviesModal = document.getElementById('closeAllMoviesModal');
    const allMoviesList = document.getElementById('allMoviesList');
    const sortMovies = document.getElementById('sortMovies');
    const genreFilter = document.getElementById('genreFilter');

    // Знайти кнопку 'усі' за текстом
    let usiBtn = null;
    document.querySelectorAll('button, .all-movies-btn').forEach(btn => {
        if (btn.textContent.trim() === 'УСІ' || btn.textContent.trim() === 'усі') usiBtn = btn;
    });

    if (usiBtn && allMoviesModal) {
        usiBtn.addEventListener('click', function() {
            allMoviesModal.style.display = 'flex';
            loadAndRenderAllMovies();
        });
    }
    if (closeAllMoviesModal) {
        closeAllMoviesModal.addEventListener('click', function() {
            allMoviesModal.style.display = 'none';
        });
    }
    // Закриття по кліку поза вікном
    if (allMoviesModal) {
        allMoviesModal.addEventListener('click', function(e) {
            if (e.target === allMoviesModal) allMoviesModal.style.display = 'none';
        });
    }
    // Фільтрація та сортування (тільки для модалки "всі фільми" на головній —
    // на сторінці movies.html ці ж id належать іншому списку, який керує movies.js)
    if (sortMovies && genreFilter && allMoviesModal) {
        sortMovies.addEventListener('change', loadAndRenderAllMovies);
        genreFilter.addEventListener('change', loadAndRenderAllMovies);
    }

    async function loadAndRenderAllMovies() {
        allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Завантаження...</div>';
        // Отримуємо всі фільми (приклад: з API або window.allMovies)
        let movies = [];
        try {
            // Спробуємо отримати з API
            const res = await fetch('/api/movies?minRating=8');
            if (res.ok) {
                movies = await res.json();
            } else {
                allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
                return;
            }
        } catch {
            allMoviesList.innerHTML = '<div style="color:#e74c3c;text-align:center;padding:30px;">Не вдалося завантажити фільми</div>';
            return;
        }
        // Фільтрація за жанром
        const genre = genreFilter.value;
        if (genre !== 'all') {
            movies = movies.filter(m => (m.genres||[]).map(g=>g.toLowerCase()).includes(genre));
        }
        // Сортування
        if (sortMovies.value === 'latest') {
            movies.sort((a,b) => (b.release_year||0)-(a.release_year||0));
        } else {
            movies.sort((a,b) => (b.imdb_rating||0)-(a.imdb_rating||0));
        }
        // Рендер
        if (!movies.length) {
            allMoviesList.innerHTML = '<div style="color:#ffe066;text-align:center;padding:30px;">Фільмів не знайдено</div>';
            return;
        }
        allMoviesList.innerHTML = movies.map(m => `
            <div class="home-modal-card" onclick="window.location='/movie/${m.id}'">
                <img src="${m.poster_url||'https://via.placeholder.com/150x225?text=No+Poster'}" alt="${m.title}">
                <div class="home-modal-card-title">${m.title}</div>
                <div class="home-modal-card-rating">IMDB: ${m.imdb_rating||'—'}</div>
                <div class="home-modal-card-genres">${(m.genres||[]).join(', ')}</div>
                <div class="home-modal-card-year" style="color:#aaa;font-size:12px;">${m.release_year||''}</div>
            </div>
        `).join('');
    }

    // ======= Перехід по кнопках 'УСІ' в новинках і популярних =======
    const latestViewAllBtn = document.querySelector('.latest-view-all');
    if (latestViewAllBtn) {
        latestViewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '/movies.html?sort=latest';
        });
    }
    const popularViewAllBtn = document.querySelector('.popular-view-all');
    if (popularViewAllBtn) {
        popularViewAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '/movies.html?sort=popular';
        });
    }

    // === Перехід по кнопці "Дивитися фільми" на сторінку movies ===
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            window.location.href = '/movies.html';
        });
    }
});

// Нижче будуть йти всі винесені функції

// ======= ФУНКЦІЇ ДЛЯ СЛАЙДЕРА ТА КАРУСЕЛІ =======

// Функція ініціалізації головного слайдера
function initInfiniteCarousel() {
    const carouselTrack = document.getElementById('carouselTrack');
    if (!carouselTrack) return;
    
    const slides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
    const indicators = document.querySelectorAll('.indicator');
    const prevButton = document.getElementById('prevSlide');
    const nextButton = document.getElementById('nextSlide');
    
    let currentIndex = 0;
    let slideInterval;
    const slideDelay = 5000;
    let isResizing = false;
    
    // Клонуємо перший і останній слайди для створення ефекту нескінченності
    const firstSlideClone = slides[0].cloneNode(true);
    const lastSlideClone = slides[slides.length - 1].cloneNode(true);

    // Додаємо клони на початок і кінець каруселі
    carouselTrack.appendChild(firstSlideClone);
    carouselTrack.insertBefore(lastSlideClone, carouselTrack.firstChild);

    // Встановлюємо активний слайд з урахуванням клонів (починаємо з першого реального слайда)
    currentIndex = 1;

    function setActiveSlide(index, withAnimation = true) {
        // Захист від встановлення некоректного індексу
        if (index < 0 || index > slides.length + 1) {
            return;
        }

        // Оновлюємо класи для всіх слайдів
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
        allSlides.forEach(slide => slide.classList.remove('active'));
        
        if (allSlides[index]) {
            allSlides[index].classList.add('active');
        }
        
        // Визначаємо реальний індекс для індикаторів (без урахування клонів)
        const realIndex = index - 1;
        // Обробляємо випадки з клонами
        const indicatorIndex = realIndex < 0 ? slides.length - 1 :
                               realIndex >= slides.length ? 0 : realIndex;

        // Оновлюємо індикатори
        indicators.forEach(ind => ind.classList.remove('active'));
        indicators[indicatorIndex].classList.add('active');

        // Перераховуємо розміри слайдів, якщо вікно було змінено
        if (isResizing) {
            centerCarouselTrack();
            isResizing = false;
        }

        // Переміщуємо карусель з анімацією або без
        const slideWidth = allSlides[0].offsetWidth;
        
        if (!withAnimation) {
            carouselTrack.style.transition = 'none';
        } else {
            carouselTrack.style.transition = 'transform 0.5s ease-out';
        }
        
        carouselTrack.style.transform = `translateX(-${index * slideWidth}px)`;
        currentIndex = index;
        resetSlideTimer();
    }
    
    function handleTransitionEnd() {
        // Якщо дійшли до клону останнього слайда або першого слайда
        if (currentIndex === 0 || currentIndex === slides.length + 1) {
            // Вимикаємо ВСІ анімації для слайдів і контейнера
            const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));

            // Додаємо спеціальний клас для вимкнення анімацій
            document.body.classList.add('freeze-animations');
            carouselTrack.classList.add('no-transition');
            allSlides.forEach(slide => slide.classList.add('no-transition'));

            // Переміщуємося до потрібного слайда
            const targetIndex = (currentIndex === 0) ? slides.length : 1;
            setActiveSlide(targetIndex, false);

            // Додаємо невелику затримку перед поверненням анімацій
            setTimeout(() => {
                document.body.classList.remove('freeze-animations');
                carouselTrack.classList.remove('no-transition');
                allSlides.forEach(slide => slide.classList.remove('no-transition'));
            }, 50);
        }
    }
    
    function nextSlide() {
        setActiveSlide(currentIndex + 1);
    }
    
    function prevSlide() {
        setActiveSlide(currentIndex - 1);
    }
    
    function resetSlideTimer() {
        clearInterval(slideInterval);
        slideInterval = setInterval(nextSlide, slideDelay);
    }
    
    // Центруємо слайди у вікні перегляду з урахуванням всіх розмірів
    function centerCarouselTrack() {
        const windowWidth = window.innerWidth;
        const containerWidth = document.querySelector('.carousel-container').offsetWidth;
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));

        // Отримуємо актуальну ширину слайда
        const slideWidth = allSlides[0].offsetWidth;

        // Розраховуємо відступ, щоб центрувати слайди
        const offset = (containerWidth - slideWidth) / 2;

        // Застосовуємо відступи і оновлюємо позицію активного слайда
        carouselTrack.style.paddingLeft = `${offset}px`;
        carouselTrack.style.paddingRight = `${offset}px`;

        // Оновлюємо позицію каруселі без анімації
        carouselTrack.style.transition = 'none';
        carouselTrack.style.transform = `translateX(-${currentIndex * slideWidth}px)`;

        // Форсуємо перекомпонування (reflow)
        carouselTrack.offsetHeight;
    }

    // Дебаунсинг-функція для відстеження зміни розміру вікна
    function debounce(func, delay) {
        let timeoutId;
        return function() {
            const context = this;
            const args = arguments;
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => {
                func.apply(context, args);
            }, delay);
        };
    }
    
    // Обробник зміни розміру вікна з дебаунсингом
    const handleResize = debounce(() => {
        isResizing = true;

        // Тимчасово вимикаємо переходи
        const allSlides = Array.from(carouselTrack.querySelectorAll('.carousel-slide'));
        carouselTrack.classList.add('no-transition');
        allSlides.forEach(slide => slide.classList.add('no-transition'));

        // Оновлюємо позиції та розміри
        centerCarouselTrack();

        // Чекаємо завершення операцій зміни розміру
        setTimeout(() => {
            // Повертаємо переходи і оновлюємо активний слайд
            carouselTrack.classList.remove('no-transition');
            allSlides.forEach(slide => slide.classList.remove('no-transition'));
            setActiveSlide(currentIndex, false);
        }, 50);
    }, 100);

    // Ініціалізація
    centerCarouselTrack();
    // Починаємо з першого оригінального слайда (враховуючи клон на початку)
    setActiveSlide(1, false);

    // Обробники подій
    carouselTrack.addEventListener('transitionend', handleTransitionEnd);
    prevButton.addEventListener('click', prevSlide);
    nextButton.addEventListener('click', nextSlide);

    // Обробники для індикаторів
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            // Індекс + 1 через клон на початку
            setActiveSlide(index + 1);
        });
    });

    // Покращений обробник зміни розміру вікна
    window.addEventListener('resize', handleResize);

    // Контроль автопрокрутки
    const sliderContainer = document.querySelector('.carousel-container');
    sliderContainer.addEventListener('mouseenter', () => clearInterval(slideInterval));
    sliderContainer.addEventListener('mouseleave', resetSlideTimer);
}

// Завантажує найновіші фільми (за датою виходу) з БД і підставляє їх у
// банер-карусель замість статичних слайдів. Зовнішній вигляд слайдів
// (розмітка/класи .carousel-slide/.slide-image/.slide-content/.premiere-badge/
// .slide-info) лишається тим самим — змінюється лише джерело даних.
// Поки триває запит, показуємо skeleton-заглушки на місці слайдів з фільмами.
function escapeHtmlForCarousel(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

async function loadHeroCarouselMovies() {
    const track = document.getElementById('carouselTrack');
    const indicatorsContainer = document.querySelector('.slider-indicators');
    if (!track) return;

    const introSlide = track.querySelector('.carousel-slide.intro-slide');
    const staticMovieSlides = Array.from(track.querySelectorAll('.carousel-slide:not(.intro-slide)'));
    const skeletonCount = staticMovieSlides.length || 4;

    function renderIndicators(movieCount) {
        if (!indicatorsContainer) return;
        const total = (introSlide ? 1 : 0) + movieCount;
        indicatorsContainer.innerHTML = Array.from({ length: total }, (_, i) =>
            `<span class="indicator${i === 0 ? ' active' : ''}"></span>`
        ).join('');
    }

    // Skeleton-заглушки на час завантаження
    staticMovieSlides.forEach(slide => slide.remove());
    const skeletonSlides = Array.from({ length: skeletonCount }, () => {
        const slide = document.createElement('div');
        slide.className = 'carousel-slide skeleton-slide';
        slide.innerHTML = `
            <div class="slide-image skeleton-shimmer"></div>
            <div class="slide-content">
                <div class="skeleton-badge skeleton-shimmer"></div>
                <div class="slide-info">
                    <div class="skeleton-line skeleton-title skeleton-shimmer"></div>
                    <div class="skeleton-line skeleton-rating skeleton-shimmer"></div>
                    <div class="skeleton-line skeleton-meta skeleton-shimmer"></div>
                </div>
            </div>
        `;
        track.appendChild(slide);
        return slide;
    });

    try {
        const response = await fetch('/api/latest-movies?limit=5');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        const movies = data.movies || [];

        skeletonSlides.forEach(slide => slide.remove());

        if (movies.length === 0) {
            // Немає даних — повертаємо статичні слайди, які зняли вище
            staticMovieSlides.forEach(slide => track.appendChild(slide));
            renderIndicators(staticMovieSlides.length);
            return;
        }

        movies.forEach(movie => {
            const releaseYear = movie.release_date ? new Date(movie.release_date).getFullYear() : '';
            const genres = movie.genres && movie.genres.length > 0 ? movie.genres.slice(0, 2).join(', ') : '';
            const metaParts = [releaseYear, genres].filter(Boolean).join(', ');
            const rating = movie.imdb_rating ? Number(movie.imdb_rating).toFixed(1) : '—';

            const slide = document.createElement('div');
            slide.className = 'carousel-slide';
            slide.innerHTML = `
                <div class="slide-image">
                    <img src="${movie.poster_url || 'https://via.placeholder.com/1200x600?text=Немає+зображення'}" alt="${escapeHtmlForCarousel(movie.title)}">
                </div>
                <div class="slide-content">
                    <div class="premiere-badge">Прем'єра</div>
                    <div class="slide-info">
                        <h2>${escapeHtmlForCarousel(movie.title)}</h2>
                        <div class="rating"><span class="star">★</span> ${rating}/10</div>
                        ${metaParts ? `<p>${escapeHtmlForCarousel(metaParts)}</p>` : ''}
                    </div>
                </div>
            `;
            track.appendChild(slide);
        });

        renderIndicators(movies.length);
    } catch (err) {
        console.error('Помилка завантаження прем\'єр для банера:', err);
        skeletonSlides.forEach(slide => slide.remove());
        // Фолбек — лишаємо статичні слайди, які зняли перед запитом
        staticMovieSlides.forEach(slide => track.appendChild(slide));
        renderIndicators(staticMovieSlides.length);
    }
}

// Функція для ініціалізації каруселі останніх фільмів
window.initLatestMoviesCarousel = function() {
    const container = document.getElementById('latestMoviesContainer');
    if (!container) return;
    
    const track = document.getElementById('latestMoviesTrack');
    const cards = Array.from(track.querySelectorAll('.movie-card'));
    
    if (!cards || cards.length === 0) {
        console.warn('Немає карток фільмів для ініціалізації каруселі');
        return;
    }

    const prevBtn = document.getElementById('latestPrevMovie');
    const nextBtn = document.getElementById('latestNextMovie');
    const progressBar = document.getElementById('latestProgressBar');
    
    let position = 0;
    let cardsPerView = getCardsPerView();
    let cardWidth = cards[0].offsetWidth + 20; // ширина картки + margin
    let maxPosition = Math.max(0, cards.length - cardsPerView);
    const scrollStep = 2; // Збільшуємо до 2 карток для прокрутки за раз
    let autoScrollInterval;

    // Центруємо картки
    function centerCardsContainer() {
        const containerWidth = document.querySelector('.movies-carousel-container').offsetWidth;
        const totalCardsWidth = cardsPerView * cardWidth;
        const marginOffset = (containerWidth - totalCardsWidth) / 2;
        
        if (marginOffset > 0) {
            track.style.marginLeft = `${marginOffset}px`;
        } else {
            track.style.marginLeft = '0';
        }
    }
    
    // Функція для визначення кількості видимих карток
    function getCardsPerView() {
        const width = window.innerWidth;
        if (width >= 1400) return 6;
        if (width >= 1200) return 5;
        if (width >= 992) return 4;
        if (width >= 768) return 3;
        if (width >= 576) return 2;
        return 1;
    }

    // Оновлюємо прогрес-бар
    function updateProgressBar() {
        const maxSteps = Math.max(1, Math.floor(maxPosition / scrollStep));
        const currentStep = Math.min(maxSteps, Math.floor(position / scrollStep));
        const progress = (currentStep / maxSteps) * 100;
        progressBar.style.width = `${progress}%`;
    }

    // Функція переміщення каруселі
    function moveCarousel(newPosition) {
        // Обмежуємо позицію
        position = Math.max(0, Math.min(newPosition, maxPosition));
        track.style.transform = `translateX(-${position * cardWidth}px)`;
        updateProgressBar();
    }

    // Обробники кнопок навігації
    nextBtn.addEventListener('click', () => {
        // Перевіряємо, чи не досягли ми останнього слайда
        if (position + scrollStep > maxPosition) {
            // Якщо залишилось менше карток ніж scrollStep, показуємо залишок
            if (position < maxPosition) {
                moveCarousel(maxPosition);
            } else {
                // Якщо досягли кінця, повертаємося на початок з плавною анімацією
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            }
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position + scrollStep);
        }
    });

    prevBtn.addEventListener('click', () => {
        if (position - scrollStep < 0) {
            // Якщо досягли початку, переміщуємося до початку
            moveCarousel(0);
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position - scrollStep);
        }
    });

    // Автоматична прокрутка
    function startAutoScroll() {
        autoScrollInterval = setInterval(() => {
            if (position + scrollStep > maxPosition) {
                // Якщо досягли кінця, повертаємося на початок
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            } else {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(position + scrollStep);
            }
        }, 5000);
    }
    
    function resetAutoScroll() {
        clearInterval(autoScrollInterval);
        startAutoScroll();
    }
    
    function stopAutoScroll() {
        clearInterval(autoScrollInterval);
    }
    
    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);

    // Обробник зміни розміру вікна
    window.addEventListener('resize', () => {
        // Перераховуємо параметри каруселі
        cardsPerView = getCardsPerView();
        cardWidth = cards[0].offsetWidth + 20;
        maxPosition = cards.length - cardsPerView;

        // Оновлюємо позицію
        moveCarousel(Math.min(position, maxPosition));

        // Центруємо картки
        centerCardsContainer();
    });

    // Додаємо підтримку свайпів для мобільних пристроїв
    let touchStartX = 0;
    let touchEndX = 0;

    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, { passive: true });

    function handleSwipe() {
        const swipeThreshold = 50; // Мінімальна відстань для свайпа

        if (touchStartX - touchEndX > swipeThreshold) {
            // Свайп вліво - наступний слайд
            if (position + scrollStep > maxPosition) {
                // Якщо залишилось менше карток ніж scrollStep, показуємо залишок
                if (position < maxPosition) {
                    moveCarousel(maxPosition);
                } else {
                    // Якщо досягли кінця, повертаємося на початок
                    moveCarousel(0);
                }
            } else {
                moveCarousel(position + scrollStep);
            }
            resetAutoScroll();
        } else if (touchEndX - touchStartX > swipeThreshold) {
            // Свайп вправо - попередній слайд
            if (position - scrollStep < 0) {
                moveCarousel(0);
            } else {
                moveCarousel(position - scrollStep);
            }
            resetAutoScroll();
        }
    }

    // Ініціалізація
    centerCardsContainer();
    moveCarousel(0);
    startAutoScroll();
}

// Функція для ініціалізації каруселі популярних фільмів
window.initPopularMoviesCarousel = function() {
    const container = document.getElementById('popularMoviesContainer');
    if (!container) return;
    
    const track = document.getElementById('popularMoviesTrack');
    const cards = Array.from(track.querySelectorAll('.popular-movie-card'));
    
    if (!cards || cards.length === 0) {
        console.warn('Немає карток фільмів для ініціалізації каруселі популярних фільмів');
        return;
    }

    const prevBtn = document.getElementById('popularPrevMovie');
    const nextBtn = document.getElementById('popularNextMovie');
    const progressBar = document.getElementById('popularProgressBar');
    
    let position = 0;
    let cardsPerView = getPopularCardsPerView();
    let cardWidth = cards[0].offsetWidth + 24; // ширина картки + margin
    let maxPosition = Math.max(0, cards.length - cardsPerView);
    const scrollStep = 2; // Кількість карток для прокрутки за раз
    let autoScrollInterval;

    // Функція для визначення кількості видимих карток
    // Збільшуємо кількість карток у ряду, оскільки вони тепер горизонтальні
    function getPopularCardsPerView() {
        const width = window.innerWidth;
        if (width >= 1200) return 4;
        if (width >= 992) return 3;
        if (width >= 768) return 2;
        return 1;
    }

    // Центруємо картки
    function centerCardsContainer() {
        const containerWidth = container.offsetWidth;
        const totalCardsWidth = cardsPerView * cardWidth;
        const marginOffset = (containerWidth - totalCardsWidth) / 2;
        
        if (marginOffset > 0) {
            track.style.marginLeft = `${marginOffset}px`;
        } else {
            track.style.marginLeft = '0';
        }
    }
    
    // Оновлюємо прогрес-бар
    function updateProgressBar() {
        const maxSteps = Math.max(1, Math.floor(maxPosition / scrollStep));
        const currentStep = Math.min(maxSteps, Math.floor(position / scrollStep));
        const progress = (currentStep / maxSteps) * 100;
        progressBar.style.width = `${progress}%`;
    }

    // Функція переміщення каруселі
    function moveCarousel(newPosition) {
        // Обмежуємо позицію
        position = Math.max(0, Math.min(newPosition, maxPosition));
        track.style.transform = `translateX(-${position * cardWidth}px)`;
        updateProgressBar();
    }

    // Обробники кнопок навігації
    nextBtn.addEventListener('click', () => {
        // Перевіряємо, чи не досягли ми останнього слайда
        if (position + scrollStep > maxPosition) {
            // Якщо залишилось менше карток ніж scrollStep, показуємо залишок
            if (position < maxPosition) {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(maxPosition);
            } else {
                // Якщо досягли кінця, повертаємося на початок з плавною анімацією
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            }
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position + scrollStep);
        }
    });

    prevBtn.addEventListener('click', () => {
        if (position - scrollStep < 0) {
            moveCarousel(0);
        } else {
            track.style.transition = 'transform 0.3s ease';
            moveCarousel(position - scrollStep);
        }
    });

    // Автоматична прокрутка
    function startAutoScroll() {
        autoScrollInterval = setInterval(() => {
            if (position + scrollStep > maxPosition) {
                // Якщо досягли кінця, повертаємося на початок
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(0);
            } else {
                track.style.transition = 'transform 0.3s ease';
                moveCarousel(position + scrollStep);
            }
        }, 6000);
    }
    
    function resetAutoScroll() {
        clearInterval(autoScrollInterval);
        startAutoScroll();
    }
    
    function stopAutoScroll() {
        clearInterval(autoScrollInterval);
    }
    
    // Обробник зміни розміру вікна
    window.addEventListener('resize', () => {
        // Перераховуємо параметри каруселі
        cardsPerView = getPopularCardsPerView();
        cardWidth = cards[0].offsetWidth + 24;
        maxPosition = cards.length - cardsPerView;

        // Оновлюємо позицію
        moveCarousel(Math.min(position, maxPosition));

        // Центруємо картки
        centerCardsContainer();
    });

    // Обробники наведення миші
    container.addEventListener('mouseenter', stopAutoScroll);
    container.addEventListener('mouseleave', startAutoScroll);

    // Додаємо підтримку свайпів для мобільних пристроїв
    let touchStartX = 0;
    let touchEndX = 0;

    track.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    track.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, { passive: true });

    function handleSwipe() {
        const swipeThreshold = 50; // Мінімальна відстань для свайпа

        if (touchStartX - touchEndX > swipeThreshold) {
            // Свайп вліво - наступний слайд
            if (position + scrollStep > maxPosition) {
                if (position < maxPosition) {
                    moveCarousel(maxPosition);
                } else {
                    moveCarousel(0);
                }
            } else {
                moveCarousel(position + scrollStep);
            }
            resetAutoScroll();
        } else if (touchEndX - touchStartX > swipeThreshold) {
            // Свайп вправо - попередній слайд
            if (position - scrollStep < 0) {
                moveCarousel(0);
            } else {
                moveCarousel(position - scrollStep);
            }
            resetAutoScroll();
        }
    }

    // Ініціалізація
    centerCardsContainer();
    moveCarousel(0);
    startAutoScroll();
}

// ======= ФУНКЦІЇ ДЛЯ МОДАЛЬНОГО ВІКНА АВТОРИЗАЦІЇ =======

function initAuthModal() {
    const loginButton = document.querySelector('.login-button a');
    const authModal = document.getElementById('auth-modal');
    
    if (!loginButton || !authModal) return;
    
    const modalClose = document.querySelector('.modal-close');
    const modalOverlay = document.querySelector('.modal-overlay');
    const modalTabs = document.querySelectorAll('.modal-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const resetPasswordForm = document.getElementById('reset-password-form');
    const forgotPasswordLink = document.querySelector('.forgot-password');
    const backToLoginLink = document.getElementById('back-to-login');
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    // Відкриття модального вікна при кліку на кнопку Входу/Реєстрації
    loginButton.addEventListener('click', function(e) {
        e.preventDefault();
        authModal.classList.add('active');
        document.body.style.overflow = 'hidden'; // Блокуємо прокрутку сторінки
    });

    // Закриття модального вікна при кліку на хрестик або затемнену область
    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalOverlay) modalOverlay.addEventListener('click', closeModal);

    // Перемикання між вкладками Вхід/Реєстрація
    modalTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Прибираємо активний клас у всіх вкладок
            modalTabs.forEach(t => t.classList.remove('active'));
            // Додаємо активний клас клікнутій вкладці
            this.classList.add('active');

            // Приховуємо форму відновлення пароля
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');

            // Перемикання між формами
            const tabType = this.getAttribute('data-tab');
            if (tabType === 'login') {
                if (loginForm) loginForm.classList.add('active');
                if (registerForm) registerForm.classList.remove('active');
            } else {
                if (registerForm) registerForm.classList.add('active');
                if (loginForm) loginForm.classList.remove('active');
            }
        });
    });
    
    // Перехід до форми відновлення пароля
    if (forgotPasswordLink && resetPasswordForm) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            if (loginForm) loginForm.classList.remove('active');
            if (registerForm) registerForm.classList.remove('active');
            resetPasswordForm.classList.add('active');

            // Прибираємо активний клас з вкладок
            modalTabs.forEach(t => t.classList.remove('active'));
        });
    }

    // Повернення до форми входу з форми відновлення пароля
    if (backToLoginLink && loginForm) {
        backToLoginLink.addEventListener('click', function(e) {
            e.preventDefault();
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');
            loginForm.classList.add('active');

            // Активуємо вкладку входу
            if (modalTabs[0]) modalTabs[0].classList.add('active');
        });
    }

    // Функція закриття модального вікна
    function closeModal() {
        authModal.classList.remove('active');
        document.body.style.overflow = ''; // Відновлюємо прокрутку сторінки

        // Затримка перед скиданням форм
        setTimeout(() => {
            // Скидання всіх форм у вихідний стан
            if (resetPasswordForm) resetPasswordForm.classList.remove('active');
            if (registerForm) registerForm.classList.remove('active');
            if (loginForm) loginForm.classList.add('active');

            // Скидання вкладок
            modalTabs.forEach((t, index) => {
                if (index === 0) {
                    t.classList.add('active');
                } else {
                    t.classList.remove('active');
                }
            });

            // Очищення полів форм
            const formInputs = authModal.querySelectorAll('input');
            formInputs.forEach(input => {
                if (input.type !== 'checkbox') {
                    input.value = '';
                } else {
                    input.checked = false;
                }
            });
        }, 300);
    }
    
    // Закриття модального вікна при натисканні Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && authModal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // Перемикання видимості пароля
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordField = this.previousElementSibling;
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                this.classList.remove('fa-eye');
                this.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                this.classList.remove('fa-eye-slash');
                this.classList.add('fa-eye');
            }
        });
    });
    
    // Запобігання відправці форм (для демонстрації)
    const authSubmitButtons = document.querySelectorAll('.auth-submit');
    authSubmitButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            // Тут можна додати валідацію форм і відправку даних на сервер
            let message = '';
            
            if (loginForm && loginForm.classList.contains('active')) {
                message = 'Виконується вхід...';
            } else if (registerForm && registerForm.classList.contains('active')) {
                message = 'Реєстрація користувача...';
            } else if (resetPasswordForm && resetPasswordForm.classList.contains('active')) {
                message = 'Відправка інструкцій для відновлення пароля...';
                
                // Імітація успішної відправки
                setTimeout(() => {
                    alert('Інструкції з відновлення пароля відправлені на вказаний email');
                    closeModal();
                }, 1000);
            }
            
            console.log(message);
        });
    });
}

// ======= ФУНКЦІЇ ДЛЯ АНІМАЦІЇ СКРОЛУ =======

function initScrollAnimations() {
    // Знаходимо всі елементи для анімації, прибираємо виняток для latestMoviesContainer
    const animateElements = document.querySelectorAll('.animate-on-scroll:not(.section-header h2)');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate');
                
                // Якщо це контейнер з картками
                if (entry.target.id === 'latestMoviesContainer' ||
                    entry.target.id === 'popularMoviesContainer') {

                    // Знаходимо всі картки всередині контейнера
                    let cards;
                    if (entry.target.id === 'latestMoviesContainer') {
                        cards = entry.target.querySelectorAll('.movie-card');
                    } else {
                        cards = entry.target.querySelectorAll('.popular-movie-card');
                    }

                    // Анімуємо кожну картку із затримкою
                    cards.forEach((card, index) => {
                        card.style.setProperty('--card-index', index);
                    });
                }
            }
        });
    }, { 
        threshold: 0.1
    });
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
    
    // Окремо обробляємо заголовки секцій
    const sectionHeaders = document.querySelectorAll('.section-header h2');
    sectionHeaders.forEach(header => {
        header.classList.add('animate');
    });
}

// ======= ФУНКЦІЇ ДЛЯ АНІМАЦІЇ ЧАСТОК =======

function initParticlesAnimation() {
    // Анімація часток в основному канвасі
    const canvas = document.getElementById('particles-canvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Встановлення розмірів canvas
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();

    // Налаштування часток
    const particles = [];
    const particleCount = 150;
    const minSize = 1;
    const maxSize = 3;
    const repelRadius = 100;
    const repelForce = 0.3;

    // Створення часток
    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            size: Math.random() * (maxSize - minSize) + minSize,
            color: `hsla(${Math.random() * 30 + 30}, 80%, 75%, ${Math.random() * 0.3 + 0.2})`,
            shape: Math.floor(Math.random() * 3)
        });
    }
    
    // Обробник руху миші
    let mouseX = null;
    let mouseY = null;

    window.addEventListener('mousemove', function(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    window.addEventListener('mouseout', function() {
        mouseX = null;
        mouseY = null;
    });

    // Анімація
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach(p => {
            // Відштовхування від курсора
            if (mouseX !== null && mouseY !== null) {
                const dx = p.x - mouseX;
                const dy = p.y - mouseY;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < repelRadius) {
                    const angle = Math.atan2(dy, dx);
                    const force = (repelRadius - distance) / repelRadius * repelForce;
                    
                    p.vx += Math.cos(angle) * force * 2;
                    p.vy += Math.sin(angle) * force * 2;
                }
            }
            
            // Рух часток
            p.x += p.vx;
            p.y += p.vy;

            // Відбиття від меж
            if (p.x < 0 || p.x > canvas.width) p.vx *= -0.8;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -0.8;

            // Обмеження позицій
            p.x = Math.max(0, Math.min(canvas.width, p.x));
            p.y = Math.max(0, Math.min(canvas.height, p.y));

            // Малювання часток
            ctx.fillStyle = p.color;

            switch (p.shape) {
                case 0: // Коло
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                    ctx.fill();
                    break;
                case 1: // Квадрат
                    ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
                    break;
                case 2: // Трикутник
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y - p.size);
                    ctx.lineTo(p.x + p.size, p.y + p.size);
                    ctx.lineTo(p.x - p.size, p.y + p.size);
                    ctx.closePath();
                    ctx.fill();
                    break;
            }
        });
        
        requestAnimationFrame(animate);
    }
    
    animate();
    
    window.addEventListener('resize', function() {
        resizeCanvas();
    });
    
    // Анімація часток у футері
    const footerCanvas = document.getElementById('footer-particles');
    if (footerCanvas) {
        const footerCtx = footerCanvas.getContext('2d');

        footerCanvas.width = footerCanvas.parentElement.offsetWidth;
        footerCanvas.height = footerCanvas.parentElement.offsetHeight;

        // Налаштування часток у футері
        const footerParticles = [];
        const footerParticleCount = 25;
        const footerParticleMaxSize = 2;

        // Створення часток у футері
        for (let i = 0; i < footerParticleCount; i++) {
            footerParticles.push({
                x: Math.random() * footerCanvas.width,
                y: Math.random() * footerCanvas.height,
                size: Math.random() * footerParticleMaxSize + 0.5,
                speedX: Math.random() * 0.3 - 0.15,
                speedY: Math.random() * 0.3 - 0.15,
                opacity: Math.random() * 0.3 + 0.1
            });
        }
        
        // Анімація часток у футері
        function animateFooterParticles() {
            footerCtx.clearRect(0, 0, footerCanvas.width, footerCanvas.height);

            footerParticles.forEach(particle => {
                // Оновлення позиції
                particle.x += particle.speedX;
                particle.y += particle.speedY;

                // Перевірка меж
                if (particle.x < 0 || particle.x > footerCanvas.width) {
                    particle.speedX = -particle.speedX;
                }
                if (particle.y < 0 || particle.y > footerCanvas.height) {
                    particle.speedY = -particle.speedY;
                }

                // Відрисовка частки
                footerCtx.beginPath();
                footerCtx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                footerCtx.fillStyle = `rgba(245, 197, 6, ${particle.opacity})`;
                footerCtx.fill();
            });

            requestAnimationFrame(animateFooterParticles);
        }

        // Запуск анімації у футері
        animateFooterParticles();

        // Оновлення розміру канваса при зміні розміру вікна
        window.addEventListener('resize', () => {
            footerCanvas.width = footerCanvas.parentElement.offsetWidth;
            footerCanvas.height = footerCanvas.parentElement.offsetHeight;
        });
    }
} 