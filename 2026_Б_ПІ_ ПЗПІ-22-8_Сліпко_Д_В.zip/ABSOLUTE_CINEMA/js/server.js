// Обробляємо статичні файли
app.use(express.static(path.join(__dirname))); 