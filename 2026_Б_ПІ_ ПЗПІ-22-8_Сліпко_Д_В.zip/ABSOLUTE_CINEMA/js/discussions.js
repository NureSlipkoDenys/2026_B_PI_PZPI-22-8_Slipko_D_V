let discussions = [];
let currentSort = 'popular';
let currentPage = 1;
const pageSize = 8;
let filteredDiscussions = [];
let selectedDiscussion = null;
let replyTo = null;
let myDiscussionsMode = false;
let currentUserId = null;

// DOM елементи
const featuredBlock = document.getElementById('featured-discussion');
const listBlock = document.getElementById('discussions-list');
const searchInput = document.getElementById('discussion-search');
const filterBtn = document.getElementById('filter-btn');
const filterDropdown = document.getElementById('filter-dropdown');
const paginationInfo = document.getElementById('pagination-info');
const prevPageBtn = document.getElementById('prev-page');
const nextPageBtn = document.getElementById('next-page');
const createBtn = document.getElementById('create-discussion-btn');
const createModal = document.getElementById('create-discussion-modal');
const closeCreateModal = document.getElementById('close-create-modal');
const createForm = document.getElementById('create-discussion-form');
const previewBlock = document.getElementById('discussion-preview');
const addCommentForm = document.getElementById('add-comment-form');

// --- Завантаження обговорень ---
async function loadDiscussions() {
    try {
        // Отримуємо всі обговорення з сервера
        const res = await fetch('/api/discussions/all');
        const data = await res.json();
        discussions = Array.isArray(data.discussions) ? data.discussions : [];
        applyFiltersAndRender();
    } catch (e) {
        featuredBlock.innerHTML = '<div class="error">Помилка завантаження обговорень</div>';
        listBlock.innerHTML = '';
    }
}

// Отримання userId авторизованого користувача (під час завантаження)
async function fetchCurrentUserId() {
    if (window.authManager && window.authManager.currentUser) {
        currentUserId = window.authManager.currentUser.user_id || window.authManager.currentUser.id;
    } else {
        try {
            const res = await fetch('/api/auth/status', { credentials: 'include' });
            const data = await res.json();
            currentUserId = data?.user?.user_id || data?.user?.id;
        } catch {}
    }
}

// --- Фільтрація, пошук, сортування ---
function applyFiltersAndRender() {
    let arr = [...discussions];
    // Пошук
    const q = (searchInput.value || '').toLowerCase();
    if (q) {
        arr = arr.filter(d => d.title.toLowerCase().includes(q) || (d.description && d.description.toLowerCase().includes(q)));
    }
    // Фільтр "Мої обговорення"
    if (myDiscussionsMode && currentUserId) {
        arr = arr.filter(d => d.author && (d.author.user_id === currentUserId || d.author.id === currentUserId));
    }
    // Сортування
    if (currentSort === 'popular') {
        arr.sort((a, b) => (b.comments_count || 0) - (a.comments_count || 0));
    } else {
        arr.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }
    filteredDiscussions = arr;
    // Пагінація
    renderPagination();
    renderList();
    renderFeatured();
}

function renderPagination() {
    const total = filteredDiscussions.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    if (currentPage > totalPages) currentPage = totalPages;
    paginationInfo.textContent = `${currentPage} / ${totalPages}`;
    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = currentPage === totalPages;
    if (filteredDiscussions.length <= pageSize) {
      nextPageBtn.style.display = 'none';
      prevPageBtn.style.display = 'none';
      paginationInfo.style.display = 'none';
    } else {
      nextPageBtn.style.display = '';
      prevPageBtn.style.display = '';
      paginationInfo.style.display = '';
    }
}

function renderList() {
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const arr = filteredDiscussions.slice(start, end);
    listBlock.innerHTML = '';
    arr.forEach(discussion => {
        // Обмеження довжини тексту
        const maxTitleLength = 40;
        const maxDescLength = 70;
        let title = discussion.title;
        let description = discussion.description || '';
        if (title.length > maxTitleLength) {
            title = title.slice(0, maxTitleLength - 1) + '...';
        }
        if (description.length > maxDescLength) {
            description = description.slice(0, maxDescLength - 1) + '...';
        }
        const card = document.createElement('div');
        card.className = 'discussion-list-card';
        // Кнопка видалення тільки для своїх обговорень
        const isOwn = currentUserId && (discussion.author.user_id === currentUserId || discussion.author.id === currentUserId);
        const deleteBtn = isOwn ? `<button class="delete-discussion-btn" data-id="${discussion.id}" title="Видалити обговорення" style="position:absolute;top:7px;right:7px;background:none;border:none;color:#888;font-size:1.1em;opacity:0.5;cursor:pointer;padding:2px 6px;z-index:2;transition:opacity 0.2s;">&times;</button>` : '';
        card.innerHTML = `
            <div style="position:relative;">
                ${deleteBtn}
                <div class="discussion-list-title">${title}</div>
                <div class="discussion-list-description" style="min-height:48px;">${description}</div>
                <div class="discussion-list-meta-bottom">
                    <span class="discussion-list-author"><img src="${discussion.author.avatar_url}" alt="">${discussion.author.username}</span>
                    <span class="discussion-list-date">${new Date(discussion.created_at).toLocaleDateString()}</span>
                    <span class="discussion-list-comments"><i class="fas fa-comments"></i> ${discussion.comments_count}</span>
                </div>
            </div>
        `;
        card.addEventListener('click', (e) => {
            // Не реагувати на клік по кнопці видалення
            if (e.target.classList.contains('delete-discussion-btn')) return;
            selectedDiscussion = discussion;
            window.scrollTo({ top: 0, behavior: 'smooth' });
            renderFeatured();
        });
        listBlock.appendChild(card);
    });
    // --- Додаю порожні картки для завершення ряду ---
    const gridColumns = getGridColumnsCount();
    const remainder = arr.length % gridColumns;
    if (remainder !== 0 && arr.length > 0) {
        for (let i = 0; i < gridColumns - remainder; i++) {
            const emptyCard = document.createElement('div');
            emptyCard.className = 'discussion-list-card discussion-list-card-empty';
            emptyCard.style.visibility = 'hidden';
            emptyCard.style.pointerEvents = 'none';
            listBlock.appendChild(emptyCard);
        }
    }
    // Обробники видалення обговорення
    document.querySelectorAll('.delete-discussion-btn').forEach(btn => {
        btn.onclick = async (e) => {
            e.stopPropagation();
            const discussionId = btn.dataset.id;
            if (!confirm('Ви дійсно хочете видалити це обговорення?')) return;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            try {
                const response = await fetch(`/api/discussions/${discussionId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                if (response.ok) {
                    await loadDiscussions();
                } else {
                    btn.disabled = false;
                    btn.innerHTML = '&times;';
                    alert('Помилка при видаленні обговорення');
                }
            } catch {
                btn.disabled = false;
                btn.innerHTML = '&times;';
                alert('Помилка при видаленні обговорення');
            }
        };
    });
}

// --- Функція для визначення кількості колонок у гриді ---
function getGridColumnsCount() {
    // За замовчуванням 4, але можна обчислити з CSS
    if (window.innerWidth <= 768) return 1;
    if (window.innerWidth <= 1200) return 2;
    return 4;
}

function renderFeatured() {
    let discussion = selectedDiscussion;
    if (!discussion && filteredDiscussions.length > 0) {
        discussion = filteredDiscussions[0];
    }
    const detailsBlock = document.getElementById('featured-discussion-details');
    const commentsBlock = document.getElementById('featured-discussion-comments');
    if (!discussion) {
        if (detailsBlock) detailsBlock.innerHTML = '<div class="no-featured">Обговорень не знайдено</div>';
        if (commentsBlock) commentsBlock.innerHTML = '';
        return;
    }
    if (detailsBlock) {
        detailsBlock.innerHTML = `
            <div style="display:flex;flex-direction:column;width:100%;align-items:flex-start;">
                <div class="featured-title" style="font-size:2.2em;font-weight:700;color:#fff;margin-bottom:10px;width:100%;">${discussion.title}</div>
                <div class="featured-description" style="font-size:1.3em;color:#ccc;margin-bottom:18px;width:100%;">${discussion.description || ''}</div>
            </div>
            <div class="featured-meta-row" style="display:flex;align-items:center;gap:32px;font-size:1.1em;color:#ffd600;margin-top:18px;">
                <div class="featured-author" style="display:flex;align-items:center;gap:8px;">
                    <img src="${discussion.author.avatar_url}" alt="" style="width:32px;height:32px;border-radius:50%;object-fit:cover;"> ${discussion.author.username}
                </div>
                <div class="featured-comments-count" style="display:flex;align-items:center;gap:6px;color:#ffd600;">
                    <i class="fas fa-comments"></i> ${discussion.comments_count} коментар${discussion.comments_count === 1 ? '' : (discussion.comments_count < 5 ? 'і' : 'ів')}
                </div>
                <div class="featured-date" style="color:#fff;font-size:0.98em;">${new Date(discussion.created_at).toLocaleString()}</div>
            </div>
        `;
    }
    if (commentsBlock) {
        commentsBlock.innerHTML = '<div class="featured-comments-list" id="featured-comments-list"></div>';
    }
    loadComments(discussion.id);
}

function renderReplyInfo() {
    const formBlock = document.querySelector('.add-comment-form-block');
    let info = document.getElementById('reply-info');
    if (replyTo) {
        if (!info) {
            info = document.createElement('div');
            info.id = 'reply-info';
            info.style = 'background:#23232b;color:#ffd600;padding:6px 12px;border-radius:6px;margin-bottom:8px;display:flex;align-items:center;gap:10px;';
            formBlock.insertBefore(info, formBlock.firstChild);
        }
        info.innerHTML = `Відповідь для <b>@${replyTo.username}</b> <button id="cancel-reply" class="cancel-reply-btn" style="margin-left:10px;">Скасувати</button>`;
        document.getElementById('cancel-reply').onclick = () => { replyTo = null; renderReplyInfo(); };
    } else if (info) {
        info.remove();
    }
}

// --- Групування коментарів у гілки (верхній рівень + відповіді) ---
function buildCommentThreads(comments) {
    const byId = {};
    comments.forEach(c => { byId[c.id] = c; });

    function findRootId(c) {
        let cur = c;
        const seen = new Set();
        while (cur.parent_id && byId[cur.parent_id] && !seen.has(cur.id)) {
            seen.add(cur.id);
            cur = byId[cur.parent_id];
        }
        return cur.id;
    }

    const topLevel = [];
    const repliesByRoot = {};
    comments.forEach(c => {
        // Немає батька або батько видалений — коментар стає коренем своєї гілки
        if (!c.parent_id || !byId[c.parent_id]) {
            topLevel.push(c);
            return;
        }
        const rootId = findRootId(c);
        if (rootId === c.id) {
            topLevel.push(c);
        } else {
            if (!repliesByRoot[rootId]) repliesByRoot[rootId] = [];
            repliesByRoot[rootId].push(c);
        }
    });

    // Сортування строго за датою: верхній рівень — нові зверху, відповіді в межах гілки — у хронологічному порядку
    topLevel.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    Object.keys(repliesByRoot).forEach(rootId => {
        repliesByRoot[rootId].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    });

    return { topLevel, repliesByRoot, byId };
}

function renderCommentItem(c, currentUserId, byId, rootId, isReply) {
    let replyLink = '';
    if (isReply && c.parent_id && c.parent_id !== rootId) {
        if (byId[c.parent_id]) {
            replyLink = `<a href="#" class="reply-link" data-reply="${c.parent_id}">у відповідь @${byId[c.parent_id].author.username}</a><br>`;
        } else {
            replyLink = `<span class="reply-deleted-label">у відповідь (коментар видалено)</span><br>`;
        }
    }
    const isOwn = currentUserId && c.user_id === currentUserId;
    const deleteBtn = isOwn ? `<button class="delete-comment-btn" data-id="${c.id}" style="margin-left:10px;background:#c0392b;color:#fff;border:none;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:0.95em;"><i class='fas fa-trash'></i></button>` : '';
    return `
        <div class="featured-comment ${isReply ? 'reply' : ''}" id="comment-${c.id}">
            <span class="comment-author">${c.author.username}</span>
            <span class="comment-date">${new Date(c.created_at).toLocaleString()}</span>
            <button class="reply-btn" data-id="${c.id}" data-username="${c.author.username}" title="Відповісти"><i class="fas fa-reply"></i></button>
            ${deleteBtn}
            <div class="comment-content">${replyLink}${c.content}</div>
        </div>
    `;
}

// --- Завантаження коментарів для обраного обговорення ---
async function loadComments(discussionId) {
    const commentsBlock = document.getElementById('featured-comments-list');
    if (!commentsBlock) return;
    commentsBlock.innerHTML = '<div class="loading">Завантаження коментарів...</div>';
    try {
        // Отримуємо поточного користувача
        let currentUserId = null;
        if (window.authManager && window.authManager.currentUser) {
            currentUserId = window.authManager.currentUser.user_id || window.authManager.currentUser.id;
        } else {
            // fallback через API
            try {
                const res = await fetch('/api/auth/status', { credentials: 'include' });
                const data = await res.json();
                currentUserId = data?.user?.user_id || data?.user?.id;
            } catch {}
        }
        const res = await fetch(`/api/discussions/${discussionId}/comments`);
        const data = await res.json();
        if (!Array.isArray(data.comments) || data.comments.length === 0) {
            commentsBlock.innerHTML = '<div class="no-comments">Коментарів поки немає</div>';
            return;
        }
        const { topLevel, repliesByRoot, byId } = buildCommentThreads(data.comments);

        commentsBlock.innerHTML = topLevel.map(root => {
            const rootHtml = renderCommentItem(root, currentUserId, byId, root.id, false);
            const replies = repliesByRoot[root.id] || [];
            if (replies.length === 0) {
                return `<div class="comment-thread">${rootHtml}</div>`;
            }
            const [firstReply, ...restReplies] = replies;
            const visibleHtml = renderCommentItem(firstReply, currentUserId, byId, root.id, true);
            let toggleHtml = '';
            if (restReplies.length > 0) {
                const hiddenHtml = restReplies.map(r => renderCommentItem(r, currentUserId, byId, root.id, true)).join('');
                toggleHtml = `
                    <button class="show-replies-btn" data-root="${root.id}" data-count="${restReplies.length}">
                        Показати усі відповіді (${replies.length})
                    </button>
                    <div class="hidden-replies" id="hidden-replies-${root.id}" style="display:none;">${hiddenHtml}</div>
                `;
            }
            return `
                <div class="comment-thread">
                    ${rootHtml}
                    <div class="comment-replies">
                        ${visibleHtml}
                        ${toggleHtml}
                    </div>
                </div>
            `;
        }).join('');

        // Розгортання/згортання прихованих відповідей
        document.querySelectorAll('.show-replies-btn').forEach(btn => {
            btn.onclick = () => {
                const rootId = btn.dataset.root;
                const hidden = document.getElementById('hidden-replies-' + rootId);
                if (!hidden) return;
                const isHidden = hidden.style.display === 'none';
                hidden.style.display = isHidden ? '' : 'none';
                btn.textContent = isHidden ? 'Згорнути відповіді' : `Показати усі відповіді (${Number(btn.dataset.count) + 1})`;
            };
        });
        // Навішуємо обробники на кнопки 'Відповісти'
        document.querySelectorAll('.reply-btn').forEach(btn => {
            btn.onclick = (e) => {
                replyTo = { id: btn.dataset.id, username: btn.dataset.username };
                renderReplyInfo();
                document.getElementById('add-comment-text').focus();
            };
        });
        // Навішуємо обробники на reply-link
        document.querySelectorAll('.reply-link').forEach(link => {
            link.onclick = (e) => {
                e.preventDefault();
                const target = document.getElementById('comment-' + link.dataset.reply);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.style.boxShadow = '0 0 0 3px #ffd600';
                    setTimeout(() => { target.style.boxShadow = ''; }, 1200);
                }
            };
        });
        // Навішуємо обробники на кнопки видалення
        document.querySelectorAll('.delete-comment-btn').forEach(btn => {
            btn.onclick = async (e) => {
                const commentId = btn.dataset.id;
                if (!confirm('Ви дійсно хочете видалити цей коментар?')) return;
                btn.disabled = true;
                btn.innerHTML = "<i class='fas fa-spinner fa-spin'></i>";
                try {
                    const response = await fetch(`/api/discussions/${discussionId}/comments/${commentId}`, {
                        method: 'DELETE',
                        credentials: 'include'
                    });
                    if (response.ok) {
                        // Видаляємо з DOM або перезавантажуємо список
                        loadComments(discussionId);
                    } else {
                        btn.disabled = false;
                        btn.innerHTML = "<i class='fas fa-trash'></i>";
                        alert('Помилка при видаленні коментаря');
                    }
                } catch {
                    btn.disabled = false;
                    btn.innerHTML = "<i class='fas fa-trash'></i>";
                    alert('Помилка при видаленні коментаря');
                }
            };
        });
    } catch {
        commentsBlock.innerHTML = '<div class="error">Помилка завантаження коментарів</div>';
    }
}

// --- Події ---
if (searchInput) {
    searchInput.addEventListener('input', () => {
        currentPage = 1;
        applyFiltersAndRender();
    });
}
if (filterBtn) {
    filterBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        // Позиціонуємо dropdown строго під кнопкою
        const rect = filterBtn.getBoundingClientRect();
        filterDropdown.style.left = rect.left + 'px';
        filterDropdown.style.top = (rect.bottom + window.scrollY) + 'px';
        filterDropdown.classList.toggle('active');
    });
}
if (filterDropdown) {
    filterDropdown.addEventListener('click', e => {
        if (e.target.classList.contains('filter-option')) {
            document.querySelectorAll('.filter-option').forEach(opt => opt.classList.remove('active'));
            e.target.classList.add('active');
            currentSort = e.target.dataset.sort;
            currentPage = 1;
            applyFiltersAndRender();
            filterDropdown.classList.remove('active');
        }
    });
}
// Приховування dropdown при кліку поза ним
window.addEventListener('click', (e) => {
    if (filterDropdown.classList.contains('active')) {
        if (!filterDropdown.contains(e.target) && e.target !== filterBtn) {
            filterDropdown.classList.remove('active');
        }
    }
});
if (prevPageBtn) prevPageBtn.addEventListener('click', () => { if (currentPage > 1) { currentPage--; applyFiltersAndRender(); } });
if (nextPageBtn) nextPageBtn.addEventListener('click', () => { const totalPages = Math.ceil(filteredDiscussions.length / pageSize); if (currentPage < totalPages) { currentPage++; applyFiltersAndRender(); } });

// --- Модалка створення обговорення ---
if (createBtn) createBtn.addEventListener('click', () => { createModal.style.display = 'flex'; });
if (closeCreateModal) closeCreateModal.addEventListener('click', () => { createModal.style.display = 'none'; });
if (createForm) {
    createForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('discussion-title').value.trim();
        const desc = document.getElementById('discussion-description').value.trim();
        if (!title || !desc) return;
        // Валідація
        if (title.length > 100 || desc.length > 500) return;
        // Відправка
        try {
            const res = await fetch('/api/discussions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ title, description: desc })
            });
            if (res.ok) {
                createModal.style.display = 'none';
                createForm.reset();
                await loadDiscussions();
            } else {
                let errText = 'Помилка створення обговорення';
                try {
                    const err = await res.json();
                    if (err && err.error) errText += `: ${err.error}`;
                    if (err && err.details) errText += `\n${err.details}`;
                } catch {}
                alert(errText);
            }
        } catch {
            alert('Помилка створення обговорення');
        }
    });
}

// --- Ініціалізація ---
document.addEventListener('DOMContentLoaded', async () => {
    await fetchCurrentUserId();
    loadDiscussions();
    renderReplyInfo();

    // --- Автопрокрутка до обговорення за параметром title ---
    const urlParams = new URLSearchParams(window.location.search);
    const targetTitle = urlParams.get('title');
    if (targetTitle) {
        setTimeout(() => {
            const cards = document.querySelectorAll('.discussion-list-card, .discussion-card');
            let found = false;
            cards.forEach(card => {
                const titleEl = card.querySelector('.discussion-list-title, .discussion-title');
                if (titleEl && titleEl.textContent.trim() === targetTitle.trim()) {
                    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    card.style.boxShadow = '0 0 0 4px #ffd600, 0 6px 20px rgba(245,197,6,0.18)';
                    card.style.transition = 'box-shadow 0.6s';
                    found = true;
                    setTimeout(() => {
                        card.style.boxShadow = '';
                    }, 2000);
                }
            });
            if (!found) {
                // Якщо не знайдено, можна показати повідомлення або нічого не робити
            }
        }, 700); // Чекаємо, поки DOM і обговорення завантажаться
    }
});

if (addCommentForm) {
    addCommentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const textarea = document.getElementById('add-comment-text');
        const text = textarea.value.trim();
        if (!text || text.length > 500) return;
        let discussion = selectedDiscussion;
        if (!discussion && filteredDiscussions.length > 0) {
            discussion = filteredDiscussions[0];
        }
        if (!discussion) return;
        const body = { content: text };
        if (replyTo) body.parent_id = Number(replyTo.id);
        console.log('replyTo before send:', replyTo);
        console.log('body before send:', body);
        try {
            const res = await fetch(`/api/discussions/${discussion.id}/comments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(body)
            });
            if (res.ok) {
                textarea.value = '';
                replyTo = null;
                renderReplyInfo();
                loadComments(discussion.id);
            } else {
                let errText = 'Помилка додавання коментаря';
                try {
                    const err = await res.json();
                    if (err && err.error) errText += `: ${err.error}`;
                    if (err && err.details) errText += `\n${err.details}`;
                } catch {}
                alert(errText);
            }
        } catch {
            alert('Помилка додавання коментаря');
        }
    });
}

const myDiscussionsBtn = document.getElementById('my-discussions-btn');
if (myDiscussionsBtn) {
    myDiscussionsBtn.addEventListener('click', () => {
        myDiscussionsMode = !myDiscussionsMode;
        myDiscussionsBtn.classList.toggle('active', myDiscussionsMode);
        myDiscussionsBtn.textContent = myDiscussionsMode ? 'Всі обговорення' : 'Мої обговорення';
        currentPage = 1;
        applyFiltersAndRender();
    });
} 