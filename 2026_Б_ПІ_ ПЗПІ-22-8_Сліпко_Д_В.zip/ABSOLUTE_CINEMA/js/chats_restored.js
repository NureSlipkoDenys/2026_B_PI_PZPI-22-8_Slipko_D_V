// Ініціалізація змінних
let currentUser = null;
let currentChatId = null;
let chats = [];
let activeChatUser = null;
let isModalOpen = false;
let socket = null;

// DOM-елементи
const chatsList = document.getElementById('chats-list');
const noChat = document.getElementById('no-chat-selected');
const activeChat = document.getElementById('active-chat');
const chatMessages = document.getElementById('chat-messages');
const chatHeader = document.getElementById('chat-header');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const newChatBtn = document.getElementById('new-chat-btn');
const newChatModal = document.getElementById('new-chat-modal');
const searchChatInput = document.getElementById('search-chat-input');
const searchUserInput = document.getElementById('search-user-input');
const searchUserBtn = document.getElementById('search-user-btn');
const searchResults = document.getElementById('search-results');
const emojiBtn = document.getElementById('emoji-btn');
const chatDeleteBtn = document.getElementById('chat-delete-btn');

// Подія завантаження DOM
document.addEventListener('DOMContentLoaded', async function () {
    // Ініціалізація компонентів
    initComponents();

    try {
        // Перевірка авторизації
        await checkAuth();

        // Завантаження чатів користувача
        if (currentUser) {
            await loadChats();
            // Відкриття чату за параметром chat
            const params = new URLSearchParams(window.location.search);
            const chatId = params.get('chat');
            if (chatId) {
                // Чекаємо, поки чати завантажаться, потім шукаємо потрібний чат
                const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
                if (chatItem) {
                    chatItem.click();
                } else {
                    // Якщо чат не знайдено (наприклад, щойно створений), пробуємо відкрити напряму
                    // Для цього потрібно знайти userId співрозмовника
                    // Можна спробувати знайти в масиві chats
                    const chatObj = chats.find(c => String(c.id) === String(chatId));
                    if (chatObj) {
                        const otherUserId = chatObj.user1_id === currentUser.user_id ? chatObj.user2.user_id : chatObj.user1.user_id;
                        openChat(chatId, otherUserId);
                    }
                }
            }
        } else {
            // Якщо користувач не авторизований, показуємо повідомлення
            chatsList.innerHTML = '<div class="empty-chats"><p>Ви не авторизовані</p><p>Увійдіть, щоб отримати доступ до чатів</p></div>';
            showLoginPrompt();
        }
    } catch (error) {
        console.error('Помилка при ініціалізації:', error);
        chatsList.innerHTML = '<div class="error-message">Помилка завантаження чатів</div>';
    }

    // Ініціалізація подій
    initEvents();

    // Ініціалізація емодзі-пікера
    initEmojiPicker();
});

// Ініціалізація компонентів сторінки
async function initComponents() {
    try {
        // Тут може бути додаткова ініціалізація компонентів
        console.log('Компоненти ініціалізовано');
    } catch (error) {
        console.error('Помилка при ініціалізації компонентів:', error);
    }
}

// Ініціалізація WebSocket з'єднання
function initWebSocket() {
    if (!currentUser) {
        console.log('initWebSocket: currentUser не визначено');
        return;
    }

    console.log('initWebSocket: Ініціалізація WebSocket для користувача', currentUser.user_id);

    // Закриваємо наявне з'єднання, якщо воно є
    if (socket) {
        console.log('initWebSocket: Закриваємо наявне з\'єднання');
        socket.close();
    }

    // Створюємо нове WebSocket з'єднання
    const wsUrl = `ws://${window.location.host}/ws/chat`;
    console.log('initWebSocket: Створюємо нове з\'єднання за URL', wsUrl);
    socket = new WebSocket(wsUrl);

    socket.onopen = async function (e) {
        console.log('WebSocket з\'єднання встановлено для користувача', currentUser.user_id);

        try {
            // Отримуємо токен через API
            console.log('Запитуємо токен через API');
            const response = await fetch('/api/auth/token');
            const data = await response.json();

            if (!data.token) {
                console.error('Токен не отримано від сервера');
                return;
            }

            console.log('Токен отримано, надсилаємо для автентифікації');
            // Надсилаємо токен для автентифікації
            socket.send(JSON.stringify({
                type: 'auth',
                token: data.token
            }));
            console.log('Токен надіслано для автентифікації');
        } catch (error) {
            console.error('Помилка при отриманні токена:', error);
        }
    };

    socket.onmessage = function (event) {
        try {
            const data = JSON.parse(event.data);
            console.log('Отримано повідомлення через WebSocket для користувача', currentUser.user_id, ':', data);

            switch (data.type) {
                case 'message':
                    // Якщо повідомлення для поточного чату — додаємо в DOM
                    if (String(data.chat_id) === String(currentChatId)) {
                        console.log('Додаємо нове повідомлення в чат:', data);
                        const messageHTML = `
                            <div class="message message-received">
                                <div class="message-content">${data.content}</div>
                                <div class="message-meta">
                                    <span class="message-time">${formatTime(new Date(data.sent_at))}</span>
                                </div>
                            </div>
                        `;
                        chatMessages.insertAdjacentHTML('beforeend', messageHTML);
                        scrollToBottom();

                        // Одразу позначаємо як прочитане (чат відкрито)
                        if (data.sender_id !== currentUser.user_id) {
                            markMessagesAsRead(currentChatId);
                        }
                    } else {
                        // Повідомлення не для поточного чату — просто оновлюємо список і бейджик
                        loadChats();
                        updateUnreadBadge();
                    }
                    break;
                case 'message_read':
                    console.log('Отримано сповіщення про прочитання для чату:', data.chat_id, 'поточний чат:', currentChatId);
                    if (String(data.chat_id) === String(currentChatId)) {
                        // Оновлюємо статус усіх надісланих повідомлень на прочитано
                        document.querySelectorAll('.message-sent .msg-status').forEach(status => {
                            status.classList.add('read');
                            status.innerHTML = '<i class="far fa-eye"></i>';
                        });
                        console.log('Оновлено іконки прочитання в поточному чаті');
                    }
                    // Не викликаємо loadChats() — у відправника unread_count не змінюється
                    break;

                case 'message_sent':
                    console.log('Повідомлення успішно доставлено:', data);
                    // Можна додати візуальне підтвердження доставки
                    break;

                case 'message_error':
                    console.error('Помилка надсилання повідомлення:', data.error);
                    alert('Помилка надсилання повідомлення: ' + data.error);
                    break;

                case 'message_status':
                    if (data.status === 'recipient_offline') {
                        console.log('Отримувач не в мережі');
                        // Можна додати візуальне сповіщення
                    }
                    break;
            }
        } catch (error) {
            console.error('Помилка при обробці WebSocket повідомлення:', error);
        }
    };

    socket.onclose = function (event) {
        console.log('WebSocket з\'єднання закрито:', event.code, event.reason);
        // Намагаємося перепідключитися через 5 секунд
        setTimeout(initWebSocket, 5000);
    };

    socket.onerror = function (error) {
        console.error('WebSocket помилка:', error);
    };
}

// Модифікуємо функцію checkAuth
async function checkAuth() {
    try {
        const response = await fetch('/api/auth/status');
        const data = await response.json();

        if (data.authenticated) {
            currentUser = data.user;
            console.log('Користувач авторизований:', currentUser);

            // Завантажуємо повну інформацію про профіль
            const profileResponse = await fetch('/api/profile');
            const profileData = await profileResponse.json();

            if (profileData.profile) {
                currentUser = { ...currentUser, ...profileData.profile };
            }

            // Ініціалізуємо WebSocket після успішної авторизації
            initWebSocket();
        } else {
            console.log('Користувач не авторизований');
            currentUser = null;
        }
    } catch (error) {
        console.error('Помилка при перевірці авторизації:', error);
        throw error;
    }
}

// Показати повідомлення про необхідність входу
function showLoginPrompt() {
    noChat.innerHTML = `
        <div class="login-prompt">
            <div class="login-icon">
                <i class="fas fa-user-lock"></i>
            </div>
            <h2>Увійдіть в акаунт</h2>
            <p>Щоб почати спілкування, потрібно увійти або зареєструватися</p>
            <button class="login-btn" onclick="openAuthModal()">
                <i class="fas fa-sign-in-alt"></i> ВХІД/РЕЄСТРАЦІЯ
            </button>
        </div>
    `;
}

// Завантаження і рендер списку чатів користувача
let loadChatsInProgress = false;
let loadChatsPending = false;
async function loadChats() {
    if (loadChatsInProgress) {
        loadChatsPending = true;
        return;
    }
    loadChatsInProgress = true;
    loadChatsPending = false;
    try {
        const response = await fetch(`/api/chats?t=${new Date().getTime()}`, {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
        const data = await response.json();

        if (response.ok) {
            chats = data.chats || [];
            renderChats();
            updateUnreadBadge();
        } else {
            console.error('loadChats error:', data.error);
        }
    } catch (error) {
        console.error('loadChats fetch error:', error);
    } finally {
        loadChatsInProgress = false;
        if (loadChatsPending) {
            loadChatsPending = false;
            loadChats();
        }
    }
}


// Відображення списку чатів
function renderChats() {
    if (chats.length === 0) {
        chatsList.innerHTML = '<div class="empty-chats"><p>У вас поки немає чатів</p><p>Натисніть "Новий чат", щоб почати спілкування</p></div>';
        return;
    }

    let chatsHTML = '';

    chats.forEach(chat => {
        // Визначаємо співрозмовника (іншого користувача)
        const otherUser = chat.user1_id === currentUser.user_id ? chat.user2 : chat.user1;
        const userProfile = otherUser && otherUser.profile ? otherUser.profile : otherUser;
        // Форматуємо час останнього повідомлення
        const lastMessageTime = chat.last_message ? formatTime(new Date(chat.last_message.sent_at)) : '';
        // Порівнюємо як рядки, щоб не було проблем з типами
        const isActive = String(chat.id) === String(currentChatId);
        // Створюємо HTML-елемент чату
        chatsHTML += `
            <div class="chat-item${isActive ? ' active' : ''}" data-chat-id="${chat.id}" data-user-id="${userProfile.user_id}">
                <div class="chat-avatar">
                    <img src="${userProfile.avatar_url || 'https://via.placeholder.com/50'}" alt="${userProfile.username}">
                </div>
                <div class="chat-preview">
                    <h3>${userProfile.username}</h3>
                    <p>${chat.last_message ? chat.last_message.content : 'Немає повідомлень'}</p>
                </div>
                <div class="chat-meta">
                    <div class="chat-time">${lastMessageTime}</div>
                    ${chat.unread_count > 0 ? `<div class="chat-unread">${chat.unread_count}</div>` : ''}
                </div>
            </div>
        `;
    });

    chatsList.innerHTML = chatsHTML;

    // Додаємо обробники для кожного чату
    document.querySelectorAll('.chat-item').forEach(item => {
        item.addEventListener('click', function () {
            const chatId = this.getAttribute('data-chat-id');
            const userId = this.getAttribute('data-user-id');
            openChat(chatId, userId);
        });
    });
}

// Відкриття чату
async function openChat(chatId, userId) {
    // Зберігаємо як число для одноманітності порівнянь
    currentChatId = String(chatId);

    // Видаляємо активний клас з усіх чатів і додаємо новому
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('active');
    });

    const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
    if (chatItem) {
        chatItem.classList.add('active');
    }

    // Показуємо вікно активного чату
    noChat.style.display = 'none';
    activeChat.style.display = 'flex';

    // Завантажуємо інформацію про користувача
    await loadChatUser(userId);

    // Завантажуємо повідомлення
    await loadMessages(chatId);

    // Позначаємо повідомлення як прочитані (не чекаємо — оновлюємо UI одразу)
    markMessagesAsRead(chatId);
}

// Завантаження інформації про користувача чату
async function loadChatUser(userId) {
    try {
        console.log('loadChatUser отримує userId:', userId, 'currentUser:', currentUser.user_id);
        const response = await fetch(`/api/users/${userId}`);
        const data = await response.json();
        if (response.ok) {
            const userProfile = data.profile;
            activeChatUser = userProfile;
            console.log('Отримано інформацію про користувача:', activeChatUser);
            // Оновлюємо заголовок чату
            document.getElementById('chat-user-name').textContent = activeChatUser.username;
            document.getElementById('chat-user-avatar').src = activeChatUser.avatar_url || 'https://via.placeholder.com/40';
            // Відображаємо біографію користувача
            const userBioElement = document.getElementById('chat-user-bio');
            if (userBioElement) {
                userBioElement.textContent = activeChatUser.bio || 'Біографія відсутня';
            }
            // Додаємо можливість переходу на профіль користувача
            const userNameElement = document.getElementById('chat-user-name');
            const userAvatarElement = document.getElementById('chat-user-avatar').parentElement;
            userNameElement.style.cursor = 'pointer';
            userAvatarElement.style.cursor = 'pointer';
            userNameElement.onclick = () => {
                console.log('Перехід на профіль співрозмовника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
            userAvatarElement.onclick = () => {
                console.log('Перехід на профіль співрозмовника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
        } else {
            console.error('Помилка при завантаженні користувача:', data.error);
        }
    } catch (error) {
        console.error('Помилка при завантаженні користувача:', error);
    }
}

// Завантаження повідомлень чату
async function loadMessages(chatId) {
    try {
        chatMessages.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Завантаження повідомлень...</p></div>';
        const response = await fetch(`/api/chats/${chatId}/messages?t=${new Date().getTime()}`, {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
        const data = await response.json();

        if (response.ok) {
            renderMessages(data.messages || []);
        } else {
            console.error('Помилка при завантаженні повідомлень:', data.error);
            chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
        }
    } catch (error) {
        console.error('Помилка при завантаженні повідомлень:', error);
        chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
    }
}

// Функція для автоматичної прокрутки чату
function scrollToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

// Відображення повідомлень чату
function renderMessages(messages) {
    if (messages.length === 0) {
        chatMessages.innerHTML = '<div class="empty-messages"><p>Напишіть повідомлення, щоб почати спілкування</p></div>';
        return;
    }

    let messagesHTML = '';

    messages.forEach(message => {
        const isSent = message.sender_id === currentUser.user_id;
        const messageClass = isSent ? 'message-sent' : 'message-received';
        const messageTime = formatTime(new Date(message.sent_at));

        let statusHTML = '';
        if (isSent) {
            statusHTML = message.is_read
                ? '<span class="msg-status read"><i class="far fa-eye"></i></span>'
                : '<span class="msg-status"><i class="fas fa-check"></i></span>';
        }

        messagesHTML += `
            <div class="message ${messageClass}">
                <div class="message-content">${message.content}</div>
                <div class="message-meta">
                    <span class="message-time">${messageTime}</span>
                    ${statusHTML}
                </div>
            </div>
        `;
    });

    chatMessages.innerHTML = messagesHTML;

    // Прокручуємо до останнього повідомлення
    scrollToBottom();
}

// Модифікуємо функцію sendMessage
async function sendMessage() {
    if (!currentChatId || !chatInput.value.trim()) {
        return;
    }

    const messageContent = chatInput.value.trim();

    try {
        console.log('Надсилання повідомлення в чат:', currentChatId);
        console.log('Вміст повідомлення:', messageContent);

        // Надсилаємо повідомлення на сервер
        const response = await fetch(`/api/chats/${currentChatId}/messages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: messageContent
            })
        });

        const data = await response.json();

        if (response.ok) {
            console.log('Повідомлення успішно надіслано:', data.message);

            // Очищаємо поле вводу
            chatInput.value = '';

            // Додаємо нове повідомлення в чат
            const message = data.message;
            const messageHTML = `
                <div class="message message-sent">
                    <div class="message-content">${message.content}</div>
                    <div class="message-meta">
                        <span class="message-time">${formatTime(new Date(message.sent_at))}</span>
                        <span class="msg-status"><i class="fas fa-check"></i></span>
                    </div>
                </div>
            `;
            chatMessages.insertAdjacentHTML('beforeend', messageHTML);

            // Прокручуємо до нового повідомлення
            scrollToBottom();

            // Надсилаємо повідомлення через WebSocket
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.send(JSON.stringify({
                    type: 'message',
                    chat_id: currentChatId,
                    content: messageContent,
                    sender_id: currentUser.user_id,
                    sent_at: message.sent_at
                }));
                console.log('Повідомлення надіслано через WebSocket');
            } else {
                console.error('WebSocket не підключено');
            }
        } else {
            console.error('Помилка при надсиланні повідомлення:', data.error);
            alert('Помилка відправки повідомлення: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Помилка при надсиланні повідомлення:', error);
        alert('Помилка відправки повідомлення: ' + error.message);
    }
}

// Позначення повідомлень як прочитаних
let markAsReadInProgress = false;
let markAsReadPending = false;
let pendingChatId = null;

async function markMessagesAsRead(chatId) {
    if (markAsReadInProgress) {
        markAsReadPending = true;
        pendingChatId = chatId;
        return;
    }
    markAsReadInProgress = true;
    markAsReadPending = false;
    try {
        const response = await fetch(`/api/chats/${chatId}/read`, {
            method: 'POST'
        });

        if (!response.ok) {
            console.error('Помилка сервера при позначенні прочитаними:', await response.text());
            return;
        }

        console.log(`Повідомлення в чаті ${chatId} позначені як прочитані на сервері`);

        // Негайно оновлюємо локальний масив chats[], не чекаємо loadChats()
        const chatIdStr = String(chatId);
        chats = chats.map(c => String(c.id) === chatIdStr ? { ...c, unread_count: 0 } : c);

        // Одразу оновлюємо бейджик у хедері та цифру в сайдбарі
        updateUnreadBadge();
        const chatItemEl = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
        if (chatItemEl) {
            const b = chatItemEl.querySelector('.chat-unread');
            if (b) b.remove();
        }

        // Фоновий синк із сервером (не блокує UI)
        renderChats();
    } catch (error) {
        console.error('markMessagesAsRead error:', error);
    } finally {
        markAsReadInProgress = false;
        if (markAsReadPending && pendingChatId) {
            markAsReadPending = false;
            // Run again if another message arrived while we were marking as read
            markMessagesAsRead(pendingChatId);
        } else {
            // Додаткове фонове оновлення списку чатів про всяк випадок,
            // якщо позначення прочитаними відбулося без повного оновлення через loadChats()
            loadChats();
        }
    }
}

// Створення нового чату
async function createChat(userId) {
    try {
        const response = await fetch('/api/chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Закриваємо модальне вікно
            closeModal();

            // Оновлюємо список чатів
            await loadChats();

            // Відкриваємо новий чат
            openChat(data.chat.id, userId);
        } else {
            console.error('Помилка при створенні чату:', data.error);
            alert('Помилка створення чату');
        }
    } catch (error) {
        console.error('Помилка при створенні чату:', error);
        alert('Помилка створення чату');
    }
}

// Пошук користувачів
async function searchUsers(query) {
    if (!query.trim()) {
        searchResults.innerHTML = '';
        return;
    }

    try {
        searchResults.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Пошук користувачів...</p></div>';

        const response = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (response.ok) {
            renderSearchResults(data.users || []);
        } else {
            console.error('Помилка при пошуку користувачів:', data.error);
            searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
        }
    } catch (error) {
        console.error('Помилка при пошуку користувачів:', error);
        searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
    }
}

// Відображення результатів пошуку користувачів
function renderSearchResults(users) {
    if (users.length === 0) {
        searchResults.innerHTML = '<div class="empty-results">Користувачів не знайдено</div>';
        return;
    }

    let resultsHTML = '';

    users.forEach(user => {
        // Пропускаємо поточного користувача
        if (user.user_id === currentUser.user_id) {
            return;
        }

        resultsHTML += `
            <div class="user-result" data-user-id="${user.user_id}">
                <div class="user-result-avatar">
                    <img src="${user.avatar_url || 'https://via.placeholder.com/40'}" alt="${user.username}">
                </div>
                <div class="user-result-details">
                    <h3>${user.username}</h3>
                    <p>${user.bio ? user.bio.substring(0, 50) + (user.bio.length > 50 ? '...' : '') : 'Немає інформації'}</p>
                </div>
            </div>
        `;
    });

    searchResults.innerHTML = resultsHTML;

    // Додаємо обробники для кожного результату
    document.querySelectorAll('.user-result').forEach(item => {
        item.addEventListener('click', function () {
            const userId = this.getAttribute('data-user-id');
            createChat(userId);
        });
    });
}

// Відкриття модального вікна
function openModal() {
    newChatModal.style.display = 'flex';
    searchUserInput.value = '';
    searchResults.innerHTML = '';
    isModalOpen = true;
}

// Закриття модального вікна
function closeModal() {
    newChatModal.style.display = 'none';
    isModalOpen = false;
}

// Пошук чатів
function filterChats(query) {
    const chatItems = document.querySelectorAll('.chat-item');

    chatItems.forEach(item => {
        const username = item.querySelector('h3').textContent.toLowerCase();
        const lastMessage = item.querySelector('p').textContent.toLowerCase();

        if (username.includes(query.toLowerCase()) || lastMessage.includes(query.toLowerCase())) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Відкриття модального вікна авторизації
function openAuthModal() {
    // Якщо є функція з auth.js, викликаємо її
    if (typeof showAuthModal === 'function') {
        showAuthModal('login');
    } else {
        alert('Для спілкування в чаті потрібно авторизуватися');
    }
}

// Форматування часу
function formatTime(date) {
    // Отримуємо поточну дату
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    // Перевіряємо, чи сьогодні повідомлення
    if (date > today) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    // Перевіряємо, чи вчора повідомлення
    if (date > yesterday) {
        return 'Вчора';
    }

    // Інакше повертаємо дату
    return date.toLocaleDateString();
}

// Ініціалізація емодзі-пікера
function initEmojiPicker() {
    // Перевіряємо, чи завантажена бібліотека
    if (typeof EmojiButton !== 'function') {
        // Якщо бібліотека не завантажена, підключаємо її
        const emojiScript = document.createElement('script');
        emojiScript.src = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/index.min.js';
        document.head.appendChild(emojiScript);

        const emojiCSS = document.createElement('link');
        emojiCSS.rel = 'stylesheet';
        emojiCSS.href = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/css/emoji-button.min.css';
        document.head.appendChild(emojiCSS);

        emojiScript.onload = setupEmojiPicker;
    } else {
        setupEmojiPicker();
    }
}

// Налаштування емодзі-пікера
function setupEmojiPicker() {
    if (!emojiBtn) return;

    const picker = new EmojiButton({
        position: 'top-start',
        theme: 'dark',
        autoHide: false,
        showVariants: true,
        emojiSize: '1.5em'
    });

    picker.on('emoji', emoji => {
        chatInput.value += emoji;
        chatInput.focus();
    });

    emojiBtn.addEventListener('click', () => {
        picker.togglePicker(emojiBtn);
    });
}

// Видалення чату
async function deleteChat(chatId) {
    if (!confirm('Ви впевнені, що хочете видалити цю переписку? Це не можна буде скасувати.')) {
        return;
    }

    try {
        console.log('Видалення чату з ID:', chatId);

        const response = await fetch(`/api/chats/${chatId}`, {
            method: 'DELETE'
        });

        const responseText = await response.text();
        console.log('Відповідь сервера при видаленні чату:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Помилка парсингу відповіді при видаленні чату:', parseError);
            alert('Помилка при видаленні чату: невірний формат відповіді');
            return;
        }

        if (response.ok) {
            console.log('Чат успішно видалено:', data);

            // Закриваємо чат
            currentChatId = null;
            activeChat.style.display = 'none';
            noChat.style.display = 'flex';

            // Оновлюємо список чатів
            await loadChats();
        } else {
            console.error('Помилка при видаленні чату:', data.error);
            alert('Помилка при видаленні чату: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Помилка при видаленні чату:', error);
        alert('Помилка при видаленні чату: ' + error.message);
    }
}

// Ініціалізація обробників подій
function initEvents() {
    // Надсилання повідомлення при натисканні кнопки
    sendBtn.addEventListener('click', sendMessage);

    // Надсилання повідомлення при натисканні Enter (без Shift)
    chatInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Відкриття модального вікна для нового чату
    newChatBtn.addEventListener('click', openModal);

    // Закриття модального вікна - використовуємо всі кнопки закриття на сторінці
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', closeModal);
    });

    // Закриття модального вікна при кліку поза ним
    newChatModal.addEventListener('click', function (e) {
        if (e.target === this) {
            closeModal();
        }
    });

    // Пошук користувачів
    searchUserBtn.addEventListener('click', function () {
        searchUsers(searchUserInput.value);
    });

    // Пошук користувачів при натисканні Enter
    searchUserInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            searchUsers(searchUserInput.value);
        }
    });

    // Пошук чатів
    searchChatInput.addEventListener('input', function () {
        filterChats(this.value);
    });

    // Закриття модального вікна при натисканні Escape
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && isModalOpen) {
            closeModal();
        }
    });

    // Видалення чату
    if (chatDeleteBtn) {
        chatDeleteBtn.addEventListener('click', function () {
            if (currentChatId) {
                deleteChat(currentChatId);
            }
        });
    }

    // Ініціалізуємо події рекомендацій, якщо вони є
    initRecommendationsEvents();
}

// Ініціалізація подій для рекомендацій
function initRecommendationsEvents() {
    // Обробники для кнопок "Почати чат" з рекомендованими користувачами
    const startChatButtons = document.querySelectorAll('.start-chat-btn');
    startChatButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Отримуємо ім'я користувача з батьківської картки
            const userName = this.closest('.user-card').querySelector('h4').textContent;

            // Заглушка - створюємо заглушку для демонстрації
            alert(`Початок нового чату з користувачем ${userName}. В реальному додатку тут буде створено новий чат.`);

            // У реальному застосунку тут має бути код для створення чату
            // createChat(userId);
        });
    });
}

// Функція для оновлення індикатора непрочитаних повідомлень у хедері
function updateUnreadBadge() {
    const badge = document.getElementById('unread-badge');
    if (!badge) return;
    // Підсумовуємо всі непрочитані повідомлення у всіх чатах
    const totalUnread = chats.reduce((sum, chat) => sum + (chat.unread_count || 0), 0);
    if (totalUnread > 0) {
        badge.textContent = totalUnread > 99 ? '99+' : totalUnread;
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
} 
