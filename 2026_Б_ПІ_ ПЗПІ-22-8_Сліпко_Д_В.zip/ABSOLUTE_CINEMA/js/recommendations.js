// recommendations.js — Персональні рекомендації на базі онбордингу та обраного

document.addEventListener('DOMContentLoaded', () => {
    loadPersonalRecommendations();
    loadRandomMovie();
});

/**
 * Завантажує персональні рекомендації:
 * - Якщо юзер залогінений і пройшов онбординг → персональна вибірка
 * - Якщо ні → топ-рейтингові фільми (fallback)
 */
async function loadPersonalRecommendations() {
    const grid = document.querySelector('.recommendations-grid');
    if (!grid) return;

    grid.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i> Завантаження...</div>';

    try {
        const response = await fetch('/api/recommendations/personal', {
            credentials: 'include',
            headers: { 'Accept': 'application/json', 'Cache-Control': 'no-cache' }
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        const movies = data.movies || [];

        grid.innerHTML = '';

        if (movies.length === 0) {
            grid.innerHTML = '<p class="no-results">Фільми не знайдені</p>';
            return;
        }

        const toShow = movies.slice(0, 3);

        // Update section header if personalized
        if (data.personalized) {
            updateRecommendationsHeader(data.preferred_genres);
        }

        toShow.forEach(movie => {
            const year = movie.release_date ? new Date(movie.release_date).getFullYear() : null;
            const genres = movie.genres && movie.genres.length > 0
                ? movie.genres.slice(0, 2).join(', ')
                : '';
            const rating = movie.imdb_rating ? Number(movie.imdb_rating).toFixed(1) : null;

            const card = document.createElement('div');
            card.className = 'recommendation-card';
            card.setAttribute('data-id', movie.id);

            const metaLineParts = [];
            if (rating !== null) metaLineParts.push(`<span class="recommendation-rating">★ ${rating}/10</span>`);
            if (year) metaLineParts.push(`${year}`);
            const metaLine = metaLineParts.join(' <span class="recommendation-dot">·</span> ');

            card.innerHTML = `
                <div class="recommendation-poster">
                    <img src="${movie.poster_url || 'https://via.placeholder.com/300x450?text=Немає+постера'}"
                         alt="${escapeHtml(movie.title)}"
                         onerror="this.src='https://via.placeholder.com/300x450?text=?'">
                    <div class="recommendation-overlay">
                        <button class="watch-button">Детальніше</button>
                        <div class="recommendation-meta">
                            ${metaLine ? `<div class="recommendation-meta-line">${metaLine}</div>` : ''}
                            ${genres ? `<div class="recommendation-meta-line">${escapeHtml(genres)}</div>` : ''}
                        </div>
                    </div>
                </div>
                <div class="recommendation-title">${escapeHtml(movie.title)}</div>
            `;

            card.querySelector('.watch-button').addEventListener('click', (e) => {
                e.stopPropagation();
                window.location.href = `/movie/${movie.id}`;
            });
            card.addEventListener('click', () => {
                window.location.href = `/movie/${movie.id}`;
            });

            grid.appendChild(card);
        });
    } catch (err) {
        console.error('Error loading recommendations:', err);
        grid.innerHTML = '<div class="error-container"><i class="fas fa-exclamation-circle"></i> Помилка при завантаженні фільмів</div>';
    }
}

/**
 * Update the recommendations header to show which genres are personalized
 */
function updateRecommendationsHeader(genres) {
    const title = document.querySelector('.recommendations-title');
    if (!title || !genres || genres.length === 0) return;
    title.innerHTML = `Рекомендуємо вам
        <span style="font-size:0.65em; color:#f5c506; display:block; margin-top:4px; font-weight:400; letter-spacing:0.05em;">
            <i class="fas fa-magic" style="margin-right:4px;"></i>${genres.slice(0,3).join(' • ')}
        </span>`;
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

/**
 * Завантажує випадковий фільм
 */
async function loadRandomMovie() {
    const container = document.querySelector('.random-movie-container');
    if (!container) return;

    container.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i> Завантаження...</div>';

    try {
        const response = await fetch('/api/random-movie', {
            headers: { 'Accept': 'application/json', 'Cache-Control': 'no-cache' }
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const movie = await response.json();
        const genres = movie.genres && movie.genres.length > 0 ? movie.genres.join(', ') : 'Жанр не вказаний';
        const year = movie.release_date ? new Date(movie.release_date).getFullYear() : 'Не вказано';
        const description = (movie.description || 'Опис відсутній').slice(0, 300) + (movie.description?.length > 300 ? '...' : '');

        const card = document.createElement('div');
        card.className = 'random-movie-card';
        card.setAttribute('data-id', movie.id);

        card.innerHTML = `
            <div class="random-movie-poster">
                <img src="${movie.poster_url || 'https://via.placeholder.com/300x450?text=Немає+постера'}" alt="${escapeHtml(movie.title)}">
            </div>
            <div class="random-movie-info">
                <h3>${escapeHtml(movie.title)}</h3>
                <div class="movie-rating"><span class="star">★</span> ${movie.imdb_rating || '?'}/10</div>
                <div class="movie-genres">${escapeHtml(genres)}</div>
                <div class="movie-release-year">Рік: ${year}</div>
                <div class="random-movie-description">${escapeHtml(description)}</div>
                <div class="random-movie-actions">
                    <button class="watch-random-button">Детальніше</button>
                    <button class="change-random-button">Змінити фільм</button>
                </div>
            </div>
        `;

        container.innerHTML = '';
        container.appendChild(card);

        card.querySelector('.watch-random-button').addEventListener('click', () => {
            window.location.href = `/movie/${movie.id}`;
        });
        card.querySelector('.change-random-button').addEventListener('click', (e) => {
            e.stopPropagation();
            loadRandomMovie();
        });
        card.addEventListener('click', () => {
            window.location.href = `/movie/${movie.id}`;
        });
    } catch (err) {
        console.error('Error loading random movie:', err);
        container.innerHTML = `
            <div class="error-container">
                <i class="fas fa-exclamation-circle"></i>
                Помилка завантаження
                <button id="retryRandomMovie">Спробувати ще раз</button>
            </div>`;
        const retry = document.getElementById('retryRandomMovie');
        if (retry) retry.addEventListener('click', loadRandomMovie);
    }
}