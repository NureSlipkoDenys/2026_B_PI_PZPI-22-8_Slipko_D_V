// Навішуємо обробник на кнопку після завантаження сторінки
// і запобігаємо дублюванню форми

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const mediaId = urlParams.get('id');

    // Завантажуємо рецензії при завантаженні сторінки
    if (mediaId) {
        loadReviews(mediaId);
    }

    // Навішуємо обробник на наявну кнопку
    const writeBtn = document.getElementById('writeReviewBtn');
    if (writeBtn) {
        writeBtn.addEventListener('click', () => {
            // Перевіряємо, чи не відкрита вже форма
            if (!document.querySelector('.review-form')) {
                showReviewForm(mediaId);
            }
        });
    }
});

// Функція для відображення форми рецензії
function showReviewForm(mediaId) {
    // Перевіряємо авторизацію
    fetch('/api/auth/status')
        .then(response => response.json())
        .then(data => {
            if (!data.authenticated) {
                alert('Для написання рецензії потрібно авторизуватися');
                return;
            }

            const reviewForm = document.createElement('div');
            reviewForm.className = 'review-form';
            reviewForm.innerHTML = `
                <h3>Написати рецензію</h3>
                <div class="rating-container">
                    <label>Оцінка:</label>
                    <div class="star-rating">
                        ${Array(5).fill().map((_, i) => `
                            <span class="star" data-rating="${i + 1}">★</span>
                        `).join('')}
                    </div>
                </div>
                <textarea id="reviewContent" placeholder="Напишіть вашу рецензію..." rows="4"></textarea>
                <div class="spoiler-checkbox">
                    <input type="checkbox" id="containsSpoilers">
                    <label for="containsSpoilers">Містить спойлери</label>
                </div>
                <button onclick="submitReview(${mediaId})">Опублікувати рецензію</button>
            `;

            // Вставляємо форму перед списком рецензій
            const reviewsContainer = document.querySelector('.reviews-container');
            const reviewsList = reviewsContainer.querySelector('.reviews-list');
            reviewsContainer.insertBefore(reviewForm, reviewsList);

            // Додаємо обробники для зірок рейтингу
            const stars = reviewForm.querySelectorAll('.star');
            stars.forEach(star => {
                star.addEventListener('click', function() {
                    const rating = this.dataset.rating;
                    stars.forEach(s => s.classList.remove('active'));
                    for (let i = 0; i < rating; i++) {
                        stars[i].classList.add('active');
                    }
                });
            });
        })
        .catch(error => {
            console.error('Помилка при перевірці авторизації:', error);
            alert('Сталася помилка при перевірці авторизації');
        });
}

// Функція для відправки рецензії
async function submitReview(mediaId) {
    const content = document.getElementById('reviewContent').value;
    const rating = document.querySelectorAll('.star.active').length;
    const containsSpoilers = document.getElementById('containsSpoilers').checked;

    if (!content || !rating) {
        alert('Будь ласка, заповніть всі обов\'язкові поля');
        return;
    }

    try {
        const response = await fetch('/api/reviews', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                mediaId,
                content,
                rating,
                containsSpoilers
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Помилка при відправці рецензії');
        }

        // Очищаємо форму і оновлюємо список рецензій
        document.querySelector('.review-form').remove();
        loadReviews(mediaId);
    } catch (error) {
        console.error('Помилка:', error);
        alert(error.message || 'Сталася помилка при відправці рецензії');
    }
}

// Функція для завантаження рецензій
async function loadReviews(mediaId) {
    try {
        const response = await fetch(`/api/reviews/${mediaId}`);
        if (!response.ok) {
            throw new Error('Помилка при завантаженні рецензій');
        }

        const reviews = await response.json();

        const reviewsContainer = document.querySelector('.reviews-list');
        reviewsContainer.innerHTML = '';

        if (reviews.length === 0) {
            reviewsContainer.innerHTML = '<p class="no-reviews">Поки немає рецензій</p>';
            return;
        }

        reviews.forEach(review => {
            const reviewElement = document.createElement('div');
            reviewElement.className = 'review-item';
            reviewElement.innerHTML = `
                <div class="review-header">
                    <span class="review-author">${review.username}</span>
                    <div class="review-rating">
                        ${Array(5).fill().map((_, i) => `
                            <span class="star ${i < review.rating ? 'active' : ''}">★</span>
                        `).join('')}
                    </div>
                </div>
                ${review.contains_spoilers ? '<div class="spoiler-warning">⚠️ Містить спойлери</div>' : ''}
                <div class="review-content">${review.content}</div>
                <div class="review-date">${new Date(review.created_at).toLocaleDateString('uk-UA')}</div>
            `;
            reviewsContainer.appendChild(reviewElement);
        });
    } catch (error) {
        console.error('Помилка при завантаженні рецензій:', error);
        const reviewsContainer = document.querySelector('.reviews-list');
        reviewsContainer.innerHTML = '<p class="error-message">Помилка при завантаженні рецензій</p>';
    }
}