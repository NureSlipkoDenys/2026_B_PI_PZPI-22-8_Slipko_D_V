/* auth.js - functions for ABSOLUTE CINEMA authentication */

// Class for managing authentication
class AuthManager {
  constructor() {
    this.currentUser = null;
    this.isAuthenticated = false;
    this.authStateChanged = new EventTarget();
    
    // Interface elements
    this.loginButton = document.querySelector('.login-button a');
    this.authModal = document.getElementById('auth-modal');
    this.loginForm = document.getElementById('login-form');
    this.registerForm = document.getElementById('register-form');
    this.resetPasswordForm = document.getElementById('reset-password-form');
    
    // Initialization
    this.init();
  }
  
  // Authentication manager initialization
  async init() {
    // Check authentication status when page loads
    try {
      await this.checkAuthStatus();
    } catch (error) {
      console.error('Error checking authentication status:', error);
    }
    
    // Set up form event listeners
    this.setupEventListeners();
  }
  
  // Check current authentication status
  async checkAuthStatus() {
    try {
      const response = await fetch('/api/auth/status', {
        method: 'GET',
        credentials: 'include' // Important for sending cookies
      });
      
      const data = await response.json();
      
      if (data.authenticated && data.user) {
        this.isAuthenticated = true;
        this.currentUser = data.user;
        this.updateUI();
        
        // Notify subscribers of authentication status change
        const event = new CustomEvent('authStateChanged', { 
          detail: { isAuthenticated: true, user: this.currentUser } 
        });
        this.authStateChanged.dispatchEvent(event);
        
        // Get user profile data
        await this.fetchUserProfile();
      }
    } catch (error) {
      console.error('Error checking authentication status:', error);
    }
  }
  
  // Get user profile data
  async fetchUserProfile() {
    if (!this.isAuthenticated || !this.currentUser) {
      return null;
    }
    
    try {
      const response = await fetch('/api/profile', {
        method: 'GET',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Неможливо отримати дані профілю');
      }
      
      const data = await response.json();
      
      if (data.profile) {
        this.currentUser = {
          ...this.currentUser,
          profile: data.profile
        };
        
        // Update UI with new profile data
        this.updateUI();
      }
      
      return this.currentUser.profile;
    } catch (error) {
      console.error('Помилка при отриманні профілю:', error);
      return null;
    }
  }
  
  // Handle user login
  async login(emailOrUsername, password, remember = false) {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ emailOrUsername, password, remember }),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Помилка при вході');
      }
      
      this.isAuthenticated = true;
      this.currentUser = data.user;
      
      // Close modal and update UI
      this.closeModal();
      this.updateUI();
      
      // Get user profile data
      await this.fetchUserProfile();
      
      // Notify authentication status change
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: true, user: this.currentUser } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Show success notification
      this.showNotification('Ви успішно увійшли в систему', 'success');

      // Check if onboarding is needed
      await this.checkAndRedirectOnboarding();
      
      return { success: true, user: data.user };
    } catch (error) {
      console.error('Помилка входу:', error);
      this.showFormError(this.loginForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // Handle user registration
  async register(username, email, password) {
    try {
      console.log('Надсилання запиту на реєстрацію:', { username, email: email.slice(0, 3) + '***' });
      
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password }),
        credentials: 'include'
      });
      
      // Get response text for diagnostics
      const responseText = await response.text();
      console.log('Отримано відповідь від сервера:', responseText);
      
      // Try to parse JSON
      let data;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Помилка аналізу JSON:', parseError);
        throw new Error('Сервер повернув некоректну відповідь: ' + responseText);
      }
      
      if (!response.ok) {
        throw new Error(data.error || data.details || 'Помилка під час реєстрації');
      }
      
      this.isAuthenticated = true;
      this.currentUser = data.user;
      
      // Close modal and update UI
      this.closeModal();
      this.updateUI();
      
      // Notify authentication status change
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: true, user: this.currentUser } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Show success notification
      this.showNotification('Ви успішно зареєструвалися! Налаштуємо рекомендації...', 'success');

      // New users always go to onboarding
      setTimeout(() => { window.location.href = '/onboarding'; }, 1200);
      
      return { success: true, user: data.user };
    } catch (error) {
      console.error('Помилка реєстрації:', error);
      this.showFormError(this.registerForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // Reset password
  async resetPassword(email) {
    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email }),
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Помилка при скиданні пароля');
      }
      
      // Show notification about sending instructions
      this.showNotification('Інструкції для відновлення пароля надіслані на вашу електронну пошту', 'info');
      
      // Return to login form
      const loginTab = document.querySelector('.modal-tab[data-tab="login"]');
      if (loginTab) {
        loginTab.click();
      }
      
      return { success: true };
    } catch (error) {
      console.error('Помилка скидання пароля:', error);
      this.showFormError(this.resetPasswordForm, error.message);
      return { success: false, error: error.message };
    }
  }
  
  // User logout
  async logout() {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Помилка при виході');
      }
      
      this.isAuthenticated = false;
      this.currentUser = null;
      
      // Update UI
      this.updateUI();
      
      // Notify authentication status change
      const event = new CustomEvent('authStateChanged', { 
        detail: { isAuthenticated: false, user: null } 
      });
      this.authStateChanged.dispatchEvent(event);
      
      // Show notification
      this.showNotification('Ви вийшли з системи', 'info');

      // Reload page after successful logout
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
      return { success: true };
    } catch (error) {
      console.error('Помилка виходу:', error);
      return { success: false, error: error.message };
    }
  }
  
  // Update UI based on authentication status
  updateUI() {
    const loginButton = document.querySelector('.login-button a');
    if (!loginButton) return;
    
    // Remove existing event listeners to avoid duplication
    const loginButtonContainer = document.querySelector('.login-button');
    const oldClone = loginButtonContainer.cloneNode(true);
    const newClone = loginButtonContainer.cloneNode(true);
    loginButtonContainer.parentNode.replaceChild(newClone, loginButtonContainer);
    
    // Get updated element references after replacement
    const newLoginButton = newClone.querySelector('a');
    
    if (this.isAuthenticated && this.currentUser) {
      // If user is authenticated
      const username = this.currentUser.profile ? this.currentUser.profile.username : 'ПРОФІЛЬ';
      newLoginButton.innerHTML = `<i class="fas fa-user"></i> ${username}`;
      
      // IMPORTANT: Completely remove href attribute
      newLoginButton.removeAttribute('href');
      
      // Immediately create profile dropdown menu
      const dropdownHTML = `
        <div class="auth-dropdown" id="auth-dropdown">
          <div class="auth-dropdown-item profile-link"><a href="/profile"><i class="fas fa-id-card"></i> Мій профіль</a></div>
          <div class="auth-dropdown-divider"></div>
          <div class="auth-dropdown-item logout-btn"><i class="fas fa-sign-out-alt"></i> Вийти</div>
        </div>
      `;
      
      // Remove existing dropdown menu if it already exists
      const existingDropdown = newClone.querySelector('#auth-dropdown');
      if (existingDropdown) {
        existingDropdown.remove();
      }
      
      // Add new dropdown menu
      newClone.insertAdjacentHTML('beforeend', dropdownHTML);
      
      // Add class for styling
      newClone.classList.add('auth-active');
      
      // Event handler for profile button to show dropdown menu
      newClone.addEventListener('click', (e) => {
        // Stop link transition
        e.preventDefault();
        e.stopPropagation();
        
        console.log('Клік по кнопці профілю');
        
        // Toggle dropdown visibility
        const dropdown = newClone.querySelector('#auth-dropdown');
        if (dropdown) {
          dropdown.classList.toggle('active');
          console.log('Стан спадного меню:', dropdown.classList.contains('active') ? 'відкрито' : 'закрито');
        }
      });
      
      // Find all links in dropdown menu
      const profileLinkItem = newClone.querySelector('.profile-link');
      if (profileLinkItem) {
        const profileLink = profileLinkItem.querySelector('a');
        if (profileLink) {
          console.log('Знайдено посилання на профіль:', profileLink.href);
          
          profileLink.addEventListener('click', (e) => {
            // Event handler for profile link
            e.stopPropagation();
            console.log('Клік по посиланню профілю:', profileLink.href);
            
            // Close dropdown
            const dropdown = newClone.querySelector('#auth-dropdown');
            if (dropdown) {
              dropdown.classList.remove('active');
            }
            
            // DO NOT cancel default action, so link transition works
          });
        }
      }
      
      // Event handler for logout button (special case)
      const logoutBtn = newClone.querySelector('.logout-btn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
          e.stopPropagation(); // Prevent event bubbling
          this.logout();
        });
      }
      
      // Close dropdown on outside click
      document.addEventListener('click', (e) => {
        if (!newClone.contains(e.target)) {
          const dropdown = document.getElementById('auth-dropdown');
          if (dropdown && dropdown.classList.contains('active')) {
            dropdown.classList.remove('active');
          }
        }
      });
      
      // Update button link in object
      this.loginButton = newLoginButton;
    } else {
      // If user is not authenticated
      newLoginButton.innerHTML = `ВХІД / РЕЄСТРАЦІЯ`;
      newLoginButton.setAttribute('href', '/login');
      
      // Remove profile dropdown menu if it exists
      const authDropdown = newClone.querySelector('#auth-dropdown');
      if (authDropdown) {
        authDropdown.remove();
      }
      
      newClone.classList.remove('auth-active');
      
      // Add handler for opening modal on click
      newLoginButton.addEventListener('click', (e) => {
        e.preventDefault();
        this.openModal();
      });
      
      // Update button link in object
      this.loginButton = newLoginButton;
    }
  }
  
  // Set up form event listeners
  setupEventListeners() {
    // Remove click handler from login button from this method,
    // since it's now fully controlled by updateUI method
    
    // Close modal event handler
    if (this.authModal) {
      const closeButton = this.authModal.querySelector('.modal-close');
      const overlay = this.authModal.querySelector('.modal-overlay');
      
      if (closeButton) {
        closeButton.addEventListener('click', () => {
          this.closeModal();
        });
      }
      
      if (overlay) {
        overlay.addEventListener('click', () => {
          this.closeModal();
        });
      }
      
      // Tab switching
      const tabs = this.authModal.querySelectorAll('.modal-tab');
      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          // Remove active class from all tabs
          tabs.forEach(t => t.classList.remove('active'));
          
          // Add active class to selected tab
          tab.classList.add('active');
          
          // Hide all forms
          const forms = this.authModal.querySelectorAll('.modal-form');
          forms.forEach(form => form.classList.remove('active'));
          
          // Show selected form
          const formId = tab.getAttribute('data-tab') + '-form';
          const selectedForm = document.getElementById(formId);
          if (selectedForm) {
            selectedForm.classList.add('active');
          }
        });
      });
      
      // Login form event handler
      if (this.loginForm) {
        this.loginForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          const emailOrUsername = this.loginForm.querySelector('#login-email').value.trim();
          const password = this.loginForm.querySelector('#login-password').value;
          const remember = this.loginForm.querySelector('#remember')?.checked || false;
          
          if (!emailOrUsername || !password) {
            this.showFormError(this.loginForm, 'Будь ласка, заповніть всі поля');
            return;
          }
          
          await this.login(emailOrUsername, password, remember);
        });
        
        // Event handler for "Забули пароль?" link
        const forgotPasswordLink = this.loginForm.querySelector('.forgot-password');
        if (forgotPasswordLink) {
          forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Hide all forms
            const forms = this.authModal.querySelectorAll('.modal-form');
            forms.forEach(form => form.classList.remove('active'));
            
            // Show reset password form
            const resetForm = document.getElementById('reset-password-form');
            if (resetForm) {
              resetForm.classList.add('active');
            }
          });
        }
      }
      
      // Reset password form event handler
      if (this.resetPasswordForm) {
        this.resetPasswordForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          const email = this.resetPasswordForm.querySelector('#reset-email').value.trim();
          
          if (!email) {
            this.showFormError(this.resetPasswordForm, 'Будь ласка, введіть електронну пошту');
            return;
          }
          
          await this.resetPassword(email);
        });
        
        // Event handler for "Повернутися до форми входу" link
        const backToLoginLink = this.resetPasswordForm.querySelector('#back-to-login');
        if (backToLoginLink) {
          backToLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Switch to login tab
            const loginTab = document.querySelector('.modal-tab[data-tab="login"]');
            if (loginTab) {
              loginTab.click();
            }
          });
        }
      }
      
      // Register form event handler
      if (this.registerForm) {
        this.registerForm.querySelector('.auth-submit').addEventListener('click', async (e) => {
          e.preventDefault();
          
          // Disable button during request execution
          const submitButton = this.registerForm.querySelector('.auth-submit');
          const originalButtonText = submitButton.textContent;
          submitButton.disabled = true;
          submitButton.textContent = 'ОБРОБКА...';
          
          try {
            const username = this.registerForm.querySelector('#register-name').value.trim();
            const email = this.registerForm.querySelector('#register-email').value.trim();
            const password = this.registerForm.querySelector('#register-password').value;
            const passwordConfirm = this.registerForm.querySelector('#register-password-confirm').value;
            const termsAccepted = this.registerForm.querySelector('#terms')?.checked || false;
            
            // Form validation
            if (!username || !email || !password || !passwordConfirm) {
              this.showFormError(this.registerForm, 'Будь ласка, заповніть всі поля');
              return;
            }
            
            if (password !== passwordConfirm) {
              this.showFormError(this.registerForm, 'Паролі не співпадають');
              return;
            }
            
            if (!termsAccepted) {
              this.showFormError(this.registerForm, 'Необхідно прийняти правила сайту');
              return;
            }
            
            await this.register(username, email, password);
          } catch (error) {
            console.error('Помилка при обробці форми реєстрації:', error);
            this.showFormError(this.registerForm, 'Виникла помилка при обробці форми');
          } finally {
            // Restore button
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
          }
        });
      }
      
      // Event handlers for password visibility toggles
      const passwordToggles = this.authModal.querySelectorAll('.password-toggle');
      passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
          const passwordInput = toggle.previousElementSibling;
          if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggle.classList.remove('fa-eye');
            toggle.classList.add('fa-eye-slash');
          } else {
            passwordInput.type = 'password';
            toggle.classList.remove('fa-eye-slash');
            toggle.classList.add('fa-eye');
          }
        });
      });
    }
  }
  
  // Show error in form
  showFormError(form, errorMessage) {
    // Remove existing error message if it exists
    const existingError = form.querySelector('.form-error');
    if (existingError) {
      existingError.remove();
    }
    
    // Create element for displaying error
    const errorElement = document.createElement('div');
    errorElement.className = 'form-error';
    errorElement.textContent = errorMessage;
    
    // Insert error message before submit button
    const submitButton = form.querySelector('.auth-submit');
    form.insertBefore(errorElement, submitButton);
    
    // Shake animation for attracting attention
    form.classList.add('shake');
    setTimeout(() => {
      form.classList.remove('shake');
    }, 500);
  }
  
  // Show notification
  showNotification(message, type = 'info') {
    // Remove existing notification if it exists
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    // Add icon based on notification type
    let icon = '';
    switch (type) {
      case 'success':
        icon = '<i class="fas fa-check-circle"></i>';
        break;
      case 'error':
        icon = '<i class="fas fa-exclamation-circle"></i>';
        break;
      case 'warning':
        icon = '<i class="fas fa-exclamation-triangle"></i>';
        break;
      default:
        icon = '<i class="fas fa-info-circle"></i>';
    }
    
    // Form notification content
    notification.innerHTML = `
      ${icon}
      <span>${message}</span>
      <button class="notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Add notification to page
    document.body.appendChild(notification);
    
    // Add notification close handler
    const closeButton = notification.querySelector('.notification-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        notification.classList.add('closing');
        setTimeout(() => {
          notification.remove();
        }, 300);
      });
    }
    
    // Automatic notification hide after 5 seconds
    setTimeout(() => {
      if (document.body.contains(notification)) {
        notification.classList.add('closing');
        setTimeout(() => {
          if (document.body.contains(notification)) {
            notification.remove();
          }
        }, 300);
      }
    }, 5000);
  }
  
  // Open modal
  openModal() {
    if (this.authModal) {
      this.authModal.classList.add('active');
      document.body.classList.add('modal-open');
    }
  }
  
  // Close modal
  closeModal() {
    if (this.authModal) {
      this.authModal.classList.remove('active');
      document.body.classList.remove('modal-open');
    }
  }
  
  // Get current user
  getCurrentUser() {
    return this.currentUser;
  }
  
  // Check if user is authenticated
  isUserAuthenticated() {
    return this.isAuthenticated;
  }
  
  // Subscribe to authentication status change
  onAuthStateChanged(callback) {
    this.authStateChanged.addEventListener('authStateChanged', (event) => {
      callback(event.detail);
    });
  }

  // Check onboarding status and redirect if needed
  async checkAndRedirectOnboarding() {
    try {
      // Don't redirect if already on onboarding page
      if (window.location.pathname === '/onboarding') return;

      const res = await fetch('/api/onboarding/status', { credentials: 'include' });
      if (!res.ok) return;
      const data = await res.json();

      if (data.authenticated && data.needs_onboarding) {
        setTimeout(() => { window.location.href = '/onboarding'; }, 800);
      }
    } catch (err) {
      console.error('Error checking onboarding status:', err);
    }
  }
}

// Create and export AuthManager instance
const authManager = new AuthManager();

// Add route handler for login page
document.addEventListener('DOMContentLoaded', () => {
  // Check if current URL contains /login
  if (window.location.pathname === '/login') {
    // Open login modal with login form
    authManager.openModal();
  }
  
  // Check if current URL contains /register
  if (window.location.pathname === '/register') {
    // Open registration modal with registration form
    authManager.openModal();
    // Switch to registration tab
    const registerTab = document.querySelector('.modal-tab[data-tab="register"]');
    if (registerTab) {
      registerTab.click();
    }
  }
});

// Export authManager for use in other modules
window.authManager = authManager; 