// Ініціалізація змінних
let currentUser = null;
let currentChatId = null;
let chats = [];
let activeChatUser = null;
let isModalOpen = false;
let socket = null;

// DOM-елементи
const chatsList = document.getElementById('unified-chats-list');
const noChat = document.getElementById('no-chat-selected');
const activeChat = document.getElementById('active-chat');
const chatMessages = document.getElementById('chat-messages');
const chatHeader = document.getElementById('chat-header');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const newChatBtn = document.getElementById('new-chat-btn');
const newChatModal = document.getElementById('new-chat-modal');
const searchChatInput = document.getElementById('search-chat-input');
const searchUserInput = document.getElementById('search-user-input');
const searchUserBtn = document.getElementById('search-user-btn');
const searchResults = document.getElementById('search-results');
const emojiBtn = document.getElementById('emoji-btn');
const chatDeleteBtn = document.getElementById('chat-delete-btn');

// Подія завантаження DOM
document.addEventListener('DOMContentLoaded', async function() {
    // Ініціалізація компонентів
    initComponents();

    try {
        // Перевірка авторизації
        await checkAuth();

        // Завантаження чатів користувача
        if (currentUser) {
            await loadChats();
            // Відкриття чату за параметром chat
            const params = new URLSearchParams(window.location.search);
            const chatId = params.get('chat');
            if (chatId) {
                // Чекаємо, поки чати завантажаться, потім шукаємо потрібний чат
                const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
                if (chatItem) {
                    chatItem.click();
                } else {
                    // Якщо чат не знайдено (наприклад, щойно створений), пробуємо відкрити напряму
                    // Для цього потрібно знайти userId співрозмовника
                    // Можна спробувати знайти в масиві chats
                    const chatObj = chats.find(c => String(c.id) === String(chatId));
                    if (chatObj) {
                        const otherUserId = chatObj.user1_id === currentUser.user_id ? chatObj.user2.user_id : chatObj.user1.user_id;
                        openChat(chatId, otherUserId);
                    }
                }
            }
        } else {
            const ul = document.getElementById('unified-chats-list');
            if (ul) ul.innerHTML = '<div class="unified-empty"><div class="unified-empty-icon">😶</div><p>Увійдіть, щоб побачити чати</p></div>';
            showLoginPrompt();
        }
    } catch (error) {
        console.error('Помилка при ініціалізації:', error);
        const ul = document.getElementById('unified-chats-list');
        if (ul) ul.innerHTML = '<div class="unified-empty"><div class="unified-empty-icon">⚠️</div><p>Помилка завантаження</p></div>';
    }

    // Ініціалізація подій
    initEvents();

    // Ініціалізація емодзі-пікера
    initEmojiPicker();
});

// Ініціалізація компонентів сторінки
async function initComponents() {
    try {
        // Тут може бути додаткова ініціалізація компонентів
        console.log('Компоненти ініціалізовано');
    } catch (error) {
        console.error('Помилка при ініціалізації компонентів:', error);
    }
}

// Ініціалізація WebSocket з'єднання
function initWebSocket() {
    if (!currentUser) {
        console.log('initWebSocket: currentUser не визначено');
        return;
    }

    console.log('initWebSocket: Ініціалізація WebSocket для користувача', currentUser.user_id);

    // Закриваємо наявне з'єднання, якщо воно є
    if (socket) {
        console.log('initWebSocket: Закриваємо наявне з\'єднання');
        socket.close();
    }

    // Створюємо нове WebSocket з'єднання
    const wsUrl = `ws://${window.location.host}/ws/chat`;
    console.log('initWebSocket: Створюємо нове з\'єднання за URL', wsUrl);
    socket = new WebSocket(wsUrl);

    socket.onopen = async function(e) {
        console.log('WebSocket з\'єднання встановлено для користувача', currentUser.user_id);

        try {
            // Отримуємо токен через API
            console.log('Запитуємо токен через API');
            const response = await fetch('/api/auth/token');
            const data = await response.json();

            if (!data.token) {
                console.error('Токен не отримано від сервера');
                return;
            }

            console.log('Токен отримано, надсилаємо для автентифікації');
            // Надсилаємо токен для автентифікації
            socket.send(JSON.stringify({
                type: 'auth',
                token: data.token
            }));
            console.log('Токен надіслано для автентифікації');
        } catch (error) {
            console.error('Помилка при отриманні токена:', error);
        }
    };

    socket.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);
            console.log('Отримано повідомлення через WebSocket для користувача', currentUser.user_id, ':', data);

            switch (data.type) {
                case 'message':
                    // Якщо повідомлення для поточного чату — додаємо в DOM
                    if (String(data.chat_id) === String(currentChatId)) {
                        console.log('Додаємо нове повідомлення в чат:', data);
                        // Формуємо фейковий об'єкт повідомлення для buildMessageHTML
                        const wsMessage = {
                            sender_id: data.sender_id,
                            content: data.content,
                            sent_at: data.sent_at,
                            is_read: false
                        };
                        const isSentByMe = data.sender_id === currentUser.user_id;
                        const messageHTML = buildMessageHTML(wsMessage, isSentByMe);
                        chatMessages.insertAdjacentHTML('beforeend', messageHTML);
                        scrollToBottom();

                        // Одразу позначаємо як прочитане (чат відкрито)
                        if (data.sender_id !== currentUser.user_id) {
                            markMessagesAsRead(currentChatId);
                        }
                    } else {
                        // Повідомлення не для поточного чату — просто оновлюємо список і бейджик
                        loadChats();
                        updateUnreadBadge();
                    }
                    break;
                case 'message_read':
                    console.log('Отримано сповіщення про прочитання для чату:', data.chat_id, 'поточний чат:', currentChatId);
                    if (String(data.chat_id) === String(currentChatId)) {
                        // Оновлюємо статус усіх надісланих повідомлень на прочитано
                        document.querySelectorAll('.message-sent .msg-status').forEach(status => {
                            status.classList.add('read');
                            status.innerHTML = '<i class="far fa-eye"></i>';
                        });
                        console.log('Оновлено іконки прочитання в поточному чаті');
                    }
                    // Не викликаємо loadChats() — у відправника unread_count не змінюється
                    break;

                case 'message_sent':
                    console.log('Повідомлення успішно доставлено:', data);
                    // Можна додати візуальне підтвердження доставки
                    break;

                case 'message_error':
                    console.error('Помилка надсилання повідомлення:', data.error);
                    alert('Помилка надсилання повідомлення: ' + data.error);
                    break;

                case 'message_status':
                    if (data.status === 'recipient_offline') {
                        console.log('Отримувач не в мережі');
                        // Можна додати візуальне сповіщення
                    }
                    break;
            }
        } catch (error) {
            console.error('Помилка при обробці WebSocket повідомлення:', error);
        }
    };

    socket.onclose = function(event) {
        console.log('WebSocket з\'єднання закрито:', event.code, event.reason);
        // Намагаємося перепідключитися через 5 секунд
        setTimeout(initWebSocket, 5000);
    };

    socket.onerror = function(error) {
        console.error('WebSocket помилка:', error);
    };
}

// Модифікуємо функцію checkAuth
async function checkAuth() {
    try {
        const response = await fetch('/api/auth/status');
        const data = await response.json();

        if (data.authenticated) {
            currentUser = data.user;
            console.log('Користувач авторизований:', currentUser);

            // Завантажуємо повну інформацію про профіль
            const profileResponse = await fetch('/api/profile');
            const profileData = await profileResponse.json();

            if (profileData.profile) {
                currentUser = { ...currentUser, ...profileData.profile };
            }

            // Ініціалізуємо WebSocket після успішної авторизації
            initWebSocket();
        } else {
            console.log('Користувач не авторизований');
            currentUser = null;
        }
    } catch (error) {
        console.error('Помилка при перевірці авторизації:', error);
        throw error;
    }
}

// Показати повідомлення про необхідність входу
function showLoginPrompt() {
    noChat.innerHTML = `
        <div class="login-prompt">
            <div class="login-icon">
                <i class="fas fa-user-lock"></i>
            </div>
            <h2>Увійдіть в акаунт</h2>
            <p>Щоб почати спілкування, потрібно увійти або зареєструватися</p>
            <button class="login-btn" onclick="openAuthModal()">
                <i class="fas fa-sign-in-alt"></i> ВХІД/РЕЄСТРАЦІЯ
            </button>
        </div>
    `;
}

// Завантаження і рендер ЄДИНОГО об'єднаного списку чатів
let loadChatsInProgress = false;
async function loadChats() {
    return loadUnifiedChats();
}

async function loadUnifiedChats() {
    if (loadChatsInProgress) return;
    loadChatsInProgress = true;
    const listEl = document.getElementById('unified-chats-list');
    try {
        const [chatsRes, groupsRes] = await Promise.all([
            fetch(`/api/chats?t=${Date.now()}`, { headers: { 'Cache-Control': 'no-cache' } }),
            fetch('/api/group-chats', { credentials: 'include' })
        ]);
        const chatsData = await chatsRes.json();
        const groupsData = await groupsRes.json();
        chats = chatsData.chats || [];

        const personal = chats.map(c => ({ ...c, _type: 'personal', _sortDate: c.last_message ? new Date(c.last_message.sent_at) : new Date(0) }));
        const groups   = (groupsData.groups || []).map(g => ({ ...g, _type: 'group', _sortDate: g.last_message ? new Date(g.last_message.sent_at) : new Date(0) }));
        const all = [...personal, ...groups].sort((a, b) => b._sortDate - a._sortDate);

        if (!listEl) { loadChatsInProgress = false; return; }

        if (all.length === 0) {
            listEl.innerHTML = `<div class="unified-empty"><div class="unified-empty-icon">🎬</div><p>Немає чатів — почніть спілкування!</p></div>`;
            loadChatsInProgress = false;
            updateUnreadBadge();
            return;
        }

        listEl.innerHTML = all.map(item => item._type === 'personal' ? buildPersonalItemHTML(item) : buildGroupItemHTML(item)).join('');

        listEl.querySelectorAll('.chat-item:not(.group-chat-item)').forEach(el => {
            el.addEventListener('click', () => openChat(el.dataset.chatId, el.dataset.userId));
        });
        listEl.querySelectorAll('.group-chat-item').forEach(el => {
            el.addEventListener('click', () => openGroupChat(el.dataset.groupId));
        });
        updateUnreadBadge();
    } catch (e) {
        console.error('loadUnifiedChats error:', e);
        if (listEl) listEl.innerHTML = `<div class="unified-empty"><div class="unified-empty-icon">⚠️</div><p>Помилка завантаження</p></div>`;
    } finally {
        loadChatsInProgress = false;
    }
}

function buildPersonalItemHTML(chat) {
    const otherUser = chat.user1_id === currentUser.user_id ? chat.user2 : chat.user1;
    const up = otherUser && otherUser.profile ? otherUser.profile : otherUser;
    const time = chat.last_message ? formatTime(new Date(chat.last_message.sent_at)) : '';
    const isActive = String(chat.id) === String(currentChatId);
    const preview = getLastMessagePreview(chat.last_message);
    return `<div class="chat-item${isActive ? ' active' : ''}" data-chat-id="${chat.id}" data-user-id="${up.user_id}">
        <div class="chat-avatar"><img src="${up.avatar_url || 'https://via.placeholder.com/50'}" alt="${up.username}"></div>
        <div class="chat-preview"><div class="chat-preview-row"><h3>${up.username}</h3></div><p>${preview}</p></div>
        <div class="chat-meta"><div class="chat-time">${time}</div>${chat.unread_count > 0 ? `<div class="chat-unread">${chat.unread_count}</div>` : ''}</div>
    </div>`;
}

function buildGroupItemHTML(g) {
    const preview = getGroupPreview(g.last_message);
    const time = g.last_message ? formatTime(new Date(g.last_message.sent_at)) : '';
    const isActive = String(g.id) === String(typeof currentGroupId !== 'undefined' ? currentGroupId : null);
    return `<div class="chat-item group-chat-item${isActive ? ' active' : ''}" data-group-id="${g.id}">
        <div class="chat-avatar group-avatar-icon"><i class="fas fa-users"></i></div>
        <div class="chat-preview"><div class="chat-preview-row"><h3>${g.name}</h3><span class="chat-group-badge"><i class="fas fa-users"></i> Група</span></div><p>${preview}</p></div>
        <div class="chat-meta"><div class="chat-time">${time}</div>${g.unread_count > 0 ? `<div class="chat-unread">${g.unread_count}</div>` : ''}</div>
    </div>`;
}

function getGroupPreview(msg) {
    if (!msg) return 'Немає повідомлень';
    try {
        const p = JSON.parse(msg.content);
        if (p.type === 'system') return `• ${p.text}`;
        if (p.type === 'movie_repost') return `🎬 ${p.title || 'Фільм'}`;
        if (p.type === 'forwarded') return `↪ Переслано від ${p.original_username}`;
    } catch {}
    return msg.content.length > 50 ? msg.content.slice(0, 50) + '…' : msg.content;
}

// Допоміжна: отримати текстовий превʼю останнього повідомлення
function getLastMessagePreview(message) {
    if (!message) return 'Немає повідомлень';
    try {
        const parsed = JSON.parse(message.content);
        if (parsed && parsed.type === 'movie_repost') return `🎬 ${parsed.title || 'Фільм'}`;
        if (parsed && parsed.type === 'forwarded') return `↪ Переслане від ${parsed.original_username || 'користувача'}`;
    } catch {}
    return message.content;
}

// Залишаємо renderChats як alias (для сумісності)
function renderChats() { loadUnifiedChats(); }

// Відкриття чату
async function openChat(chatId, userId) {
    // Скидаємо стан групового чату
    if (typeof currentGroupId !== 'undefined') {
        currentGroupId = null;
    }

    // Показуємо кнопку видалення, ховаємо групові кнопки
    const deleteBtn = document.getElementById('chat-delete-btn');
    const settingsBtn = document.getElementById('group-settings-btn');
    const leaveBtn = document.getElementById('group-leave-btn');
    if (deleteBtn) deleteBtn.style.display = '';
    if (settingsBtn) settingsBtn.style.display = 'none';
    if (leaveBtn) leaveBtn.style.display = 'none';

    // Повертаємо аватар якщо він був захований
    const avatarEl = document.getElementById('chat-user-avatar');
    if (avatarEl) avatarEl.style.display = '';

    // Зберігаємо як число для одноманітності порівнянь
    currentChatId = String(chatId);

    // Видаляємо активний клас з усіх чатів і додаємо новому
    document.querySelectorAll('.chat-item').forEach(item => {
        item.classList.remove('active');
    });
    // Знімаємо активний клас з групових
    document.querySelectorAll('.group-chat-item').forEach(item => {
        item.classList.remove('active');
    });
    
    const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
    if (chatItem) {
        chatItem.classList.add('active');
    }
    
    // Показуємо вікно активного чату
    noChat.style.display = 'none';
    activeChat.style.display = 'flex';

    // Завантажуємо інформацію про користувача
    await loadChatUser(userId);

    // Завантажуємо повідомлення
    await loadMessages(chatId);

    // Позначаємо повідомлення як прочитані (не чекаємо — оновлюємо UI одразу)
    markMessagesAsRead(chatId);
}

// Завантаження інформації про користувача чату
async function loadChatUser(userId) {
    try {
        console.log('loadChatUser отримує userId:', userId, 'currentUser:', currentUser.user_id);
        const response = await fetch(`/api/users/${userId}`);
        const data = await response.json();
        if (response.ok) {
            const userProfile = data.profile;
            activeChatUser = userProfile;
            console.log('Отримано інформацію про користувача:', activeChatUser);
            // Оновлюємо заголовок чату
            document.getElementById('chat-user-name').textContent = activeChatUser.username;
            document.getElementById('chat-user-avatar').src = activeChatUser.avatar_url || 'https://via.placeholder.com/40';
            // Відображаємо біографію користувача
            const userBioElement = document.getElementById('chat-user-bio');
            if (userBioElement) {
                userBioElement.textContent = activeChatUser.bio || 'Біографія відсутня';
            }
            // Додаємо можливість переходу на профіль користувача
            const userNameElement = document.getElementById('chat-user-name');
            const userAvatarElement = document.getElementById('chat-user-avatar').parentElement;
            userNameElement.style.cursor = 'pointer';
            userAvatarElement.style.cursor = 'pointer';
            userNameElement.onclick = () => {
                console.log('Перехід на профіль співрозмовника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
            userAvatarElement.onclick = () => {
                console.log('Перехід на профіль співрозмовника:', activeChatUser.user_id);
                window.location.href = `/profile.html?id=${activeChatUser.user_id}`;
            };
        } else {
            console.error('Помилка при завантаженні користувача:', data.error);
        }
    } catch (error) {
        console.error('Помилка при завантаженні користувача:', error);
    }
}

// Завантаження повідомлень чату
async function loadMessages(chatId) {
    try {
        chatMessages.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Завантаження повідомлень...</p></div>';
        const response = await fetch(`/api/chats/${chatId}/messages?t=${new Date().getTime()}`, {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
        const data = await response.json();

        if (response.ok) {
            renderMessages(data.messages || []);
        } else {
            console.error('Помилка при завантаженні повідомлень:', data.error);
            chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
        }
    } catch (error) {
        console.error('Помилка при завантаженні повідомлень:', error);
        chatMessages.innerHTML = '<div class="error-message">Помилка завантаження повідомлень</div>';
    }
}

// Функція для автоматичної прокрутки чату
function scrollToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    if (chatMessages) {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

// Стан відповіді
let replyingTo = null; // { id, content, sender_username }

// Допоміжна: отримати текстовий прев'ю для цитати
function getReplyPreviewText(content) {
    try {
        const p = JSON.parse(content);
        if (p && p.type === 'movie_repost') return `🎬 ${p.title || 'Фільм'}`;
    } catch {}
    return content.length > 80 ? content.slice(0, 80) + '…' : content;
}

// Допоміжна функція: рендер одного повідомлення (текст або картка фільму)
function buildMessageHTML(message, isSent) {
    const messageClass = isSent ? 'message-sent' : 'message-received';
    const messageTime = formatTime(new Date(message.sent_at));
    const msgId = message.id ? `data-msg-id="${message.id}"` : '';

    let statusHTML = '';
    if (isSent) {
        statusHTML = message.is_read
            ? '<span class="msg-status read"><i class="far fa-eye"></i></span>'
            : '<span class="msg-status"><i class="fas fa-check"></i></span>';
    }

    // Цитата (відповідь на повідомлення)
    let replyHTML = '';
    if (message.reply_to) {
        const rt = message.reply_to;
        const rtPreview = getReplyPreviewText(rt.content);
        replyHTML = `
            <a class="msg-reply-quote" href="#msg-${rt.id}" onclick="scrollToMessage(${rt.id})">
                <span class="msg-reply-author">${rt.sender_username || 'Користувач'}</span>
                <span class="msg-reply-text">${rtPreview}</span>
            </a>
        `;
    }

    // Контент повідомлення
    let contentHTML = '';
    try {
        const parsed = JSON.parse(message.content);
        if (parsed && parsed.type === 'movie_repost') {
            const year = parsed.release_date ? new Date(parsed.release_date).getFullYear() : '';
            const rating = parsed.imdb_rating ? `<span class="chat-movie-rating"><i class="fas fa-star"></i> ${parsed.imdb_rating}</span>` : '';
            contentHTML = `
                <a href="${parsed.url}" class="chat-movie-card" title="Відкрити фільм">
                    <div class="chat-movie-poster">
                        ${parsed.poster_url
                            ? `<img src="${parsed.poster_url}" alt="${parsed.title}">`
                            : `<div class="chat-movie-no-poster"><i class="fas fa-film"></i></div>`
                        }
                    </div>
                    <div class="chat-movie-info">
                        <div class="chat-movie-label"><i class="fas fa-share-alt"></i> Поділився фільмом</div>
                        <div class="chat-movie-title">${parsed.title}</div>
                        <div class="chat-movie-meta">${year ? year : ''}${rating}</div>
                        <div class="chat-movie-link">Натисніть, щоб переглянути <i class="fas fa-arrow-right"></i></div>
                    </div>
                </a>
            `;
        } else if (parsed && parsed.type === 'forwarded') {
            // Переслане повідомлення — посилання на профіль через /profile.html?id=UUID
            const isOwnMsg = parsed.original_user_id && currentUser && parsed.original_user_id === currentUser.user_id;
            const authorUrl = `/profile.html?id=${parsed.original_user_id}`;
            const innerPreview = getReplyPreviewText(parsed.original_content);
            contentHTML = `
                <div class="msg-forwarded">
                    <div class="msg-forwarded-header">
                        <i class="fas fa-share"></i> Переслано від
                        <a href="${authorUrl}" class="msg-forwarded-author" onclick="event.stopPropagation()">${parsed.original_username}</a>
                    </div>
                    <div class="msg-forwarded-text">${innerPreview}</div>
                </div>
            `;
        } else {
            contentHTML = message.content;
        }
    } catch {
        contentHTML = message.content;
    }

    // Кнопки дій під повідомленням
    const msgIdVal = message.id || 0;
    const actionsHTML = `
        <div class="msg-actions">
            <button class="msg-action-btn reply-btn" onclick="startReply(${msgIdVal})" title="Відповісти">
                <i class="fas fa-reply"></i> Відповісти
            </button>
            <button class="msg-action-btn forward-btn" onclick="openForwardModal(${msgIdVal})" title="Переслати">
                <i class="fas fa-share"></i> Переслати
            </button>
        </div>
    `;

    return `
        <div class="message ${messageClass}" id="msg-${msgIdVal}" ${msgId}>
            ${replyHTML}
            <div class="message-content">${contentHTML}</div>
            <div class="message-meta">
                <span class="message-time">${messageTime}</span>
                ${statusHTML}
            </div>
            ${actionsHTML}
        </div>
    `;
}

// ============================================================
// REPLY — відповідь на повідомлення
// ============================================================
function startReply(msgId) {
    // Знаходимо повідомлення в DOM
    const msgEl = document.getElementById(`msg-${msgId}`);
    if (!msgEl) return;

    const contentEl = msgEl.querySelector('.message-content');
    const rawContent = contentEl ? contentEl.innerText || contentEl.textContent : '';
    const isSent = msgEl.classList.contains('message-sent');

    // Для групових чатів — беремо ім'я з .group-msg-name,
    // для особистих — з activeChatUser
    let authorName;
    if (isSent) {
        authorName = currentUser?.username || 'Ви';
    } else {
        const groupSenderEl = msgEl.querySelector('.group-msg-name');
        authorName = groupSenderEl
            ? groupSenderEl.textContent.trim()
            : (activeChatUser?.username || 'Співрозмовник');
    }

    // Отримуємо sender_username з DOM або з даних
    const msgIdAttr = parseInt(msgEl.getAttribute('data-msg-id') || msgId);

    replyingTo = {
        id: msgIdAttr,
        content: rawContent,
        sender_username: authorName
    };

    // Показуємо reply bar
    const replyBar = document.getElementById('reply-bar');
    const replyAuthor = document.getElementById('reply-bar-author');
    const replyPreview = document.getElementById('reply-bar-preview');
    if (replyBar) replyBar.style.display = 'flex';
    if (replyAuthor) replyAuthor.textContent = authorName;
    if (replyPreview) replyPreview.textContent = rawContent.length > 60 ? rawContent.slice(0, 60) + '…' : rawContent;

    // Фокус на поле вводу
    const chatInput = document.getElementById('chat-input');
    if (chatInput) chatInput.focus();
}

function cancelReply() {
    replyingTo = null;
    const replyBar = document.getElementById('reply-bar');
    if (replyBar) replyBar.style.display = 'none';
}

// Якірний перехід до оригінального повідомлення
function scrollToMessage(msgId) {
    const el = document.getElementById(`msg-${msgId}`);
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('msg-highlight');
    setTimeout(() => el.classList.remove('msg-highlight'), 1500);
}

// ============================================================
// FORWARD — переслати повідомлення в інший чат
// ============================================================
let forwardingMsgId = null;

function openForwardModal(msgId) {
    forwardingMsgId = msgId;
    const modal = document.getElementById('forwardMsgModal');
    const chatsList = document.getElementById('forwardChatsList');
    const preview = document.getElementById('forwardMsgPreview');
    if (!modal) return;

    // Preview оригінального повідомлення
    const msgEl = document.getElementById(`msg-${msgId}`);
    if (preview && msgEl) {
        const contentEl = msgEl.querySelector('.message-content');
        const text = contentEl ? (contentEl.innerText || contentEl.textContent || '').slice(0, 100) : '';
        preview.textContent = text + (text.length >= 100 ? '…' : '');
    }

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    chatsList.innerHTML = '<div class="share-modal-loading"><i class="fas fa-spinner fa-spin"></i> Завантаження чатів...</div>';

    fetch(`/api/chats?t=${Date.now()}`, { credentials: 'include' })
        .then(r => r.json())
        .then(data => {
            const chats = data.chats || [];
            if (chats.length === 0) {
                chatsList.innerHTML = '<div class="share-modal-loading">Немає доступних чатів</div>';
                return;
            }
            chatsList.innerHTML = chats.map(chat => {
                const otherUser = chat.user1_id === currentUser.user_id ? chat.user2 : chat.user1;
                const profile = otherUser?.profile || otherUser;
                const avatar = profile?.avatar_url || 'https://via.placeholder.com/44';
                const name = profile?.username || 'Користувач';
                return `
                    <div class="forward-chat-item" data-chat-id="${chat.id}">
                        <img src="${avatar}" alt="${name}" class="share-chat-avatar">
                        <span class="share-chat-name">${name}</span>
                        <button class="forward-send-btn" data-chat-id="${chat.id}">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                `;
            }).join('');

            // Обробники
            chatsList.querySelectorAll('.forward-send-btn').forEach(btn => {
                btn.addEventListener('click', async () => {
                    const targetChatId = btn.getAttribute('data-chat-id');
                    await forwardMessageToChat(msgId, targetChatId, btn);
                });
            });
        })
        .catch(() => {
            chatsList.innerHTML = '<div class="share-modal-loading">Помилка завантаження</div>';
        });
}

function closeForwardModal() {
    const modal = document.getElementById('forwardMsgModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
    forwardingMsgId = null;
}

async function forwardMessageToChat(msgId, targetChatId, btn) {
    // Знаходимо оригінальне повідомлення
    const msgEl = document.getElementById(`msg-${msgId}`);
    if (!msgEl) return;

    const contentEl = msgEl.querySelector('.message-content');
    const originalText = contentEl ? (contentEl.innerText || contentEl.textContent || '').trim() : '';
    const isSentByMe = msgEl.classList.contains('message-sent');
    const authorName = isSentByMe ? (currentUser?.username || 'Ви') : (activeChatUser?.username || 'Співрозмовник');
    const authorId = isSentByMe ? currentUser.user_id : (activeChatUser?.user_id || '');

    // Формуємо forwarded JSON
    const forwardContent = JSON.stringify({
        type: 'forwarded',
        original_content: originalText,
        original_username: authorName,
        original_user_id: authorId
    });

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    try {
        const res = await fetch(`/api/chats/${targetChatId}/messages`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ content: forwardContent })
        });
        if (res.ok) {
            btn.innerHTML = '<i class="fas fa-check"></i>';
            btn.classList.add('sent');
            setTimeout(() => closeForwardModal(), 900);
        } else {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-paper-plane"></i>';
        }
    } catch {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-paper-plane"></i>';
    }
}

// Відображення повідомлень чату
function renderMessages(messages) {
    if (messages.length === 0) {
        chatMessages.innerHTML = '<div class="empty-messages"></div>';
        return;
    }
    
    let messagesHTML = '';
    messages.forEach(message => {
        const isSent = message.sender_id === currentUser.user_id;
        messagesHTML += buildMessageHTML(message, isSent);
    });
    
    chatMessages.innerHTML = messagesHTML;
    scrollToBottom();
}

// Модифікуємо функцію sendMessage
async function sendMessage() {
    // Якщо відкритий груповий чат — делегуємо
    if (typeof currentGroupId !== 'undefined' && currentGroupId) {
        if (typeof sendGroupMessage === 'function') sendGroupMessage();
        return;
    }

    if (!currentChatId || !chatInput.value.trim()) {
        return;
    }
    
    const messageContent = chatInput.value.trim();
    const currentReplyTo = replyingTo ? { ...replyingTo } : null;
    
    try {
        console.log('Надсилання повідомлення в чат:', currentChatId);

        const body = { content: messageContent };
        if (currentReplyTo) body.reply_to_id = currentReplyTo.id;

        const response = await fetch(`/api/chats/${currentChatId}/messages`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            console.log('Повідомлення успішно надіслано:', data.message);
            chatInput.value = '';
            cancelReply(); // скидаємо reply після відправки
            
            // Будуємо HTML нового повідомлення з reply_to якщо є
            const message = data.message;
            const messageHTML = buildMessageHTML(message, true);
            chatMessages.insertAdjacentHTML('beforeend', messageHTML);
            scrollToBottom();

            // Відправляємо через WebSocket
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.send(JSON.stringify({
                    type: 'message',
                    chat_id: currentChatId,
                    content: messageContent,
                    sender_id: currentUser.user_id,
                    sent_at: message.sent_at,
                    reply_to_id: currentReplyTo?.id || null
                }));
                console.log('Повідомлення надіслано через WebSocket');
            }
        } else {
            console.error('Помилка при надсиланні повідомлення:', data.error);
            alert('Помилка відправки повідомлення: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Помилка при надсиланні повідомлення:', error);
        alert('Помилка відправки повідомлення: ' + error.message);
    }
}

// Позначення повідомлень як прочитаних
async function markMessagesAsRead(chatId) {
    const readingChatId = String(chatId);
    try {
        const response = await fetch(`/api/chats/${chatId}/read`, {
            method: 'POST'
        });

        if (!response.ok) {
            console.error('Помилка сервера при позначенні прочитаними:', await response.text());
            return;
        }

        console.log(`Повідомлення в чаті ${chatId} позначені як прочитані на сервері`);

        // Одразу прибираємо бейджик у сайдбарі (без повної перемальовки)
        const chatItem = document.querySelector(`.chat-item[data-chat-id="${chatId}"]`);
        if (chatItem) {
            const badge = chatItem.querySelector('.chat-unread');
            if (badge) badge.remove();
        }

        // Оновлюємо список чатів — хедер-бейджик оновиться всередині loadChats() після оновлення chats[]
        loadChats();
    } catch (error) {
        console.error('Помилка при позначенні повідомлень як прочитаних:', error);
    }
}

// Створення нового чату
async function createChat(userId) {
    try {
        const response = await fetch('/api/chats', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Закриваємо модальне вікно
            closeModal();

            // Оновлюємо список чатів
            await loadChats();

            // Відкриваємо новий чат
            openChat(data.chat.id, userId);
        } else {
            console.error('Помилка при створенні чату:', data.error);
            alert('Помилка створення чату');
        }
    } catch (error) {
        console.error('Помилка при створенні чату:', error);
        alert('Помилка створення чату');
    }
}

// Пошук користувачів
async function searchUsers(query) {
    if (!query.trim()) {
        searchResults.innerHTML = '';
        return;
    }
    
    try {
        searchResults.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Пошук користувачів...</p></div>';
        
        const response = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`);
        const data = await response.json();
        
        if (response.ok) {
            renderSearchResults(data.users || []);
        } else {
            console.error('Помилка при пошуку користувачів:', data.error);
            searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
        }
    } catch (error) {
        console.error('Помилка при пошуку користувачів:', error);
        searchResults.innerHTML = '<div class="error-message">Помилка пошуку користувачів</div>';
    }
}

// Відображення результатів пошуку користувачів
function renderSearchResults(users) {
    if (users.length === 0) {
        searchResults.innerHTML = '<div class="empty-results">Користувачів не знайдено</div>';
        return;
    }
    
    let resultsHTML = '';
    
    users.forEach(user => {
        // Пропускаємо поточного користувача
        if (user.user_id === currentUser.user_id) {
            return;
        }
        
        resultsHTML += `
            <div class="user-result" data-user-id="${user.user_id}">
                <div class="user-result-avatar">
                    <img src="${user.avatar_url || 'https://via.placeholder.com/40'}" alt="${user.username}">
                </div>
                <div class="user-result-details">
                    <h3>${user.username}</h3>
                    <p>${user.bio ? user.bio.substring(0, 50) + (user.bio.length > 50 ? '...' : '') : 'Немає інформації'}</p>
                </div>
            </div>
        `;
    });
    
    searchResults.innerHTML = resultsHTML;

    // Додаємо обробники для кожного результату
    document.querySelectorAll('.user-result').forEach(item => {
        item.addEventListener('click', function() {
            const userId = this.getAttribute('data-user-id');
            createChat(userId);
        });
    });
}

// Відкриття модального вікна
function openModal() {
    newChatModal.style.display = 'flex';
    searchUserInput.value = '';
    searchResults.innerHTML = '';
    isModalOpen = true;
}

// Закриття модального вікна
function closeModal() {
    newChatModal.style.display = 'none';
    isModalOpen = false;
}

// Пошук чатів — єдиний список
function filterChats(query) {
    const q = query.toLowerCase();
    document.querySelectorAll('#unified-chats-list .chat-item').forEach(item => {
        const name = (item.querySelector('h3')?.textContent || '').toLowerCase();
        const msg  = (item.querySelector('p')?.textContent  || '').toLowerCase();
        item.style.display = (!q || name.includes(q) || msg.includes(q)) ? 'flex' : 'none';
    });
}

// Відкриття модального вікна авторизації
function openAuthModal() {
    // Якщо є функція з auth.js, викликаємо її
    if (typeof showAuthModal === 'function') {
        showAuthModal('login');
    } else {
        alert('Для спілкування в чаті потрібно авторизуватися');
    }
}

// Форматування часу
function formatTime(date) {
    // Отримуємо поточну дату
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    // Перевіряємо, чи сьогодні повідомлення
    if (date > today) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    // Перевіряємо, чи вчора повідомлення
    if (date > yesterday) {
        return 'Вчора';
    }

    // Інакше повертаємо дату
    return date.toLocaleDateString();
}

// Ініціалізація емодзі-пікера
function initEmojiPicker() {
    // Перевіряємо, чи завантажена бібліотека
    if (typeof EmojiButton !== 'function') {
        // Якщо бібліотека не завантажена, підключаємо її
        const emojiScript = document.createElement('script');
        emojiScript.src = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/index.min.js';
        document.head.appendChild(emojiScript);
        
        const emojiCSS = document.createElement('link');
        emojiCSS.rel = 'stylesheet';
        emojiCSS.href = 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@3.1.1/dist/css/emoji-button.min.css';
        document.head.appendChild(emojiCSS);
        
        emojiScript.onload = setupEmojiPicker;
    } else {
        setupEmojiPicker();
    }
}

// Налаштування емодзі-пікера
function setupEmojiPicker() {
    if (!emojiBtn) return;
    
    const picker = new EmojiButton({
        position: 'top-start',
        theme: 'dark',
        autoHide: false,
        showVariants: true,
        emojiSize: '1.5em'
    });
    
    picker.on('emoji', emoji => {
        chatInput.value += emoji;
        chatInput.focus();
    });
    
    emojiBtn.addEventListener('click', () => {
        picker.togglePicker(emojiBtn);
    });
}

// Видалення чату
async function deleteChat(chatId) {
    if (!confirm('Ви впевнені, що хочете видалити цю переписку? Це не можна буде скасувати.')) {
        return;
    }

    try {
        console.log('Видалення чату з ID:', chatId);

        const response = await fetch(`/api/chats/${chatId}`, {
            method: 'DELETE'
        });

        const responseText = await response.text();
        console.log('Відповідь сервера при видаленні чату:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (parseError) {
            console.error('Помилка парсингу відповіді при видаленні чату:', parseError);
            alert('Помилка при видаленні чату: невірний формат відповіді');
            return;
        }

        if (response.ok) {
            console.log('Чат успішно видалено:', data);

            // Закриваємо чат
            currentChatId = null;
            activeChat.style.display = 'none';
            noChat.style.display = 'flex';

            // Оновлюємо список чатів
            await loadChats();
        } else {
            console.error('Помилка при видаленні чату:', data.error);
            alert('Помилка при видаленні чату: ' + (data.error || 'Невідома помилка'));
        }
    } catch (error) {
        console.error('Помилка при видаленні чату:', error);
        alert('Помилка при видаленні чату: ' + error.message);
    }
}

// Ініціалізація обробників подій
function initEvents() {
    // Надсилання повідомлення при натисканні кнопки
    sendBtn.addEventListener('click', sendMessage);

    // Надсилання повідомлення при натисканні Enter (без Shift)
    chatInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Скасування відповіді
    const replyBarCancel = document.getElementById('reply-bar-cancel');
    if (replyBarCancel) replyBarCancel.addEventListener('click', cancelReply);

    // Закриття forward modal
    const forwardModalClose = document.getElementById('forwardModalClose');
    if (forwardModalClose) forwardModalClose.addEventListener('click', closeForwardModal);
    const forwardModal = document.getElementById('forwardMsgModal');
    if (forwardModal) forwardModal.addEventListener('click', e => { if (e.target === forwardModal) closeForwardModal(); });

    // Відкриття модального вікна для нового чату
    newChatBtn.addEventListener('click', openModal);

    // Закриття модального вікна - використовуємо всі кнопки закриття на сторінці
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', closeModal);
    });

    // Закриття модального вікна при кліку поза ним
    newChatModal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });

    // Пошук користувачів
    searchUserBtn.addEventListener('click', function() {
        searchUsers(searchUserInput.value);
    });

    // Пошук користувачів при натисканні Enter
    searchUserInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            searchUsers(searchUserInput.value);
        }
    });

    // Пошук чатів
    searchChatInput.addEventListener('input', function() {
        filterChats(this.value);
    });

    // Закриття модального вікна при натисканні Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            if (isModalOpen) closeModal();
            cancelReply();
            closeForwardModal();
        }
    });

    // Видалення чату
    if (chatDeleteBtn) {
        chatDeleteBtn.addEventListener('click', function() {
            if (currentChatId) {
                deleteChat(currentChatId);
            }
        });
    }

    // Ініціалізуємо події рекомендацій, якщо вони є
    initRecommendationsEvents();
}

// Ініціалізація подій для рекомендацій
function initRecommendationsEvents() {
    // Обробники для кнопок "Почати чат" з рекомендованими користувачами
    const startChatButtons = document.querySelectorAll('.start-chat-btn');
    startChatButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Отримуємо ім'я користувача з батьківської картки
            const userName = this.closest('.user-card').querySelector('h4').textContent;

            // Заглушка - створюємо заглушку для демонстрації
            alert(`Початок нового чату з користувачем ${userName}. В реальному додатку тут буде створено новий чат.`);

            // У реальному застосунку тут має бути код для створення чату
            // createChat(userId);
        });
    });
}

// Функція для оновлення індикатора непрочитаних — делегуємо до глобальної
// (unread-badge.js рахує і особисті, і групові чати)
function updateUnreadBadge() {
    if (typeof updateUnreadBadgeGlobal === 'function') {
        updateUnreadBadgeGlobal();
    }
}