/**
 * onboarding.js — Tinder-style movie swipe mini-game
 * ABSOLUTE CINEMA Recommendation Onboarding
 */

// ---- State ----
let movies = [];        // All movies for swipe
let cards = [];         // DOM card elements
let currentIndex = 0;   // Index of top card's movie
let likedMovies = [];   // Movies the user liked
let history = [];       // Action history for undo
const TOTAL_CARDS = 10;

// Swipe state
let isDragging = false;
let startX = 0, startY = 0;
let currentX = 0, currentY = 0;
let topCard = null;

// ---- DOM ----
const stepWelcome  = document.getElementById('step-welcome');
const stepGame     = document.getElementById('step-game');
const stepResults  = document.getElementById('step-results');
const cardStack    = document.getElementById('ob-card-stack');
const progressBar  = document.getElementById('ob-progress-bar');
const progressText = document.getElementById('ob-progress-text');
const indicatorLike    = document.getElementById('ob-indicator-like');
const indicatorDislike = document.getElementById('ob-indicator-dislike');
const btnLike    = document.getElementById('btn-like');
const btnDislike = document.getElementById('btn-dislike');
const btnUndo    = document.getElementById('btn-undo');

// ---- Particles ----
(function initParticles() {
    const canvas = document.getElementById('ob-particles');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const resize = () => {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const particles = Array.from({ length: 40 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.3,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        o: Math.random() * 0.25 + 0.05
    }));

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.x += p.vx; p.y += p.vy;
            if (p.x < 0 || p.x > canvas.width)  p.vx *= -1;
            if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(245,197,6,${p.o})`;
            ctx.fill();
        });
        requestAnimationFrame(draw);
    }
    draw();
})();

// ---- Step navigation ----
function showStep(step) {
    [stepWelcome, stepGame, stepResults].forEach(s => {
        if (s === step) {
            s.classList.remove('exit');
            s.classList.add('active');
        } else if (s.classList.contains('active')) {
            s.classList.add('exit');
            setTimeout(() => { s.classList.remove('active', 'exit'); }, 500);
        }
    });
}

// ---- Welcome Events ----
document.getElementById('btn-start-game').addEventListener('click', async () => {
    showStep(stepGame);
    await loadMovies();
});

document.getElementById('btn-skip-onboarding').addEventListener('click', async () => {
    await skipOnboarding();
});

// ---- Load movies from API ----
async function loadMovies() {
    try {
        const res = await fetch('/api/onboarding/movies', { credentials: 'include' });
        if (!res.ok) throw new Error('Failed to load movies');
        const data = await res.json();
        movies = data.movies || [];

        if (movies.length === 0) {
            cardStack.innerHTML = '<div class="ob-empty-state"><i class="fas fa-film"></i><p>Фільми не знайдено</p></div>';
            return;
        }

        renderCards();
        setupTopCard();
        updateProgress();
    } catch (err) {
        console.error('Error loading onboarding movies:', err);
        cardStack.innerHTML = '<div class="ob-empty-state"><i class="fas fa-exclamation-circle"></i><p>Помилка завантаження</p></div>';
    }
}

// ---- Render card stack ----
function renderCards() {
    cardStack.innerHTML = '';
    cards = [];

    // Show up to 3 cards at a time (stack effect)
    const count = Math.min(3, movies.length - currentIndex);
    for (let i = count - 1; i >= 0; i--) {
        const movie = movies[currentIndex + i];
        if (!movie) continue;
        const card = createCard(movie);
        cards.push(card);
        cardStack.appendChild(card);
    }

    // The last appended card is on top
    if (cards.length > 0) {
        const top = cards[cards.length - 1];
        top.classList.add('is-top');
        topCard = top;
        attachDrag(top);
    }
}

function createCard(movie) {
    const el = document.createElement('div');
    el.className = 'ob-movie-card';
    el.dataset.movieId = movie.id;

    const year = movie.release_date ? new Date(movie.release_date).getFullYear() : '';
    const rating = movie.imdb_rating ? Number(movie.imdb_rating).toFixed(1) : '?';
    const genresHTML = (movie.genres || []).slice(0, 3)
        .map(g => `<span class="ob-genre-tag">${g}</span>`).join('');
    const poster = movie.poster_url || 'https://via.placeholder.com/360x490/12121a/f5c506?text=?';

    el.innerHTML = `
        <div class="ob-card-poster">
            <img src="${escapeHtml(poster)}" alt="${escapeHtml(movie.title)}" draggable="false"
                 onerror="this.src='https://via.placeholder.com/360x490/12121a/f5c506?text=?'">
        </div>
        <div class="ob-card-gradient"></div>
        <div class="ob-card-info">
            <div class="ob-card-title">${escapeHtml(movie.title)}</div>
            <div class="ob-card-meta">
                <div class="ob-card-rating"><i class="fas fa-star"></i> ${rating}</div>
                ${year ? `<div class="ob-card-year">${year}</div>` : ''}
            </div>
            <div class="ob-card-genres">${genresHTML}</div>
        </div>
    `;
    return el;
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ---- Update progress ----
function updateProgress() {
    const done = currentIndex;
    const total = movies.length;
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    progressBar.style.setProperty('--progress', pct + '%');
    progressText.textContent = `${done} / ${total}`;
}

// ---- Setup top card drag ----
function setupTopCard() {
    if (!cards.length) return;
    const top = cards[cards.length - 1];
    top.classList.add('is-top');
    topCard = top;
    attachDrag(top);
}

// ---- Drag / Swipe mechanics ----
function attachDrag(card) {
    // Mouse
    card.addEventListener('mousedown', onDragStart, { passive: true });
    // Touch
    card.addEventListener('touchstart', onDragStart, { passive: true });
}

function onDragStart(e) {
    if (!topCard || topCard.classList.contains('animating')) return;
    isDragging = true;
    const point = e.touches ? e.touches[0] : e;
    startX = point.clientX;
    startY = point.clientY;
    currentX = 0; currentY = 0;

    document.addEventListener('mousemove', onDragMove, { passive: true });
    document.addEventListener('touchmove', onDragMove, { passive: true });
    document.addEventListener('mouseup', onDragEnd);
    document.addEventListener('touchend', onDragEnd);
}

function onDragMove(e) {
    if (!isDragging || !topCard) return;
    const point = e.touches ? e.touches[0] : e;
    currentX = point.clientX - startX;
    currentY = point.clientY - startY;

    const rotate = currentX * 0.06;
    topCard.style.transform = `translate(${currentX}px, ${currentY}px) rotate(${rotate}deg)`;
    topCard.style.transition = 'none';

    // Show indicators
    const threshold = 60;
    if (currentX > threshold) {
        indicatorLike.classList.add('visible');
        indicatorDislike.classList.remove('visible');
        indicatorLike.style.opacity = Math.min((currentX - threshold) / 80, 1);
    } else if (currentX < -threshold) {
        indicatorDislike.classList.add('visible');
        indicatorLike.classList.remove('visible');
        indicatorDislike.style.opacity = Math.min((-currentX - threshold) / 80, 1);
    } else {
        indicatorLike.classList.remove('visible');
        indicatorDislike.classList.remove('visible');
    }
}

function onDragEnd() {
    document.removeEventListener('mousemove', onDragMove);
    document.removeEventListener('touchmove', onDragMove);
    document.removeEventListener('mouseup', onDragEnd);
    document.removeEventListener('touchend', onDragEnd);

    if (!isDragging || !topCard) { isDragging = false; return; }
    isDragging = false;

    indicatorLike.classList.remove('visible');
    indicatorDislike.classList.remove('visible');

    const SWIPE_THRESHOLD = 100;
    if (currentX > SWIPE_THRESHOLD) {
        flyOut('right');
    } else if (currentX < -SWIPE_THRESHOLD) {
        flyOut('left');
    } else {
        // Snap back
        topCard.style.transition = 'transform 0.35s cubic-bezier(0.4,0,0.2,1)';
        topCard.style.transform = '';
    }
}

// ---- Fly out animation ----
function flyOut(direction) {
    if (!topCard || topCard.classList.contains('animating')) return;
    const card = topCard;
    const movieIndex = currentIndex;

    card.classList.add('animating');

    const x = direction === 'right' ? window.innerWidth + 200 : -(window.innerWidth + 200);
    const rotate = direction === 'right' ? 30 : -30;

    card.style.transition = 'transform 0.4s cubic-bezier(0.4,0,0.2,1), opacity 0.4s ease';
    card.style.transform = `translate(${x}px, ${currentY * 0.5}px) rotate(${rotate}deg)`;
    card.style.opacity = '0';

    const liked = direction === 'right';
    const movie = movies[movieIndex];

    // Record action
    history.push({ movieIndex, liked, card });
    if (liked) likedMovies.push(movie);
    btnUndo.disabled = false;

    currentIndex++;
    updateProgress();

    // Promote next cards after animation
    setTimeout(() => {
        card.remove();
        cards = cards.filter(c => c !== card);

        // Add new card to bottom of stack if available
        if (currentIndex + 2 < movies.length) {
            const newMovie = movies[currentIndex + 2];
            const newCard = createCard(newMovie);
            cardStack.insertBefore(newCard, cardStack.firstChild);
            cards.unshift(newCard);
        }

        // Reset stack layering
        reorderStack();

        if (currentIndex >= movies.length) {
            finishGame();
        }
    }, 400);
}

function reorderStack() {
    // Re-apply visual stack order to remaining cards
    const remaining = Array.from(cardStack.querySelectorAll('.ob-movie-card:not(.animating)'));
    remaining.forEach((c, i) => {
        c.classList.remove('is-top');
    });

    topCard = remaining[remaining.length - 1] || null;
    if (topCard) {
        topCard.classList.add('is-top');
        topCard.style.transform = '';
        topCard.style.transition = '';
        topCard.style.opacity = '';
        attachDrag(topCard);
    }

    // Stack effect for cards behind
    remaining.forEach((c, i) => {
        if (i === remaining.length - 1) return; // top card, already handled
        const offset = remaining.length - 1 - i;
        c.style.transform = `scale(${1 - offset * 0.05}) translateY(${offset * 10}px)`;
        c.style.filter = `brightness(${1 - offset * 0.2})`;
        c.style.transition = 'transform 0.35s ease, filter 0.35s ease';
        c.style.zIndex = i;
    });
}

// ---- Undo last action ----
btnUndo.addEventListener('click', () => {
    if (history.length === 0) return;
    const last = history.pop();

    // Remove from liked if it was liked
    if (last.liked) {
        likedMovies = likedMovies.filter(m => m.id !== movies[last.movieIndex].id);
    }

    currentIndex = last.movieIndex;
    updateProgress();

    // Rebuild stack
    renderCards();
    setupTopCard();
    btnUndo.disabled = history.length === 0;
});

// ---- Action button handlers ----
btnLike.addEventListener('click', () => {
    if (!topCard || topCard.classList.contains('animating')) return;
    currentX = 0; currentY = 0;
    flyOut('right');
});

btnDislike.addEventListener('click', () => {
    if (!topCard || topCard.classList.contains('animating')) return;
    currentX = 0; currentY = 0;
    flyOut('left');
});

// Keyboard support
document.addEventListener('keydown', (e) => {
    if (!stepGame.classList.contains('active')) return;
    if (e.key === 'ArrowRight') btnLike.click();
    if (e.key === 'ArrowLeft')  btnDislike.click();
    if (e.key === 'z' || e.key === 'Z') btnUndo.click();
});

// ---- Finish game → Results step ----
function finishGame() {
    // Compute genre preferences
    const genreCount = {};
    let totalRating = 0;
    let ratedCount = 0;

    likedMovies.forEach(movie => {
        (movie.genres || []).forEach(genre => {
            genreCount[genre] = (genreCount[genre] || 0) + 1;
        });
        if (movie.imdb_rating) {
            totalRating += parseFloat(movie.imdb_rating);
            ratedCount++;
        }
    });

    const minRating = ratedCount > 0 ? Math.max(0, (totalRating / ratedCount) - 1.5) : 5.0;
    const preferredGenres = Object.entries(genreCount)
        .sort((a, b) => b[1] - a[1])
        .map(([genre]) => genre);

    // Update results UI
    document.getElementById('stat-liked').textContent = likedMovies.length;
    document.getElementById('stat-genres').textContent = preferredGenres.length;

    const genresPreview = document.getElementById('ob-genres-preview');
    genresPreview.innerHTML = preferredGenres.slice(0, 8)
        .map(g => `<span class="ob-genre-pill">${g}</span>`).join('');

    // Save to server
    savePreferences(preferredGenres, minRating);

    setTimeout(() => showStep(stepResults), 300);
}

// ---- Save preferences via API ----
async function savePreferences(genres, minRating) {
    try {
        await fetch('/api/onboarding/complete', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ genres, min_rating: minRating })
        });
    } catch (err) {
        console.error('Error saving preferences:', err);
    }
}

async function skipOnboarding() {
    try {
        await fetch('/api/onboarding/skip', {
            method: 'POST',
            credentials: 'include'
        });
    } catch (err) {
        console.error('Error skipping onboarding:', err);
    }
    window.location.href = '/';
}

// ---- Finish → go home ----
document.getElementById('btn-finish').addEventListener('click', () => {
    window.location.href = '/';
});
