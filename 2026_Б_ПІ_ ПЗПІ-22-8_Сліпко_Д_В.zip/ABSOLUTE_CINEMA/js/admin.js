document.addEventListener('DOMContentLoaded', () => {
    // Navigation handling
    const navItems = document.querySelectorAll('.admin-nav-item[data-target]');
    const sections = document.querySelectorAll('.admin-section');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = item.getAttribute('data-target');
            
            navItems.forEach(nav => nav.classList.remove('active'));
            sections.forEach(sec => sec.classList.remove('active'));
            
            item.classList.add('active');
            document.getElementById(targetId).classList.add('active');

            if (targetId === 'users') loadUsers();
            if (targetId === 'media') loadMedia();
        });
    });

    // Load initial data
    loadStats();
});

async function logoutAdmin() {
    await fetch('/api/auth/logout', { method: 'POST' });
    window.location.href = '/admin-login';
}

async function loadStats() {
    try {
        const res = await fetch('/api/admin/stats');
        if (!res.ok) throw new Error('Не вдалося завантажити статистику');
        const data = await res.json();
        
        document.getElementById('stat-users').innerText = data.users;
        document.getElementById('stat-media').innerText = data.movies;
        document.getElementById('stat-reviews').innerText = data.reviews;
        document.getElementById('stat-discussions').innerText = data.discussions;
    } catch (e) {
        console.error(e);
    }
}

async function loadUsers() {
    const tbody = document.getElementById('users-table-body');
    tbody.innerHTML = '<tr><td colspan="5">Завантаження...</td></tr>';
    
    try {
        const res = await fetch('/api/admin/users');
        if (!res.ok) throw new Error('Не вдалося завантажити користувачів');
        const data = await res.json();
        
        tbody.innerHTML = '';
        data.users.forEach(user => {
            const roleStr = user.is_admin ? '<span style="color:#69f0ae">Адмін</span>' : 'Користувач';
            const actionBtn = user.is_admin 
                ? `<button class="action-btn btn-toggle" onclick="toggleAdmin('${user.user_id}', false)">Забрати Адміна</button>`
                : `<button class="action-btn btn-toggle" onclick="toggleAdmin('${user.user_id}', true)">Дати Адміна</button>`;

            tbody.innerHTML += `
                <tr>
                    <td><small>${user.user_id}</small></td>
                    <td>${user.username}</td>
                    <td>${new Date(user.created_at).toLocaleDateString()}</td>
                    <td>${roleStr}</td>
                    <td>
                        ${actionBtn}
                        <button class="action-btn btn-delete" onclick="deleteUser('${user.user_id}')"><i class="fas fa-trash"></i> Видалити</button>
                    </td>
                </tr>
            `;
        });
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="5">Помилка завантаження</td></tr>';
        console.error(e);
    }
}

async function loadMedia() {
    const tbody = document.getElementById('media-table-body');
    tbody.innerHTML = '<tr><td colspan="5">Завантаження...</td></tr>';
    
    try {
        const res = await fetch('/api/latest-movies'); // Використовуємо існуючий API
        if (!res.ok) throw new Error('Не вдалося завантажити медіа');
        const data = await res.json();
        
        tbody.innerHTML = '';
        data.movies.forEach(media => {
            tbody.innerHTML += `
                <tr>
                    <td>${media.id}</td>
                    <td>${media.title}</td>
                    <td>${media.type}</td>
                    <td>${media.release_date || '-'}</td>
                    <td>
                        <button class="action-btn btn-delete" onclick="deleteMedia(${media.id})"><i class="fas fa-trash"></i> Видалити</button>
                    </td>
                </tr>
            `;
        });
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="5">Помилка завантаження</td></tr>';
        console.error(e);
    }
}

async function toggleAdmin(userId, isAdmin) {
    if (!confirm(`Ви впевнені, що хочете ${isAdmin ? 'надати' : 'забрати'} права адміністратора?`)) return;
    try {
        await fetch(`/api/admin/users/${userId}/toggle-admin`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ is_admin: isAdmin })
        });
        loadUsers();
    } catch (e) {
        console.error(e);
        alert('Помилка');
    }
}

async function deleteUser(userId) {
    if (!confirm('Ви впевнені, що хочете ВИДАЛИТИ користувача? Ця дія незворотна.')) return;
    try {
        const res = await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' });
        if (res.ok) {
            loadUsers();
            loadStats();
        } else {
            const data = await res.json();
            alert(data.error || 'Помилка видалення');
        }
    } catch (e) {
        console.error(e);
        alert('Помилка видалення');
    }
}

async function deleteMedia(id) {
    if (!confirm('Ви впевнені, що хочете видалити цей контент?')) return;
    try {
        const res = await fetch(`/api/admin/media/${id}`, { method: 'DELETE' });
        if (res.ok) {
            loadMedia();
            loadStats();
        } else {
            alert('Помилка видалення');
        }
    } catch (e) {
        console.error(e);
    }
}

// Modal handling
async function openMediaModal() {
    document.getElementById('mediaModal').classList.add('active');
    await loadGenresOptions();
}

async function loadGenresOptions() {
    const select = document.getElementById('mediaGenres');
    if (!select || select.dataset.loaded) return;
    try {
        const res = await fetch('/api/genres');
        const data = await res.json();
        select.innerHTML = (data.genres || []).map(g => `<option value="${g.id}">${g.name}</option>`).join('');
        select.dataset.loaded = '1';
    } catch (e) {
        console.error('Помилка завантаження жанрів:', e);
    }
}

function closeMediaModal() {
    document.getElementById('mediaModal').classList.remove('active');
    document.getElementById('mediaForm').reset();
}

async function submitMedia(e) {
    e.preventDefault();
    const selectedGenres = [...document.getElementById('mediaGenres').selectedOptions].map(o => parseInt(o.value));
    const payload = {
        title: document.getElementById('mediaTitle').value,
        description: document.getElementById('mediaDesc').value,
        poster_url: document.getElementById('mediaPoster').value,
        type: document.getElementById('mediaType').value,
        release_date: document.getElementById('mediaRelease').value || null,
        imdb_rating: parseFloat(document.getElementById('mediaImdb').value) || null,
        genre_ids: selectedGenres
    };

    try {
        const res = await fetch('/api/admin/media', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        if (res.ok) {
            closeMediaModal();
            loadMedia();
            loadStats();
        } else {
            alert('Помилка збереження');
        }
    } catch (error) {
        console.error(error);
        alert('Помилка з\'єднання');
    }
}
