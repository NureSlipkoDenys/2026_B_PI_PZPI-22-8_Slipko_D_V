window.initSearch = function () {
    const searchIcon = document.getElementById('search-icon');
    const searchPopup = document.getElementById('search-popup');
    if (!searchIcon || !searchPopup) return;

    const searchInput = searchPopup.querySelector('input');
    const searchResults = searchPopup.querySelector('.search-results');
    if (!searchInput || !searchResults) return;

    // Не навішуємо обробники повторно при переініціалізації хедера
    if (searchIcon.dataset.searchInit === '1') return;
    searchIcon.dataset.searchInit = '1';

    const VISIBLE_LIMIT = 3;
    let searchTimeout;

    function closePopup() {
        searchPopup.classList.remove('active');
        searchIcon.classList.remove('active');
        searchInput.value = '';
        searchResults.innerHTML = '';
    }

    searchIcon.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const willOpen = !searchPopup.classList.contains('active');
        searchPopup.classList.toggle('active', willOpen);
        searchIcon.classList.toggle('active', willOpen);
        if (willOpen) {
            setTimeout(() => searchInput.focus(), 50);
        } else {
            searchInput.value = '';
            searchResults.innerHTML = '';
        }
    });

    document.addEventListener('click', (e) => {
        if (searchPopup.classList.contains('active') &&
            !searchPopup.contains(e.target) &&
            !searchIcon.contains(e.target)) {
            closePopup();
        }
    });

    searchPopup.addEventListener('click', (e) => e.stopPropagation());

    function goToMoviesSearch(query) {
        window.location.href = `/movies.html?search=${encodeURIComponent(query)}`;
    }

    async function searchMovies(query) {
        if (!query.trim()) {
            searchResults.innerHTML = '';
            return;
        }
        try {
            const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const data = await response.json();
            const movies = (data.movies || []).sort((a, b) => (b.imdb_rating || 0) - (a.imdb_rating || 0));

            if (movies.length === 0) {
                searchResults.innerHTML = '<div class="no-results">Фільмів не знайдено</div>';
                return;
            }

            const visibleMovies = movies.slice(0, VISIBLE_LIMIT);
            const resultsHtml = visibleMovies.map(movie => `
                <div class="search-result-item" onclick="window.location='/movie/${movie.id}'">
                    <div class="search-result-poster">
                        <img src="${movie.poster_url || 'https://via.placeholder.com/40x60?text=No+Poster'}"
                             alt="${movie.title}">
                    </div>
                    <div class="search-result-info">
                        <div class="search-result-title">${movie.title}</div>
                        <div class="search-result-details">
                            <span class="search-result-rating">★ ${movie.imdb_rating || '—'}</span>
                            <span class="search-result-year">${movie.release_date ? movie.release_date.slice(0, 4) : '—'}</span>
                        </div>
                    </div>
                </div>
            `).join('');

            const showMoreHtml = movies.length > VISIBLE_LIMIT
                ? `<button class="search-show-more-btn" type="button">ПОКАЗАТИ БІЛЬШЕ</button>`
                : '';

            searchResults.innerHTML = resultsHtml + showMoreHtml;

            const showMoreBtn = searchResults.querySelector('.search-show-more-btn');
            if (showMoreBtn) {
                showMoreBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    goToMoviesSearch(query);
                });
            }
        } catch (error) {
            console.error('Search error:', error);
            searchResults.innerHTML = '<div class="no-results">Помилка пошуку</div>';
        }
    }

    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => searchMovies(e.target.value), 300);
    });

    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const query = e.target.value.trim();
            if (query) goToMoviesSearch(query);
        }
    });
};
