// movie-detail.js - скрипт для сторінки з детальною інформацією про фільм

function getMovieIdFromUrl() {
    const pathParts = window.location.pathname.split('/');
    return pathParts[pathParts.length - 1];
}

function formatDate(dateString) {
    if (!dateString) return 'Дата невідома';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Дата невідома';
    return date.toLocaleDateString('uk-UA');
}

// Визначає середню яскравість зображення (0 — чорне, 1 — біле) через canvas
function getImageBrightness(imgUrl) {
    return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
            try {
                const size = 16;
                const canvas = document.createElement('canvas');
                canvas.width = size;
                canvas.height = size;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, size, size);
                const { data } = ctx.getImageData(0, 0, size, size);
                let total = 0;
                for (let i = 0; i < data.length; i += 4) {
                    total += data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
                }
                resolve(total / (data.length / 4) / 255);
            } catch (e) {
                resolve(null);
            }
        };
        img.onerror = () => resolve(null);
        img.src = imgUrl;
    });
}

// Підбирає рівень підсвітки бекдропу залежно від яскравості постера,
// щоб темні обкладинки не зливались у суцільну чорну плашку
function applyBackdropBrightness(backdropImg, posterUrl) {
    getImageBrightness(posterUrl).then(brightness => {
        if (brightness === null) return;
        const lifted = Math.min(1.1, Math.max(0.65, 1.0 - brightness * 0.5));
        backdropImg.style.filter = `blur(28px) brightness(${lifted.toFixed(2)}) saturate(0.85)`;
    });
}

// Підганяє висоту постера під реальну висоту блока з інформацією про фільм,
// щоб праворуч/під кнопками не лишалось порожнього місця при короткому описі
const POSTER_MIN_HEIGHT = 320;
const POSTER_MAX_HEIGHT = 560;
function syncPosterHeight() {
    const poster = document.querySelector('.movie-poster:not(.no-poster)');
    const info = document.querySelector('.movie-info');
    if (!poster || !info) return;
    if (window.innerWidth <= 860) {
        poster.style.height = '';
        return;
    }
    const targetHeight = Math.min(POSTER_MAX_HEIGHT, Math.max(POSTER_MIN_HEIGHT, info.offsetHeight));
    poster.style.height = `${targetHeight}px`;
}

async function loadMovieDetails() {
    const movieContent = document.getElementById('movieContent');
    if (!movieContent) return;
    try {
        const movieId = getMovieIdFromUrl();
        if (!movieId) throw new Error('ID фільму не знайдено');

        const res = await fetch(`/api/movie/${movieId}`);
        if (!res.ok) throw new Error('Фільм не знайдено');
        const movie = await res.json();

        let genres = [];
        try {
            const genresRes = await fetch(`/api/movie/${movieId}/genres`);
            if (genresRes.ok) {
                const genresData = await genresRes.json();
                genres = genresData.genres || [];
            }
        } catch {}

        let cast = [];
        try {
            const castRes = await fetch(`/api/movie/${movieId}/cast`);
            if (castRes.ok) {
                const castData = await castRes.json();
                cast = castData.cast || [];
            }
        } catch {}

        // Отримуємо середню оцінку глядачів
        let averageRating = null;
        try {
            const reviewsRes = await fetch(`/api/movie/${movieId}/reviews`, { credentials: 'include' });
            if (reviewsRes.ok) {
                const reviewsData = await reviewsRes.json();
                averageRating = reviewsData.average_rating;
            }
        } catch {}

        movieContent.className = 'movie-detail-card';
        movieContent.style.animation = 'none';
        requestAnimationFrame(() => { movieContent.style.animation = ''; });

        // Встановлюємо блюр-фон з постера фільму
        const backdropImg = document.getElementById('movieBackdropImg');
        if (backdropImg && movie.poster_url) {
            backdropImg.style.backgroundImage = `url('${movie.poster_url}')`;
            applyBackdropBrightness(backdropImg, movie.poster_url);
        }
        const posterHtml = movie.poster_url
            ? `<div class="movie-poster"><img src="${movie.poster_url}" alt="${movie.title}"></div>`
            : `<div class="movie-poster no-poster"><i class="fas fa-film fa-5x"></i><span>Немає постера</span></div>`;
        // Отримуємо кількість репостів
        let repostCount = 0;
        try {
            const repostRes = await fetch(`/api/movie/${movieId}/reposts/count`);
            if (repostRes.ok) {
                const repostData = await repostRes.json();
                repostCount = repostData.count || 0;
            }
        } catch {}

        movieContent.innerHTML = `
            ${posterHtml}
            <div class="movie-info">
                <h1 class="movie-title">${movie.title}</h1>
                <div class="movie-meta">
                    <div class="movie-meta-item"><i class="fas fa-calendar"></i> <span>Дата виходу: <b>${formatDate(movie.release_date)}</b></span></div>
                    <div class="movie-meta-item"><i class="fas fa-clock"></i> <span>Тривалість: <b>${movie.duration_min ? movie.duration_min + ' хв' : '—'}</b></span></div>
                    <div class="movie-meta-item"><i class="fas fa-star"></i> <span>Рейтинг: <b>${movie.imdb_rating != null ? movie.imdb_rating + ' / 10' : '—'}</b></span></div>
                    <div class="movie-meta-item"><i class="fas fa-users"></i> <span>Оцінка глядачів: <b>${averageRating !== null && averageRating !== undefined ? averageRating : '—'}</b></span></div>
                </div>
                <div class="movie-meta">
                    <div class="movie-meta-item"><i class="fas fa-film"></i> <span>Жанри: <b>${genres.length ? genres.join(', ') : '—'}</b></span></div>
                    <div class="movie-meta-item"><i class="fas fa-user"></i> <span>Режисер: <b>${movie.director || '—'}</b></span></div>
                </div>
                <p class="movie-description">${movie.description || 'Опис відсутній'}</p>
                <div class="movie-actions">
                    <button class="action-button favorite-button"><i class="fas fa-heart"></i> Додати в обране</button>
                    <button class="action-button review-button"><i class="fas fa-comment"></i> Написати рецензію</button>
                    <button class="action-button share-button" id="shareMovieBtn"><i class="fas fa-share-alt"></i> Репост (<span id="repostCountBadge">${repostCount}</span>)</button>
                </div>
                ${cast.length > 0 ? `
                <div class="movie-cast">
                    <h2 class="cast-title">Акторський склад</h2>
                    <p class="movie-cast-text">${cast.map(actor => actor.full_name).join(', ')}</p>
                </div>` : ''}
            </div>
            <div class="movie-reviews">
                <h2 class="reviews-title">Рецензії</h2>
                <div id="reviewsContainer" class="reviews-container"></div>
            </div>
        `;
        syncPosterHeight();
        await updateFavoriteButtonState(movieId);
        setupButtonHandlers(movieId);
        loadReviews(movieId);
        setupShareModal(movieId);
    } catch (e) {
        showError(e.message);
    }
}

function showError(message) {
    const movieContent = document.getElementById('movieContent');
    if (movieContent) {
        movieContent.className = 'movie-detail-card error-container';
        movieContent.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <p>Помилка: ${message}</p>
            <a href="/" style="color: #e50914; margin-top: 15px; display: inline-block;">Повернутися на головну</a>
        `;
    }
}

async function checkAuth() {
    try {
        const res = await fetch('/api/auth/status', { credentials: 'include' });
        const data = await res.json();
        return data.authenticated;
    } catch {
        return false;
    }
}

function setupButtonHandlers(movieId) {
    const favoriteButton = document.querySelector('.favorite-button');
    if (favoriteButton) {
        favoriteButton.addEventListener('click', async () => {
            try {
                const isAuthenticated = await checkAuth();
                if (!isAuthenticated) {
                    const confirmLogin = confirm('Для додавання фільму в обране необхідно авторизуватися. Перейти на сторінку входу?');
                    if (confirmLogin) {
                        localStorage.setItem('returnUrl', window.location.href);
                        window.location.href = '/login';
                    }
                    return;
                }

                const isFavorite = favoriteButton.classList.contains('active');
                if (isFavorite) {
                    const favoriteId = favoriteButton.dataset.favoriteId;
                    if (favoriteId) {
                        await removeFromFavorites(favoriteId, movieId);
                    } else {
                        await updateFavoriteButtonState(movieId);
                    }
                } else {
                    const response = await fetch(`/api/favorites`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ movieId }),
                        credentials: 'include'
                    });

                    // У будь-якому разі після спроби додати — оновлюємо стан кнопки
                    await updateFavoriteButtonState(movieId);

                    if (!response.ok) {
                        if (response.status === 401) {
                            const confirmLogin = confirm('Ваша сесія закінчилася. Перейти на сторінку входу?');
                            if (confirmLogin) {
                                localStorage.setItem('returnUrl', window.location.href);
                                window.location.href = '/login';
                            }
                            return;
                        }
                        // Якщо 409 — просто оновлюємо стан кнопки, не показуємо помилку
                        if (response.status === 409) {
                            return;
                        }
                        throw new Error('Не вдалося додати фільм в обране');
                    }
                }
            } catch (error) {
                console.error('Помилка при роботі з обраним:', error);
                alert('Помилка: ' + error.message);
            }
        });
    }

    const reviewButton = document.querySelector('.review-button');
    if (reviewButton) {
        reviewButton.addEventListener('click', () => {
            const reviewsContainer = document.getElementById('reviewsContainer');
            if (!reviewsContainer) return;
            // Якщо форма вже є — не додавати ще раз
            if (document.querySelector('.review-form')) return;

            // Перевірка авторизації
            fetch('/api/auth/status')
                .then(response => response.json())
                .then(data => {
                    if (!data.authenticated) {
                        alert('Для написання рецензії потрібно авторизуватись');
                        return;
                    }
                    const reviewForm = document.createElement('div');
                    reviewForm.className = 'review-form';
                    reviewForm.innerHTML = `
                        <h3>Написати рецензію</h3>
                        <div class="rating-container">
                            <label>Оцінка:</label>
                            <div class="star-rating">
                                ${Array(10).fill().map((_, i) => `
                                    <span class="star" data-rating="${i + 1}">★</span>
                                `).join('')}
                            </div>
                        </div>
                        <textarea id="reviewContent" placeholder="Напишіть вашу рецензію..." rows="4"></textarea>
                        <button type="button" id="submitReviewBtn">Опублікувати рецензію</button>
                        <button type="button" id="cancelReviewBtn" style="margin-left:10px; background:#888;">Скасувати</button>
                    `;
                    // Вставляємо форму перед списком рецензій
                    reviewsContainer.prepend(reviewForm);
                    // Зірки рейтингу
                    const stars = reviewForm.querySelectorAll('.star');
                    stars.forEach(star => {
                        star.addEventListener('click', function() {
                            const rating = this.dataset.rating;
                            stars.forEach(s => s.classList.remove('active'));
                            for (let i = 0; i < rating; i++) {
                                stars[i].classList.add('active');
                            }
                        });
                    });
                    // Кнопка відправки
                    reviewForm.querySelector('#submitReviewBtn').addEventListener('click', async () => {
                        const content = document.getElementById('reviewContent').value;
                        const rating = reviewForm.querySelectorAll('.star.active').length;
                        if (!content || !rating) {
                            alert('Будь ласка, заповніть всі обовʼязкові поля');
                            return;
                        }
                        try {
                            const mediaId = getMovieIdFromUrl();
                            const response = await fetch('/api/reviews', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ mediaId, content, rating })
                            });
                            if (!response.ok) {
                                const error = await response.json();
                                throw new Error(error.error || 'Помилка при відправці рецензії');
                            }
                            reviewForm.remove();
                            loadReviews(mediaId);
                        } catch (error) {
                            alert(error.message || 'Сталася помилка при відправці рецензії');
                        }
                    });
                    // Кнопка скасування
                    reviewForm.querySelector('#cancelReviewBtn').addEventListener('click', () => {
                        reviewForm.remove();
                    });
                });
        });
    }
}

async function loadReviews(movieId) {
    const container = document.getElementById('reviewsContainer');
    if (!container) return;
    container.innerHTML = Array(3).fill().map(() => '<div class="skeleton"></div>').join('');
    try {
        // Отримуємо поточного користувача
        const authRes = await fetch('/api/auth/status', { credentials: 'include' });
        const authData = await authRes.json();
        const currentUserId = authData?.user?.id;

        const res = await fetch(`/api/movie/${movieId}/reviews`, { credentials: 'include' });
        const data = await res.json();
        const reviews = Array.isArray(data) ? data : (data.reviews || []);
        if (!res.ok) {
            if (res.status === 404) throw { code: 404 };
            throw new Error(data.error || 'Не вдалося завантажити рецензії');
        }
        if (reviews.length === 0) {
            container.innerHTML = '<div class="reviews-empty"><i class="far fa-comment-dots" style="font-size:2em;color:rgba(245,197,6,0.4);display:block;margin-bottom:10px;"></i>Поки немає рецензій.<br><button class="action-button write-first-button" style="margin-top:14px;"><i class="fas fa-comment"></i> Написати першу рецензію</button></div>';
            container.querySelector('.write-first-button')?.addEventListener('click', () => document.querySelector('.review-button')?.click());
            return;
        }
        container.innerHTML = reviews.map(r => {
            const isOwn = currentUserId && r.user_id === currentUserId;
            const likeBtnClass = r.is_liked ? 'like-review-btn liked' : 'like-review-btn';
            const maxLength = 350;
            const isLong = r.content.length > maxLength;
            const shortText = isLong ? r.content.slice(0, maxLength) + '…' : r.content;
            let reviewTextHtml = `<p class="review-content review-text" data-full-text="${encodeURIComponent(r.content)}" data-short-text="${encodeURIComponent(shortText)}">${shortText}</p>`;
            if (isLong) {
                reviewTextHtml += `<button class="show-full-review-btn toggle-review-btn">Дивитись повністю...</button>`;
            }
            return `
            <div class="review" style="position:relative;">
                <div class="review-header">
                    <span class="review-rating">${'★'.repeat(r.rating) + '☆'.repeat(10 - r.rating)}</span>
                    <span class="review-author">
                      ${isOwn
                        ? (r.username || 'Анонім')
                        : `<a href="/profile.html?id=${r.user_id}">${r.username || 'Анонім'}</a>`}
                    </span>
                    <span class="review-date">${formatDate(r.created_at)}</span>
                </div>
                ${reviewTextHtml}
                ${!isOwn ? `<button class="${likeBtnClass}" data-id="${r.id}"><i class="fas fa-thumbs-up"></i> <span class="like-count">${r.likes_count || 0}</span></button>` : ''}
                ${isOwn ? `<button class="delete-review-btn" data-id="${r.id}"><i class="fas fa-trash"></i></button>` : ''}
            </div>
        `;
        }).join('');
        // Додаю обробник для видалення рецензії
        const deleteButtons = container.querySelectorAll('.delete-review-btn');
        deleteButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const reviewId = button.getAttribute('data-id');
                if (confirm('Ви дійсно хочете видалити цю рецензію?')) {
                    button.disabled = true;
                    button.innerHTML = "<i class='fas fa-spinner fa-spin'></i>";
                    const response = await fetch(`/api/reviews/${reviewId}`, {
                        method: 'DELETE',
                        credentials: 'include'
                    });
                    if (response.ok) {
                        button.closest('.review').remove();
                    } else {
                        button.disabled = false;
                        button.innerHTML = "<i class='fas fa-trash'></i>";
                        alert('Помилка при видаленні рецензії');
                    }
                }
            });
        });
        // Додаю обробник для лайків
        const likeButtons = container.querySelectorAll('.like-review-btn');
        likeButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const reviewId = button.getAttribute('data-id');
                const isLiked = button.classList.contains('liked');
                try {
                    button.disabled = true;
                    let res;
                    if (!isLiked) {
                        // Ставимо лайк
                        res = await fetch('/api/review-likes', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({ review_id: reviewId })
                        });
                    } else {
                        // Знімаємо лайк
                        res = await fetch('/api/review-likes', {
                            method: 'DELETE',
                            headers: { 'Content-Type': 'application/json' },
                            credentials: 'include',
                            body: JSON.stringify({ review_id: reviewId })
                        });
                    }
                    if (!res.ok) throw new Error('Не вдалося оновити лайк');
                    // Оновлюємо UI: перераховуємо лайки та змінюємо клас
                    const countSpan = button.querySelector('.like-count');
                    let count = parseInt(countSpan.textContent);
                    if (!isLiked) {
                        countSpan.textContent = count + 1;
                        button.classList.add('liked');
                    } else {
                        countSpan.textContent = Math.max(0, count - 1);
                        button.classList.remove('liked');
                    }
                    button.disabled = false;
                } catch (e) {
                    button.disabled = false;
                    alert(e.message || 'Помилка при лайку');
                }
            });
        });
        // Додаю обробник для згортання/розгортання рецензій
        const showFullBtns = container.querySelectorAll('.show-full-review-btn');
        showFullBtns.forEach((btn) => {
            btn.addEventListener('click', function() {
                const reviewText = btn.closest('.review').querySelector('.review-text');
                const isExpanded = reviewText.classList.contains('expanded-review');
                if (!isExpanded) {
                    // Розгортаємо
                    const fullText = decodeURIComponent(reviewText.getAttribute('data-full-text'));
                    reviewText.textContent = fullText;
                    reviewText.classList.add('expanded-review');
                    btn.textContent = 'Приховати...';
                } else {
                    // Згортаємо
                    const shortText = decodeURIComponent(reviewText.getAttribute('data-short-text'));
                    reviewText.textContent = shortText;
                    reviewText.classList.remove('expanded-review');
                    btn.textContent = 'Дивитись повністю...';
                }
                // Переміщуємо кнопку після тексту
                reviewText.after(btn);
            });
        });
    } catch (err) {
        if (err.code === 404) {
            container.innerHTML = `
                <p>Поки немає рецензій.</p>
                <button class="action-button write-first-button"><i class="fas fa-comment"></i> Написати першу рецензію</button>
            `;
            const writeBtn = container.querySelector('.write-first-button');
            if (writeBtn) writeBtn.addEventListener('click', () => {
                document.querySelector('.review-button')?.click();
            });
        } else {
            container.innerHTML = `<p>Помилка: ${err.message || err}</p>`;
        }
    }
}

async function updateFavoriteButtonState(movieId) {
    try {
        const profileRes = await fetch('/api/profile', { credentials: 'include' });
        if (!profileRes.ok) return;
        const profileData = await profileRes.json();
        const userId = profileData?.profile?.user_id;
        if (!userId) return;

        const favRes = await fetch(`/api/favorites/user/${userId}`, { credentials: 'include' });
        if (!favRes.ok) return;
        const favData = await favRes.json();
        const favorites = favData.favorites || [];

        const favoriteRecord = favorites.find(fav =>
            String(fav.media_id) === String(movieId) ||
            (fav.media && String(fav.media.id) === String(movieId))
        );

        const favoriteButton = document.querySelector('.favorite-button');
        if (favoriteButton) {
            if (favoriteRecord) {
                favoriteButton.innerHTML = '<i class="fas fa-heart-broken"></i> Видалити з обраного';
                favoriteButton.classList.add('active', 'remove-favorite-btn');
                favoriteButton.dataset.favoriteId = favoriteRecord.media_id;
            } else {
                favoriteButton.innerHTML = '<i class="fas fa-heart"></i> Додати в обране';
                favoriteButton.classList.remove('active', 'remove-favorite-btn');
                delete favoriteButton.dataset.favoriteId;
            }
        }
    } catch (e) {
        console.warn('Не вдалося перевірити обране:', e);
    }
}

async function removeFromFavorites(favoriteId, movieId) {
    try {
        const response = await fetch(`/api/favorites/${favoriteId}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Помилка при видаленні з обраного');
        }

        // Оновлюємо стан кнопки
        await updateFavoriteButtonState(movieId);
    } catch (error) {
        console.error('Помилка:', error);
        alert('Не вдалося видалити з обраного');
    }
}

// ============================================================
// SHARE MODAL — «Скинути другу» (мультивибір + повідомлення)
// ============================================================
function setupShareModal(movieId) {
    const shareBtn = document.getElementById('shareMovieBtn');
    if (!shareBtn) return;

    // Вставляємо модальне вікно в DOM (якщо ще немає)
    if (!document.getElementById('shareMovieModal')) {
        const modal = document.createElement('div');
        modal.id = 'shareMovieModal';
        modal.className = 'share-modal-overlay';
        modal.innerHTML = `
            <div class="share-modal">
                <div class="share-modal-header">
                    <h3><i class="fas fa-share-alt"></i> Репост</h3>
                    <button class="share-modal-close" id="shareModalClose"><i class="fas fa-times"></i></button>
                </div>

                <div class="share-modal-body">
                    <!-- Поле для повідомлення -->
                    <div class="share-message-wrap">
                        <label class="share-message-label"><i class="fas fa-comment-alt"></i> Додати повідомлення (необов'язково)</label>
                        <textarea
                            id="shareMessageText"
                            class="share-message-input"
                            placeholder="Напиши щось до фільму..."
                            rows="2"
                            maxlength="500"
                        ></textarea>
                    </div>

                    <!-- Хедер списку чатів -->
                    <div class="share-chats-header">
                        <p class="share-modal-hint"><i class="fas fa-users"></i> Оберіть кому надіслати:</p>
                        <label class="share-select-all-label" id="shareSelectAllWrap" style="display:none">
                            <input type="checkbox" id="shareSelectAll"> Вибрати всіх
                        </label>
                    </div>

                    <!-- Список чатів з чекбоксами -->
                    <div class="share-chats-list" id="shareModalChatsList">
                        <div class="share-modal-loading"><i class="fas fa-spinner fa-spin"></i> Завантаження чатів...</div>
                    </div>
                </div>

                <!-- Футер з кнопкою -->
                <div class="share-modal-footer" id="shareModalFooter" style="display:none">
                    <span class="share-selected-count" id="shareSelectedCount">0 вибрано</span>
                    <button class="share-send-all-btn" id="shareSendAllBtn" disabled>
                        <i class="fas fa-paper-plane"></i> Відправити
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        document.getElementById('shareModalClose').addEventListener('click', closeShareModal);
        modal.addEventListener('click', (e) => { if (e.target === modal) closeShareModal(); });
    }

    shareBtn.addEventListener('click', async () => {
        const isAuthenticated = await checkAuth();
        if (!isAuthenticated) {
            const confirmLogin = confirm('Для репосту фільму необхідно авторизуватися. Перейти на сторінку входу?');
            if (confirmLogin) {
                localStorage.setItem('returnUrl', window.location.href);
                window.location.href = '/login';
            }
            return;
        }
        openShareModal(movieId);
    });
}

async function openShareModal(movieId) {
    const modal = document.getElementById('shareMovieModal');
    const chatsList = document.getElementById('shareModalChatsList');
    const footer = document.getElementById('shareModalFooter');
    const selectAllWrap = document.getElementById('shareSelectAllWrap');
    if (!modal) return;

    // Скидаємо стан
    const msgInput = document.getElementById('shareMessageText');
    if (msgInput) msgInput.value = '';

    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    chatsList.innerHTML = '<div class="share-modal-loading"><i class="fas fa-spinner fa-spin"></i> Завантаження чатів...</div>';
    if (footer) footer.style.display = 'none';
    if (selectAllWrap) selectAllWrap.style.display = 'none';

    try {
        const [chatsRes, authRes] = await Promise.all([
            fetch(`/api/chats?t=${Date.now()}`, { credentials: 'include' }),
            fetch('/api/auth/status', { credentials: 'include' })
        ]);
        const chatsData = await chatsRes.json();
        const authData = await authRes.json();
        const chats = chatsData.chats || [];
        const currentUserId = authData?.user?.id;

        if (chats.length === 0) {
            chatsList.innerHTML = '<div class="share-no-chats"><i class="fas fa-comment-slash"></i><p>У вас поки немає чатів.<br>Почніть спілкування на сторінці <a href="/chats.html">Чатів</a>.</p></div>';
            return;
        }

        // Рендеримо список з чекбоксами
        chatsList.innerHTML = chats.map(chat => {
            const otherUser = chat.user1_id === currentUserId ? chat.user2 : chat.user1;
            const profile = otherUser?.profile || otherUser;
            const avatar = profile?.avatar_url || 'https://via.placeholder.com/44';
            const name = profile?.username || 'Користувач';
            return `
                <label class="share-chat-item share-chat-selectable" data-chat-id="${chat.id}">
                    <input type="checkbox" class="share-chat-checkbox" value="${chat.id}" data-movie-id="${movieId}">
                    <img src="${avatar}" alt="${name}" class="share-chat-avatar">
                    <span class="share-chat-name">${name}</span>
                    <span class="share-chat-check-icon"><i class="fas fa-check"></i></span>
                </label>
            `;
        }).join('');

        // Показуємо footer та "вибрати всіх"
        if (footer) footer.style.display = 'flex';
        if (selectAllWrap) selectAllWrap.style.display = 'flex';

        // Логіка "вибрати всіх"
        const selectAll = document.getElementById('shareSelectAll');
        if (selectAll) {
            selectAll.checked = false;
            selectAll.addEventListener('change', () => {
                chatsList.querySelectorAll('.share-chat-checkbox').forEach(cb => {
                    cb.checked = selectAll.checked;
                    cb.closest('label').classList.toggle('selected', selectAll.checked);
                });
                updateSendButton();
            });
        }

        // Логіка чекбоксів у рядках
        chatsList.querySelectorAll('.share-chat-checkbox').forEach(cb => {
            cb.addEventListener('change', () => {
                cb.closest('label').classList.toggle('selected', cb.checked);
                updateSendButton();
                // Синхронізуємо "вибрати всіх"
                const all = chatsList.querySelectorAll('.share-chat-checkbox');
                const checked = chatsList.querySelectorAll('.share-chat-checkbox:checked');
                if (selectAll) selectAll.checked = all.length === checked.length && checked.length > 0;
            });
        });

        // Кнопка "Відправити"
        const sendBtn = document.getElementById('shareSendAllBtn');
        if (sendBtn) {
            sendBtn.onclick = () => sendRepostToSelected(movieId);
        }

        updateSendButton();

    } catch (e) {
        chatsList.innerHTML = '<div class="share-modal-loading">Помилка завантаження чатів</div>';
    }
}

// Оновлення стану кнопки "Відправити"
function updateSendButton() {
    const chatsList = document.getElementById('shareModalChatsList');
    const sendBtn = document.getElementById('shareSendAllBtn');
    const countEl = document.getElementById('shareSelectedCount');
    if (!chatsList || !sendBtn) return;

    const checked = chatsList.querySelectorAll('.share-chat-checkbox:checked');
    const n = checked.length;
    sendBtn.disabled = n === 0;
    if (countEl) countEl.textContent = n === 0 ? 'Нікого не вибрано' : `${n} вибрано`;
}

// Відправка репосту у всі вибрані чати
async function sendRepostToSelected(movieId) {
    const chatsList = document.getElementById('shareModalChatsList');
    const sendBtn = document.getElementById('shareSendAllBtn');
    const msgInput = document.getElementById('shareMessageText');
    if (!chatsList || !sendBtn) return;

    const checked = [...chatsList.querySelectorAll('.share-chat-checkbox:checked')];
    if (checked.length === 0) return;

    const message = msgInput ? msgInput.value.trim() : '';

    // Блокуємо інтерфейс
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Надсилання...';
    chatsList.querySelectorAll('.share-chat-checkbox').forEach(cb => cb.disabled = true);
    document.getElementById('shareSelectAll') && (document.getElementById('shareSelectAll').disabled = true);

    let successCount = 0;
    let failCount = 0;

    await Promise.all(checked.map(async cb => {
        const chatId = parseInt(cb.value);
        const row = cb.closest('label');
        try {
            const res = await fetch(`/api/movie/${movieId}/repost`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ chat_id: chatId, message })
            });
            if (res.ok) {
                successCount++;
                if (row) row.classList.add('share-sent');
            } else {
                failCount++;
                if (row) row.classList.add('share-fail');
            }
        } catch {
            failCount++;
            if (row) row.classList.add('share-fail');
        }
    }));

    // Оновлюємо лічильник репостів на сторінці
    const badge = document.getElementById('repostCountBadge');
    if (badge && successCount > 0) {
        badge.textContent = parseInt(badge.textContent || '0') + successCount;
    }

    sendBtn.innerHTML = `<i class="fas fa-check"></i> Надіслано ${successCount}/${checked.length}`;

    if (failCount === 0) {
        setTimeout(() => closeShareModal(), 1200);
    } else {
        // Якщо були помилки — показуємо помилку і розблоковуємо
        sendBtn.disabled = false;
        sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Спробувати знову';
        chatsList.querySelectorAll('.share-chat-checkbox').forEach(cb => cb.disabled = false);
    }
}

function closeShareModal() {
    const modal = document.getElementById('shareMovieModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

document.addEventListener('DOMContentLoaded', loadMovieDetails);
window.addEventListener('resize', syncPosterHeight);