// Функція для завантаження популярних фільмів
async function loadPopularMovies() {
    try {
        const response = await fetch('/api/popular-movies');
        if (!response.ok) {
            throw new Error('Не вдалося завантажити популярні фільми');
        }

        const data = await response.json();
        const movies = data.movies || [];

        // Отримуємо контейнер для популярних фільмів
        const popularMoviesTrack = document.getElementById('popularMoviesTrack');
        if (!popularMoviesTrack) return;

        // Очищаємо контейнер
        popularMoviesTrack.innerHTML = '';

        // Додаємо фільми в контейнер
        movies
            .filter(movie => Number(movie.imdb_rating) >= 8)
            .forEach((movie, index) => {
                const movieCard = document.createElement('div');
                movieCard.className = 'popular-movie-card';
                movieCard.setAttribute('data-index', index);

                // Форматуємо дату релізу
                const releaseDate = movie.release_date ? new Date(movie.release_date) : null;
                const releaseYear = releaseDate ? releaseDate.getFullYear() : '';

                // Скорочуємо опис, якщо він занадто довгий
                const shortDescription = movie.description && movie.description.length > 110
                    ? movie.description.substring(0, 110) + '...'
                    : (movie.description || 'Опис відсутній');

                // Формуємо блок з рейтингами
                const imdbRating = movie.imdb_rating
                    ? `<span class="star">★</span> ${movie.imdb_rating}/10`
                    : `<span class="star">★</span> ?/10`;

                movieCard.innerHTML = `
                    <div class="popular-movie-poster">
                        <img src="${movie.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${movie.title}" loading="lazy">
                        <div class="popular-movie-overlay">
                            <button class="popular-movie-btn">Детальніше</button>
                            <div class="popular-movie-meta">
                                <div class="popular-movie-meta-line">${imdbRating}${releaseYear ? `<span class="popular-movie-dot">·</span>${releaseYear}` : ''}</div>
                                ${movie.genres ? `<div class="popular-movie-meta-line">${movie.genres}</div>` : ''}
                                <div class="popular-movie-desc">${shortDescription}</div>
                            </div>
                        </div>
                    </div>
                    <div class="popular-movie-body">
                        <h3 class="popular-movie-title" title="${movie.title}">${movie.title}</h3>
                    </div>
                `;

                // Додаємо обробник кліку для перегляду фільму
                const watchButton = movieCard.querySelector('.popular-movie-btn');
                watchButton.addEventListener('click', (event) => {
                    event.stopPropagation();
                    window.location.href = `/movie/${movie.id}`;
                });
                movieCard.addEventListener('click', () => {
                    window.location.href = `/movie/${movie.id}`;
                });

                popularMoviesTrack.appendChild(movieCard);
            });

        // Ініціалізація каруселі для популярних фільмів
        try {
            if (typeof window.initPopularMoviesCarousel === 'function' && movies.length > 0) {
                window.initPopularMoviesCarousel();
            }
        } catch (carouselError) {
            console.error('Помилка ініціалізації каруселі популярних фільмів:', carouselError);
        }
    } catch (error) {
        console.error('Помилка при завантаженні популярних фільмів:', error);
        const popularMoviesTrack = document.getElementById('popularMoviesTrack');
        if (popularMoviesTrack) {
            popularMoviesTrack.innerHTML = `
                <div class="error-container">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>Помилка при завантаженні популярних фільмів: ${error.message}</p>
                </div>
            `;
        }
    }
}

// Завантажуємо популярні фільми при завантаженні сторінки
document.addEventListener('DOMContentLoaded', loadPopularMovies);

// Видаляємо цю заглушку, щоб не конфліктувала з основною функцією в script.js
// function initPopularMoviesCarousel() {} 