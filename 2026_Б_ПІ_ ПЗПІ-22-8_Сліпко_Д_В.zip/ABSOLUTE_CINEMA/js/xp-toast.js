/* xp-toast.js — Глобальні XP-сповіщення для ABSOLUTE CINEMA
 * Підключається на кожній сторінці. Показує тост при отриманні досягнення або нового рангу.
 * Версія 2.0: Сповіщення лише за майлстоуни (досягнення), без спаму за кожну дію.
 */

(function () {
  'use strict';

  // ── Стилі тоста (вставляються один раз) ──────────────────────────
  const STYLE = `
    #xp-toast-container {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 10px;
      pointer-events: none;
    }
    .xp-toast {
      display: flex;
      align-items: center;
      gap: 12px;
      background: linear-gradient(135deg, rgba(15,15,20,0.97) 0%, rgba(25,22,10,0.97) 100%);
      border: 1px solid rgba(189,183,107,0.45);
      border-left: 4px solid #BDB76B;
      border-radius: 10px;
      padding: 12px 18px;
      min-width: 250px;
      max-width: 350px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.55), 0 0 16px rgba(189,183,107,0.12);
      pointer-events: auto;
      animation: xpToastIn 0.4s cubic-bezier(0.22,1,0.36,1) both;
      will-change: transform, opacity;
    }
    .xp-toast.hiding {
      animation: xpToastOut 0.35s ease-in forwards;
    }
    .xp-toast-icon {
      font-size: 28px;
      line-height: 1;
      flex-shrink: 0;
      filter: drop-shadow(0 0 6px rgba(189,183,107,0.6));
    }
    .xp-toast-body {
      display: flex;
      flex-direction: column;
      gap: 2px;
      flex: 1;
    }
    .xp-toast-label {
      font-size: 11px;
      color: #888;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      font-family: 'Oswald', sans-serif;
    }
    .xp-toast-amount {
      font-size: 16px;
      font-weight: 700;
      color: #f5de50;
      font-family: 'Oswald', sans-serif;
      letter-spacing: 0.5px;
      text-shadow: 0 0 10px rgba(245,222,80,0.4);
    }
    .xp-toast-reason {
      font-size: 12px;
      color: #ccc;
    }
    .xp-toast-xp-value {
      font-size: 14px;
      font-weight: 700;
      color: #BDB76B;
      margin-left: auto;
    }
    @keyframes xpToastIn {
      from { transform: translateX(110%) scale(0.92); opacity: 0; }
      to   { transform: translateX(0)   scale(1);    opacity: 1; }
    }
    @keyframes xpToastOut {
      from { transform: translateX(0)   scale(1);    opacity: 1; }
      to   { transform: translateX(110%) scale(0.92); opacity: 0; }
    }
  `;

  function injectStyles() {
    if (document.getElementById('xp-toast-styles')) return;
    const style = document.createElement('style');
    style.id = 'xp-toast-styles';
    style.textContent = STYLE;
    document.head.appendChild(style);
  }

  function getContainer() {
    let c = document.getElementById('xp-toast-container');
    if (!c) {
      c = document.createElement('div');
      c.id = 'xp-toast-container';
      document.body.appendChild(c);
    }
    return c;
  }

  // ── Тост для нового досягнення ────────────────────────────────
  function showAchievementToast(ach) {
    injectStyles();
    const container = getContainer();

    const toast = document.createElement('div');
    toast.className = 'xp-toast';
    toast.innerHTML = `
      <span class="xp-toast-icon">${ach.icon || '🏆'}</span>
      <div class="xp-toast-body">
        <span class="xp-toast-label">Нове досягнення!</span>
        <span class="xp-toast-amount">${ach.title}</span>
        <span class="xp-toast-reason">${ach.description}</span>
      </div>
      ${ach.xp_reward > 0 ? \`<span class="xp-toast-xp-value">+\${ach.xp_reward} XP</span>\` : ''}
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('hiding');
      setTimeout(() => toast.remove(), 380);
    }, 4500);
  }

  // ── Тост для підвищення рангу ────────────────────────────────
  function showRankUpToast(icon, title) {
    injectStyles();
    const container = getContainer();

    const toast = document.createElement('div');
    toast.className = 'xp-toast';
    toast.style.borderLeftColor = '#FFD700';
    toast.style.borderColor = 'rgba(255,215,0,0.5)';
    toast.innerHTML = `
      <span class="xp-toast-icon">${icon || '🎖️'}</span>
      <div class="xp-toast-body">
        <span class="xp-toast-label">Новий ранг!</span>
        <span class="xp-toast-amount" style="color:#FFD700;font-size:18px;">${title}</span>
        <span class="xp-toast-reason">Вітаємо з підвищенням!</span>
      </div>
    `;
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('hiding');
      setTimeout(() => toast.remove(), 380);
    }, 6000);
  }

  // ── Polling logic ───────────────────────────────────────────
  const LAST_ACH_KEY = 'ac_last_ach_check';
  const RANK_KEY = 'ac_cached_rank';
  let _pollTimer = null;
  let _userId    = null;

  async function fetchNewAchievements(uid, since) {
    try {
      const res = await fetch(\`/api/achievements/recent/\${uid}?since=\${encodeURIComponent(since)}\`, { credentials: 'include' });
      if (!res.ok) return [];
      const data = await res.json();
      return data.achievements || [];
    } catch { return []; }
  }

  async function fetchRank(uid) {
    try {
      const res = await fetch(\`/api/profile/rank/\${uid}\`, { credentials: 'include' });
      if (!res.ok) return null;
      const data = await res.json();
      return data.rank || null;
    } catch { return null; }
  }

  async function pollGameData() {
    if (!_userId) return;

    // 1. Перевіряємо нові досягнення
    const lastCheck = localStorage.getItem(LAST_ACH_KEY) || new Date(Date.now() - 60000).toISOString();
    const nowISO = new Date().toISOString();

    const newAchievements = await fetchNewAchievements(_userId, lastCheck);

    if (newAchievements && newAchievements.length > 0) {
      // Показуємо тости з невеликою затримкою між ними
      newAchievements.forEach((ua, index) => {
        setTimeout(() => {
          if (ua.achievements) {
            showAchievementToast(ua.achievements);
          }
        }, index * 1000);
      });
    }
    
    // Оновлюємо час останньої перевірки (беремо найсвіжіший час досягнення, якщо є, або поточний час)
    if (newAchievements && newAchievements.length > 0) {
      const maxEarned = newAchievements.reduce((max, curr) => curr.earned_at > max ? curr.earned_at : max, newAchievements[0].earned_at);
      localStorage.setItem(LAST_ACH_KEY, maxEarned);
    } else {
      localStorage.setItem(LAST_ACH_KEY, nowISO);
    }

    // 2. Перевіряємо підвищення рангу
    const rank = await fetchRank(_userId);
    if (rank) {
      const cachedRank = localStorage.getItem(RANK_KEY) || '';
      
      if (!cachedRank) {
        localStorage.setItem(RANK_KEY, rank.rank_title || '');
      } else if (rank.rank_title && rank.rank_title !== cachedRank) {
        setTimeout(() => {
          showRankUpToast(rank.rank_icon, rank.rank_title);
        }, 800); // Затримка, щоб тости не накладалися
        localStorage.setItem(RANK_KEY, rank.rank_title);
      }
    }
  }

  // ── Щоденний вхід (Streak) ─────────────────────────────────
  async function recordDailyLogin() {
    try {
      await fetch('/api/profile/record-login', {
        method: 'POST',
        credentials: 'include'
      });
      // Якщо стрік відкрив досягнення, полінг це підхопить!
    } catch (e) {
      console.error('Помилка запису streak:', e);
    }
  }

  function startPolling(userId) {
    _userId = userId;

    // Спочатку реєструємо щоденний вхід
    recordDailyLogin();

    if (_pollTimer) return;

    pollGameData(); // перший запит одразу
    _pollTimer = setInterval(pollGameData, 15000); // кожні 15 сек
  }

  // ── Автозапуск після авторизації ─────────────────────────────────
  function tryStart() {
    const check = () => {
      const mgr = window.authManager;
      if (mgr && mgr.currentUser) {
        const uid = mgr.currentUser.user_id || mgr.currentUser.id;
        if (uid) {
          startPolling(uid);
          return;
        }
      }
      fetch('/api/auth/status', { credentials: 'include' })
        .then(r => r.json())
        .then(d => {
          const uid = d?.user?.id;
          if (uid) startPolling(uid);
        })
        .catch(() => {});
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => setTimeout(check, 800));
    } else {
      setTimeout(check, 800);
    }
  }

  // ── Експорт ───────────────────────────────────────────────────────
  window.showAchievementToast = showAchievementToast;
  window.showRankUpToast      = showRankUpToast;
  window.startGamification    = startPolling;

  tryStart();

})();
