// Універсальний скрипт для оновлення бейджа непрочитаних повідомлень у хедері
async function updateUnreadBadgeGlobal() {
    const badge = document.getElementById('unread-badge');
    if (!badge) return;
    try {
        const [chatsRes, groupsRes] = await Promise.all([
            fetch(`/api/chats?t=${new Date().getTime()}`, {
                headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0' }
            }),
            fetch(`/api/group-chats?t=${new Date().getTime()}`, {
                headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache', 'Expires': '0' }
            })
        ]);

        let totalUnread = 0;

        if (chatsRes.ok) {
            const data = await chatsRes.json();
            totalUnread += (data.chats || []).reduce((sum, c) => sum + (c.unread_count || 0), 0);
        }
        if (groupsRes.ok) {
            const data = await groupsRes.json();
            totalUnread += (data.groups || []).reduce((sum, g) => sum + (g.unread_count || 0), 0);
        }

        if (totalUnread > 0) {
            badge.textContent = totalUnread > 99 ? '99+' : totalUnread;
            badge.style.display = 'inline-flex';
        } else {
            badge.style.display = 'none';
        }
    } catch (e) {
        badge.style.display = 'none';
    }
}

function tryInitUnreadBadge() {
    if (document.getElementById('unread-badge')) {
        updateUnreadBadgeGlobal();
        setInterval(updateUnreadBadgeGlobal, 30000);
    } else {
        setTimeout(tryInitUnreadBadge, 100);
    }
}

document.addEventListener('DOMContentLoaded', tryInitUnreadBadge);
document.addEventListener('headerLoaded', tryInitUnreadBadge);