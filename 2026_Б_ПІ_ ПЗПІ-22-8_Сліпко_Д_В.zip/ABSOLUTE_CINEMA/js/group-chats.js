// ============================================================
// GROUP CHATS — group-chats.js
// ============================================================

let currentGroupId = null;
let currentGroupRole = null; // 'owner' | 'admin' | 'member'
let groupMembersCache = [];
let gcSelectedMembers = {}; // { userId: { username, avatar_url } }

// ── Утиліти ─────────────────────────────────────────────────
function gcEl(id) { return document.getElementById(id); }

function gcFormatTime(dateStr) {
    const d = new Date(dateStr);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    if (d >= today) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString();
}

function gcGetPreview(msg) {
    if (!msg) return 'Немає повідомлень';
    try {
        const p = JSON.parse(msg.content);
        if (p.type === 'system') return `• ${p.text}`;
        if (p.type === 'movie_repost') return `🎬 ${p.title || 'Фільм'}`;
        if (p.type === 'forwarded') return `↪ Переслано від ${p.original_username}`;
    } catch {}
    return msg.content.length > 50 ? msg.content.slice(0, 50) + '…' : msg.content;
}

function gcRoleLabel(role) {
    return role === 'owner' ? '👑 Власник' : role === 'admin' ? '🛡 Адмін' : '';
}

// ── Завантаження і рендер списку груп ───────────────────────
// Делегуємо до єдиного unified списку (визначено в chats.js)
async function loadGroupChats() {
    if (typeof loadUnifiedChats === 'function') {
        return loadUnifiedChats();
    }
}

// Залишаємо renderGroupChatsList як заглушку для зворотної сумісності
function renderGroupChatsList(groups) {
    // Rendering is handled by loadUnifiedChats in chats.js
}

// ── Відкрити груповий чат ────────────────────────────────────
async function openGroupChat(groupId) {
    currentGroupId = groupId;
    currentChatId = null; // скидаємо особистий чат

    // UI: показуємо active-chat, ховаємо no-chat
    const activeChat = gcEl('active-chat');
    const noChat = gcEl('no-chat-selected');
    if (activeChat) activeChat.style.display = 'flex';
    if (noChat) noChat.style.display = 'none';

    // Перемикаємо кнопки хедера
    const deleteBtn = gcEl('chat-delete-btn');
    const settingsBtn = gcEl('group-settings-btn');
    const leaveBtn = gcEl('group-leave-btn');
    if (deleteBtn) deleteBtn.style.display = 'none';
    if (settingsBtn) settingsBtn.style.display = 'flex';
    if (leaveBtn) leaveBtn.style.display = 'flex';

    // Завантажуємо учасників (для ролі)
    const membRes = await fetch(`/api/group-chats/${groupId}/members`, { credentials: 'include' });
    const membData = await membRes.json();
    currentGroupRole = membData.my_role || 'member';
    groupMembersCache = membData.members || [];

    // Встановлюємо назву групи в хедері
    const groupsRes = await fetch('/api/group-chats', { credentials: 'include' });
    const groupsData = await groupsRes.json();
    const group = (groupsData.groups || []).find(g => String(g.id) === String(groupId));
    if (group) {
        const nameEl = gcEl('chat-user-name');
        const bioEl = gcEl('chat-user-bio');
        const avatarEl = gcEl('chat-user-avatar');
        if (nameEl) nameEl.textContent = group.name;
        if (bioEl) bioEl.textContent = `${group.members_count} учасників`;
        if (avatarEl) avatarEl.style.display = 'none';
    }

    // Завантажуємо повідомлення
    await loadGroupMessages(groupId);

    // Оновлюємо активний елемент у сайдбарі
    document.querySelectorAll('.group-chat-item').forEach(el => {
        el.classList.toggle('active', el.dataset.groupId === String(groupId));
    });
    document.querySelectorAll('.chat-item:not(.group-chat-item)').forEach(el => el.classList.remove('active'));

    // Позначаємо як прочитані і одразу оновлюємо sidebar + хедер badge
    fetch(`/api/group-chats/${groupId}/read`, { method: 'POST', credentials: 'include' })
        .then(() => {
            loadGroupChats();
            if (typeof updateUnreadBadgeGlobal === 'function') updateUnreadBadgeGlobal();
        })
        .catch(() => {});
}

// ── Повідомлення групового чату ──────────────────────────────
async function loadGroupMessages(groupId) {
    const messagesEl = gcEl('chat-messages');
    if (!messagesEl) return;
    messagesEl.innerHTML = '<div class="loading-container"><i class="fas fa-spinner fa-spin"></i><p>Завантаження...</p></div>';

    const [msgsRes, membRes] = await Promise.all([
        fetch(`/api/group-chats/${groupId}/messages`, { credentials: 'include' }),
        fetch(`/api/group-chats/${groupId}/members`, { credentials: 'include' })
    ]);
    const msgsData = await msgsRes.json();
    const membData = await membRes.json();

    // Зберігаємо last_read_at для індикаторів прочитаних
    groupMembersCache = membData.members || [];
    renderGroupMessages(msgsData.messages || [], groupMembersCache);
}

function buildGroupMessageHTML(msg) {
    const cu = typeof currentUser !== 'undefined' ? currentUser : null;
    const isMine = cu && msg.sender_id === cu.user_id;
    const msgClass = isMine ? 'message-sent' : 'message-received';
    const time = gcFormatTime(msg.sent_at);
    const senderId = msg.sender_id || '';
    const senderUserId = msg.sender_profile?.user_id || senderId;
    const senderName = msg.sender_profile?.username || 'Користувач';
    const avatar = msg.sender_profile?.avatar_url || 'https://via.placeholder.com/28';
    const msgId = msg.id || 0;

    // Системне повідомлення
    try {
        const p = JSON.parse(msg.content);
        if (p.type === 'system') {
            return `<div class="group-system-msg">${p.text}</div>`;
        }
    } catch {}

    // Reply quote
    let replyHTML = '';
    if (msg.reply_to) {
        const rt = msg.reply_to;
        const rtPreview = rt.content.length > 60 ? rt.content.slice(0, 60) + '…' : rt.content;
        replyHTML = `
            <a class="msg-reply-quote" href="#msg-${rt.id}" onclick="scrollToMessage(${rt.id})">
                <span class="msg-reply-author">${rt.sender_username || 'Користувач'}</span>
                <span class="msg-reply-text">${rtPreview}</span>
            </a>`;
    }

    // Контент
    let contentHTML = msg.content;
    try {
        const p = JSON.parse(msg.content);
        if (p.type === 'movie_repost') {
            const year = p.release_date ? new Date(p.release_date).getFullYear() : '';
            contentHTML = `
                <a href="${p.url}" class="chat-movie-card" title="Відкрити фільм">
                    <div class="chat-movie-poster">${p.poster_url ? `<img src="${p.poster_url}" alt="${p.title}">` : '<div class="chat-movie-no-poster"><i class="fas fa-film"></i></div>'}</div>
                    <div class="chat-movie-info">
                        <div class="chat-movie-label"><i class="fas fa-share-alt"></i> Поділився фільмом</div>
                        <div class="chat-movie-title">${p.title}</div>
                        <div class="chat-movie-meta">${year}</div>
                        <div class="chat-movie-link">Переглянути <i class="fas fa-arrow-right"></i></div>
                    </div>
                </a>`;
        } else if (p.type === 'forwarded') {
            contentHTML = `
                <div class="msg-forwarded">
                    <div class="msg-forwarded-header"><i class="fas fa-share"></i> Переслано від
                        <a href="/profile.html?id=${p.original_user_id}" class="msg-forwarded-author">${p.original_username}</a>
                    </div>
                    <div class="msg-forwarded-text">${p.original_content}</div>
                </div>`;
        }
    } catch {}

    // Показуємо ім'я + аватар відправника (з посиланням на профіль)
    const senderHTML = isMine ? '' : `
        <div class="group-msg-sender">
            <img src="${avatar}" class="group-msg-avatar">
            <a href="/profile.html?id=${senderUserId}" class="group-msg-name">${senderName}</a>
        </div>`;

    // Індикатор прочитаних (тільки для власних повідомлень)
    const readCount = isMine ? (msg._readCount || 0) : 0;
    const readIndicator = (isMine && readCount > 0)
        ? `<span class="group-read-indicator" title="Прочитали ${readCount}"><i class="far fa-eye"></i> ${readCount}</span>`
        : (isMine ? '<span class="group-read-indicator unread"><i class="far fa-clock"></i></span>' : '');

    return `
        <div class="message ${msgClass}" id="msg-${msgId}" data-msg-id="${msgId}">
            ${senderHTML}
            ${replyHTML}
            <div class="message-content">${contentHTML}</div>
            <div class="message-meta">
                <span class="message-time">${time}</span>
                ${readIndicator}
            </div>
            <div class="msg-actions">
                <button class="msg-action-btn reply-btn" onclick="startReply(${msgId})"><i class="fas fa-reply"></i> Відповісти</button>
            </div>
        </div>`;
}

function renderGroupMessages(messages, members) {
    const el = gcEl('chat-messages');
    if (!el) return;
    if (!messages.length) {
        el.innerHTML = '<div class="empty-messages"><p>Напишіть перше повідомлення!</p></div>';
        return;
    }

    const cu = typeof currentUser !== 'undefined' ? currentUser : null;

    // Предобчислюємо для кожного повідомлення: скільки учасників його прочитали
    if (members && members.length) {
        messages = messages.map(msg => {
            const msgTime = new Date(msg.sent_at).getTime();
            const readCount = (members || []).filter(m => {
                // Не рахуємо себе самого відправника
                if (m.user_id === msg.sender_id) return false;
                return m.last_read_at && new Date(m.last_read_at).getTime() >= msgTime;
            }).length;
            return { ...msg, _readCount: readCount };
        });
    }

    el.innerHTML = messages.map(msg => buildGroupMessageHTML(msg)).join('');
    el.scrollTop = el.scrollHeight;
}

// ── Відправка повідомлення ───────────────────────────────────
async function sendGroupMessage() {
    if (!currentGroupId) return;
    const input = gcEl('chat-input');
    const content = input?.value?.trim();
    if (!content) return;

    // Зберігаємо reply ДО cancelReply, щоб можна було відрендерити цитату
    const savedReply = (typeof replyingTo !== 'undefined' && replyingTo) ? { ...replyingTo } : null;

    const body = { content };
    if (savedReply) {
        body.reply_to_id = savedReply.id;
    }

    const res = await fetch(`/api/group-chats/${currentGroupId}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body)
    });

    if (res.ok) {
        const data = await res.json();
        input.value = '';
        if (typeof cancelReply === 'function') cancelReply();

        // Якщо сервер не повернув повний об'єкт reply_to — додаємо вручну із збереженого
        if (savedReply && data.message && !data.message.reply_to) {
            data.message.reply_to = {
                id: savedReply.id,
                content: savedReply.content,
                sender_username: savedReply.sender_username
            };
        }

        const msgHTML = buildGroupMessageHTML(data.message);
        const messagesEl = gcEl('chat-messages');
        if (messagesEl) {
            messagesEl.insertAdjacentHTML('beforeend', msgHTML);
            messagesEl.scrollTop = messagesEl.scrollHeight;
        }
        loadGroupChats(); // оновлюємо превю
    }
}

// ── Панель управління групою ─────────────────────────────────
function openGroupPanel() {
    const panel = gcEl('groupPanel');
    const overlay = gcEl('groupPanelOverlay');
    if (!panel || !currentGroupId) return;
    panel.classList.add('open');
    overlay.classList.add('visible');
    renderGroupPanel();
}

function closeGroupPanel() {
    gcEl('groupPanel')?.classList.remove('open');
    gcEl('groupPanelOverlay')?.classList.remove('visible');
}

async function renderGroupPanel() {
    const res = await fetch(`/api/group-chats/${currentGroupId}/members`, { credentials: 'include' });
    const data = await res.json();
    const members = data.members || [];
    const myRole = data.my_role || 'member';
    currentGroupRole = myRole;
    groupMembersCache = members;

    // Назва
    const nameEl = gcEl('groupPanelName');
    if (nameEl) nameEl.textContent = gcEl('chat-user-name')?.textContent || 'Група';

    // Кількість
    const countEl = gcEl('gpMembersCount');
    if (countEl) countEl.textContent = `(${members.length})`;

    // Секції доступні owner/admin
    const isPrivileged = ['owner', 'admin'].includes(myRole);
    const gpRename = gcEl('gpRenameSection');
    const gpAdd = gcEl('gpAddMemberSection');
    const gpTransfer = gcEl('gpTransferSection');
    const gpDelete = gcEl('gpDeleteSection');

    if (gpRename) gpRename.style.display = isPrivileged ? '' : 'none';
    if (gpAdd) gpAdd.style.display = isPrivileged ? '' : 'none';
    if (gpTransfer) gpTransfer.style.display = myRole === 'owner' ? '' : 'none';
    if (gpDelete) gpDelete.style.display = myRole === 'owner' ? '' : 'none';

    // Список учасників
    const cu = typeof currentUser !== 'undefined' ? currentUser : null;
    const listEl = gcEl('gpMembersList');
    if (listEl) {
        listEl.innerHTML = members.map(m => {
            const isMe = cu && m.user_id === cu.user_id;
            const canManage = myRole === 'owner' && m.role !== 'owner';
            const adminToggleBtn = canManage ? `
                <button class="gp-role-btn" onclick="gcToggleRole('${m.user_id}','${m.role}','${m.profile.username}')">
                    ${m.role === 'admin' ? '<i class="fas fa-user-minus"></i>' : '<i class="fas fa-shield-alt"></i>'}
                </button>` : '';
            const kickBtn = (isPrivileged && !isMe && m.role !== 'owner' && !(myRole === 'admin' && m.role === 'admin')) ? `
                <button class="gp-kick-btn" onclick="gcKickMember('${m.user_id}','${m.profile.username}')">
                    <i class="fas fa-user-times"></i>
                </button>` : '';
            return `
                <div class="gp-member-row">
                    <img src="${m.profile.avatar_url || 'https://via.placeholder.com/32'}" class="gp-member-avatar">
                    <div class="gp-member-info">
                        <span class="gp-member-name">${m.profile.username}${isMe ? ' (Ви)' : ''}</span>
                        <span class="gp-member-role">${gcRoleLabel(m.role)}</span>
                    </div>
                    <div class="gp-member-actions">${adminToggleBtn}${kickBtn}</div>
                </div>`;
        }).join('');
    }

    // Transfer select
    const transferSel = gcEl('gpTransferSelect');
    if (transferSel) {
        const others = members.filter(m => m.role !== 'owner');
        transferSel.innerHTML = others.map(m =>
            `<option value="${m.user_id}">${m.profile.username}</option>`
        ).join('');
    }
}

async function gcToggleRole(userId, currentRole, username) {
    const newRole = currentRole === 'admin' ? 'member' : 'admin';
    const label = newRole === 'admin' ? 'адміністратором' : 'учасником';
    if (!confirm(`Зробити ${username} ${label}?`)) return;
    const res = await fetch(`/api/group-chats/${currentGroupId}/members/${userId}/role`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        credentials: 'include', body: JSON.stringify({ role: newRole })
    });
    if (res.ok) { renderGroupPanel(); loadGroupMessages(currentGroupId); }
    else { const d = await res.json(); alert(d.error); }
}

async function gcKickMember(userId, username) {
    if (!confirm(`Виключити ${username} з групи?`)) return;
    const res = await fetch(`/api/group-chats/${currentGroupId}/members/${userId}`, {
        method: 'DELETE', credentials: 'include'
    });
    if (res.ok) { renderGroupPanel(); loadGroupMessages(currentGroupId); }
    else { const d = await res.json(); alert(d.error); }
}

// ── Вийти з групи ────────────────────────────────────────────
async function leaveGroup() {
    const cu = typeof currentUser !== 'undefined' ? currentUser : null;
    if (!cu || !currentGroupId) return;

    const res = await fetch(`/api/group-chats/${currentGroupId}/members/${cu.user_id}`, {
        method: 'DELETE', credentials: 'include'
    });
    const data = await res.json();

    if (res.ok) {
        currentGroupId = null;
        gcEl('active-chat').style.display = 'none';
        gcEl('no-chat-selected').style.display = 'flex';
        gcEl('chat-delete-btn').style.display = '';
        gcEl('group-settings-btn').style.display = 'none';
        gcEl('group-leave-btn').style.display = 'none';
        loadGroupChats();
    } else if (data.code === 'MUST_TRANSFER') {
        alert('Ви власник групи. Спочатку передайте права власника іншому учаснику через Налаштування групи.');
        openGroupPanel();
    } else if (data.code === 'LAST_MEMBER') {
        if (confirm('Ви єдиний учасник. Видалити групу?')) gcDeleteGroup();
    } else {
        alert(data.error || 'Помилка');
    }
}

async function gcDeleteGroup() {
    if (!currentGroupId) return;
    const res = await fetch(`/api/group-chats/${currentGroupId}`, {
        method: 'DELETE', credentials: 'include'
    });
    if (res.ok) {
        currentGroupId = null;
        closeGroupPanel();
        gcEl('active-chat').style.display = 'none';
        gcEl('no-chat-selected').style.display = 'flex';
        gcEl('chat-delete-btn').style.display = '';
        gcEl('group-settings-btn').style.display = 'none';
        gcEl('group-leave-btn').style.display = 'none';
        loadGroupChats();
    } else {
        const d = await res.json();
        alert(d.error || 'Помилка видалення');
    }
}

// ── Модалка: Створити групу ──────────────────────────────────
function openCreateGroupModal() {
    gcEl('createGroupModal').classList.add('active');
    gcEl('groupNameInput').value = '';
    gcEl('gcSearchInput').value = '';
    gcEl('gcSearchResults').innerHTML = '';
    gcEl('gcSelectedMembers').innerHTML = '';
    gcSelectedMembers = {};
    document.body.style.overflow = 'hidden';
}

function closeCreateGroupModal() {
    gcEl('createGroupModal').classList.remove('active');
    document.body.style.overflow = '';
}

async function gcSearchUsers(query, resultsEl, onSelect) {
    if (!query.trim()) return;
    const res = await fetch(`/api/users/search?query=${encodeURIComponent(query)}`, { credentials: 'include' });
    const data = await res.json();
    const users = data.users || [];
    if (!users.length) { resultsEl.innerHTML = '<div class="gc-no-results">Нікого не знайдено</div>'; return; }
    resultsEl.innerHTML = users.map(u => `
        <div class="gc-user-result" data-user-id="${u.user_id}">
            <img src="${u.avatar_url || 'https://via.placeholder.com/32'}" class="gc-result-avatar">
            <span>${u.username}</span>
        </div>`).join('');
    resultsEl.querySelectorAll('.gc-user-result').forEach(el => {
        el.addEventListener('click', () => onSelect(el.dataset.userId, users.find(u => u.user_id === el.dataset.userId)));
    });
}

function gcAddSelectedMember(userId, profile) {
    if (gcSelectedMembers[userId]) return;
    gcSelectedMembers[userId] = profile;
    renderGcSelectedMembers();
}

function renderGcSelectedMembers() {
    const el = gcEl('gcSelectedMembers');
    if (!el) return;
    el.innerHTML = Object.entries(gcSelectedMembers).map(([uid, p]) => `
        <div class="gc-chip">
            <img src="${p.avatar_url || 'https://via.placeholder.com/20'}" class="gc-chip-avatar">
            <span>${p.username}</span>
            <button onclick="gcRemoveSelected('${uid}')"><i class="fas fa-times"></i></button>
        </div>`).join('');
}

function gcRemoveSelected(uid) {
    delete gcSelectedMembers[uid];
    renderGcSelectedMembers();
}

async function submitCreateGroup() {
    const name = gcEl('groupNameInput')?.value?.trim();
    if (!name) { alert('Введіть назву групи'); return; }

    const memberIds = Object.keys(gcSelectedMembers);
    const res = await fetch('/api/group-chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ name, member_ids: memberIds })
    });
    const data = await res.json();
    if (res.ok) {
        closeCreateGroupModal();
        await loadGroupChats();
        openGroupChat(data.group.id);
    } else {
        alert(data.error || 'Помилка створення групи');
    }
}

// ── Ініціалізація ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    // Чекаємо поки currentUser завантажиться (auth.js)
    const waitForUser = setInterval(() => {
        if (typeof currentUser !== 'undefined' && currentUser) {
            clearInterval(waitForUser);
            loadGroupChats();
            initGroupChatEvents();
        }
    }, 300);
    // Timeout fallback
    setTimeout(() => { clearInterval(waitForUser); loadGroupChats(); initGroupChatEvents(); }, 3000);
});

function initGroupChatEvents() {
    // Нова група
    gcEl('new-group-btn')?.addEventListener('click', openCreateGroupModal);
    gcEl('createGroupClose')?.addEventListener('click', closeCreateGroupModal);
    gcEl('createGroupClose2')?.addEventListener('click', closeCreateGroupModal);
    gcEl('createGroupModal')?.addEventListener('click', e => { if (e.target === gcEl('createGroupModal')) closeCreateGroupModal(); });

    // Пошук у create modal
    gcEl('gcSearchBtn')?.addEventListener('click', () => {
        gcSearchUsers(gcEl('gcSearchInput').value, gcEl('gcSearchResults'), (uid, profile) => {
            gcAddSelectedMember(uid, profile);
            gcEl('gcSearchResults').innerHTML = '';
            gcEl('gcSearchInput').value = '';
        });
    });
    gcEl('gcSearchInput')?.addEventListener('keydown', e => {
        if (e.key === 'Enter') gcEl('gcSearchBtn').click();
    });

    // Створити групу
    gcEl('createGroupSubmit')?.addEventListener('click', submitCreateGroup);

    // Налаштування групи
    gcEl('group-settings-btn')?.addEventListener('click', openGroupPanel);
    gcEl('groupPanelClose')?.addEventListener('click', closeGroupPanel);
    gcEl('groupPanelOverlay')?.addEventListener('click', closeGroupPanel);

    // Вийти з групи
    gcEl('group-leave-btn')?.addEventListener('click', leaveGroup);

    // Rename
    gcEl('gpRenameBtn')?.addEventListener('click', async () => {
        const name = gcEl('gpRenameInput')?.value?.trim();
        if (!name) return;
        const res = await fetch(`/api/group-chats/${currentGroupId}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            credentials: 'include', body: JSON.stringify({ name })
        });
        if (res.ok) {
            gcEl('chat-user-name').textContent = name;
            gcEl('groupPanelName').textContent = name;
            gcEl('gpRenameInput').value = '';
            loadGroupMessages(currentGroupId);
            loadGroupChats();
        } else { const d = await res.json(); alert(d.error); }
    });

    // Transfer ownership
    gcEl('gpTransferBtn')?.addEventListener('click', async () => {
        const newOwnerId = gcEl('gpTransferSelect')?.value;
        if (!newOwnerId) return;
        const member = groupMembersCache.find(m => m.user_id === newOwnerId);
        if (!confirm(`Передати права власника ${member?.profile?.username || newOwnerId}?`)) return;
        const res = await fetch(`/api/group-chats/${currentGroupId}/transfer-ownership`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            credentials: 'include', body: JSON.stringify({ new_owner_id: newOwnerId })
        });
        if (res.ok) { renderGroupPanel(); loadGroupMessages(currentGroupId); }
        else { const d = await res.json(); alert(d.error); }
    });

    // Add member from panel
    gcEl('gpAddSearchBtn')?.addEventListener('click', () => {
        gcSearchUsers(gcEl('gpAddInput').value, gcEl('gpAddResults'), async (uid, profile) => {
            const res = await fetch(`/api/group-chats/${currentGroupId}/members`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                credentials: 'include', body: JSON.stringify({ user_id: uid })
            });
            if (res.ok) {
                gcEl('gpAddResults').innerHTML = '';
                gcEl('gpAddInput').value = '';
                renderGroupPanel();
                loadGroupMessages(currentGroupId);
                loadGroupChats();
            } else { const d = await res.json(); alert(d.error); }
        });
    });
    gcEl('gpAddInput')?.addEventListener('keydown', e => {
        if (e.key === 'Enter') gcEl('gpAddSearchBtn').click();
    });

    // Delete group
    gcEl('gpDeleteBtn')?.addEventListener('click', () => {
        if (confirm('Видалити групу? Це незворотньо.')) gcDeleteGroup();
    });

    // Escape
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') { closeCreateGroupModal(); closeGroupPanel(); }
    });
}
