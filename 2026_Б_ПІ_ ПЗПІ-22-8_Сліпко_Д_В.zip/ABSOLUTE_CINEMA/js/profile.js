/* profile.js - Скрипти для сторінки профілю ABSOLUTE CINEMA */

// Клас для управління сторінкою профілю
class ProfileManager {
  constructor() {
    // Основні елементи профілю
    this.avatar = document.getElementById('profile-avatar-img');
    this.username = document.getElementById('profile-username');
    this.joinDate = document.getElementById('profile-join-date');
    this.bio = document.getElementById('profile-bio');
    this.socialLinks = document.getElementById('social-links');

    // Лічильники статистики
    this.reviewsCount = document.getElementById('reviews-count');
    this.favoritesCount = document.getElementById('favorites-count');
    this.commentsCount = document.getElementById('comments-count');

    // Вкладки профілю
    this.tabs = document.querySelectorAll('.profile-tabs .tab');
    this.tabContents = document.querySelectorAll('.tab-content');

    // Модальне вікно редагування
    this.editProfileModal = document.getElementById('edit-profile-modal');
    this.editAvatarBtn = document.getElementById('edit-avatar-btn');
    this.editProfileBtn = document.getElementById('edit-profile-btn');

    // Поля форми редагування
    this.editUsernameInput = document.getElementById('edit-username');
    this.editBioInput = document.getElementById('edit-bio');
    this.socialInputs = {
      imdb: document.getElementById('imdb-link'),
      instagram: document.getElementById('instagram-link'),
      twitter: document.getElementById('twitter-link'),
      letterboxd: document.getElementById('letterboxd-link')
    };

    // Дані профілю
    this.profileData = null;

    // Ініціалізація
    this.init();
  }

  // Ініціалізація сторінки профілю
  async init() {
    try {
      console.log('Ініціалізація профілю користувача...');

      document.body.classList.add('loading');

      // Завантажуємо хедер (компонент)
      console.log('Завантаження хедера для профілю...');
      await this.loadHeader();

      // Отримуємо id користувача з URL
      const params = new URLSearchParams(window.location.search);
      const profileUserId = params.get('id');
      this.profileUserId = profileUserId;

      // Завантажуємо дані профілю
      console.log('Завантаження даних профілю...');
      const profileData = await this.loadProfileData();

      if (!profileData) {
        console.error('Дані профілю не завантажено');
        this.showNotification('Не вдалося завантажити дані профілю. Спробуйте оновити сторінку.', 'error');
      }

      // Налаштування обробників подій
      console.log('Налаштування обробників подій...');
      this.setupEventListeners();

      // За замовчуванням активна перша вкладка
      console.log('Активація першої вкладки...');
      this.tabs[0].click();

      document.body.classList.remove('loading');
      console.log('Ініціалізація профілю завершена');
    } catch (error) {
      console.error('Критична помилка при ініціалізації профілю:', error);
      this.showNotification('Критична помилка при завантаженні профілю: ' + error.message, 'error');
      document.body.classList.remove('loading');
    }
  }

  // Завантаження хедера
  async loadHeader() {
    try {
      const headerContainer = document.getElementById('header-container');
      if (!headerContainer) {
        console.error('Контейнер хедера не знайдено');
        return;
      }

      // Використовуємо функцію з компонентів
      if (typeof window.loadHeader === 'function') {
        console.log('Виклик функції loadHeader з компонентів...');
        await window.loadHeader();
        console.log('Хедер успішно завантажено');
      } else {
        console.warn('Функцію завантаження хедера не знайдено, створюю базовий хедер');

        // Резервний варіант - створюємо простий хедер з навігацією на головну
        headerContainer.innerHTML = `
          <header id="main-header">
            <div class="header-container">
              <div class="logo">
                <a href="/" id="logo-link">ABSOLUTE CINEMA</a>
              </div>
              <nav class="main-nav">
                <ul>
                  <li><a href="/" class="nav-link"><i class="fas fa-home"></i>ГОЛОВНА</a></li>
                  <li><a href="/movies" class="nav-link"><i class="fas fa-film"></i>ФІЛЬМИ</a></li>
                  <li><a href="/series" class="nav-link"><i class="fas fa-tv"></i>СЕРІАЛИ</a></li>
                  <li><a href="/discussions" class="nav-link"><i class="fas fa-comments"></i>ЧАТИ</a></li>
                  <li><a href="/ratings" class="nav-link"><i class="fas fa-star"></i>РЕЙТИНГИ</a></li>
                </ul>
              </nav>
              <div class="header-controls">
                <div class="login-button">
                  <a href="/" id="profile-link">ПОВЕРНУТИСЯ НА ГОЛОВНУ</a>
                </div>
              </div>
            </div>
          </header>
        `;
      }
    } catch (error) {
      console.error('Помилка при завантаженні хедера для профілю:', error);
      throw new Error('Не вдалося завантажити хедер: ' + error.message);
    }
  }

  // Завантаження даних профілю з сервера
  async loadProfileData() {
    try {
      console.log('Починаю завантаження даних профілю...');

      // Додаємо затримку для завершення завантаження хедера та інших компонентів
      await new Promise(resolve => setTimeout(resolve, 300));

      let url = '/api/profile';
      if (this.profileUserId) {
        url = `/api/users/${this.profileUserId}`;
      }
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        },
        credentials: 'include'
      });

      console.log('Отримано відповідь від API:', response.status, response.statusText);

      if (!response.ok) {
        console.error('Помилка при завантаженні профілю. Статус:', response.status);
        let errorMessage = 'Не вдалося завантажити дані профілю';

        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          console.error('Не вдалося прочитати відповідь від сервера:', e);
        }

        throw new Error(errorMessage);
      }

      let data;
      try {
        data = await response.json();
        console.log('Отримано дані профілю:', data);
      } catch (e) {
        console.error('Помилка при розборі JSON:', e);
        throw new Error('Невірний формат даних профілю');
      }

      // Перевірка наявності профілю
      if (!data.profile) {
        console.error('Профіль не знайдено у відповіді API');
        // Створення базової структури для відображення
        data = {
          profile: {
            username: 'Невідомий користувач',
            created_at: new Date().toISOString(),
            bio: 'Інформація відсутня',
            social_links: {}
          },
          stats: {
            reviews: 0,
            favorites: 0,
            comments: 0
          }
        };

        this.showNotification('Профіль користувача не знайдено. Відображаються базові дані.', 'warning');
      }

      this.profileData = data;

      // Відображаємо дані на сторінці
      this.renderProfileData();

      return data;
    } catch (error) {
      console.error('Помилка при завантаженні даних профілю:', error);
      this.showNotification('Не вдалося завантажити дані профілю: ' + error.message, 'error');

      // Перенаправляємо на сторінку входу, якщо користувач не авторизований
      if (error.message.includes('не авторизований') || error.message.includes('unauthorized')) {
        console.log('Перенаправлення на сторінку входу через відсутність авторизації');
        window.location.href = '/login';
        return null;
      }

      // Створюємо базовий профіль для аварійного відображення
      this.profileData = {
        profile: {
          username: 'Помилка завантаження',
          created_at: new Date().toISOString(),
          bio: 'Не вдалося завантажити дані профілю. Спробуйте оновити сторінку.',
          social_links: {}
        },
        stats: {
          reviews: 0,
          favorites: 0,
          comments: 0
        }
      };

      // Відображаємо доступні дані
      this.renderProfileData();

      return null;
    }
  }

  // Відображення даних профілю на сторінці
  renderProfileData() {
    if (!this.profileData || !this.profileData.profile) {
      this.showNotification('Дані профілю відсутні', 'warning');
      return;
    }

    const { profile, stats } = this.profileData;

    // Основна інформація
    this.username.textContent = profile.username || 'Немає імені';

    // Аватар
    if (profile.avatar_url) {
      this.avatar.src = profile.avatar_url;
    } else {
      // Стандартний аватар, якщо немає завантаженого
      this.avatar.src = 'https://via.placeholder.com/150?text=' + profile.username.charAt(0).toUpperCase();
    }

    // Дата реєстрації
    const createdDate = new Date(profile.created_at);
    const dateOptions = { day: 'numeric', month: 'long', year: 'numeric' };
    this.joinDate.innerHTML = `На сайті з: <span>${createdDate.toLocaleDateString('uk-UA', dateOptions)}</span>`;

    // Біографія
    if (profile.bio) {
      this.bio.textContent = profile.bio;
    } else {
      this.bio.textContent = 'Інформація відсутня';
      this.bio.classList.add('empty-bio');
    }

    // Соціальні мережі
    this.renderSocialLinks(profile.social_links);

    // Статистика
    if (stats) {
      this.reviewsCount.textContent = stats.reviews;
      this.favoritesCount.textContent = stats.favorites;
      this.commentsCount.textContent = stats.comments;
    }

    // Заповнюємо форму редагування поточними даними
    this.populateEditForm(profile);

    // Завантажуємо блок рангу
    this.loadUserRank(profile.user_id);

    // Приховуємо кнопку редагування, якщо це не ваш профіль
    let isOwnProfile = true;
    if (this.profileUserId && window.authManager && window.authManager.currentUser) {
      isOwnProfile = (window.authManager.currentUser.user_id == this.profileUserId);
    } else if (this.profileUserId) {
      isOwnProfile = false;
    }
    if (this.editProfileBtn) {
      this.editProfileBtn.style.display = isOwnProfile ? '' : 'none';
    }
    if (this.editAvatarBtn) {
      this.editAvatarBtn.style.display = isOwnProfile ? '' : 'none';
    }
    // Приховуємо вкладку "Обране" для чужих профілів
    const favoritesTab = document.querySelector('.profile-tabs .tab[data-tab="favorites"]');
    const favoritesContent = document.getElementById('favorites-tab');
    if (favoritesTab && favoritesContent) {
      if (!isOwnProfile) {
        favoritesTab.style.display = 'none';
        favoritesContent.style.display = 'none';
      } else {
        favoritesTab.style.display = '';
        // Не активуємо вкладку, просто показуємо якщо свій профіль
      }
    }

    // Кнопка 'Написати' для чужого профілю
    let writeBtn = document.getElementById('write-message-btn');
    if (!isOwnProfile) {
      if (!writeBtn) {
        writeBtn = document.createElement('button');
        writeBtn.className = 'write-message-btn';
        writeBtn.id = 'write-message-btn';
        writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
        const actions = document.querySelector('.profile-actions');
        if (actions) actions.appendChild(writeBtn);
      }
      // Скидання стану кнопки завжди при рендері
      writeBtn.style.display = '';
      writeBtn.disabled = false;
      writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
      writeBtn.onclick = async () => {
        try {
          writeBtn.disabled = true;
          writeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Зачекайте...';
          const response = await fetch('/api/chats', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: this.profileUserId })
          });
          const data = await response.json();
          if (response.ok && data.chat && data.chat.id) {
            window.location.href = '/chats.html?chat=' + data.chat.id;
          } else {
            alert('Не вдалося створити або знайти чат: ' + (data.error || 'Невідома помилка'));
            writeBtn.disabled = false;
            writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
          }
        } catch (e) {
          alert('Сталася помилка: ' + e.message);
          writeBtn.disabled = false;
          writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
        }
      };
    } else if (writeBtn) {
      writeBtn.style.display = 'none';
      writeBtn.disabled = false;
      writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
    }
  }
  
  // Відображення соціальних посилань
  renderSocialLinks(socialLinks) {
    // Очищаємо контейнер
    this.socialLinks.innerHTML = '';

    if (!socialLinks || Object.keys(socialLinks).length === 0) {
      const noLinks = document.createElement('div');
      noLinks.className = 'no-social-links';
      noLinks.textContent = 'Соціальні мережі не додані';
      this.socialLinks.appendChild(noLinks);
      return;
    }

    // Створюємо посилання для кожної соціальної мережі
    for (const [network, url] of Object.entries(socialLinks)) {
      if (!url) continue;

      const link = document.createElement('a');
      // Переконаємось, що URL починається з http:// або https://
      const fullUrl = url.startsWith('http://') || url.startsWith('https://') ? url : `https://${url}`;
      link.href = fullUrl;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.className = `social-link ${network}`;

      // Визначаємо іконку
      let icon;
      let networkName;
      
      switch (network) {
        case 'imdb':
          icon = 'fa-imdb';
          networkName = 'IMDb';
          break;
        case 'instagram':
          icon = 'fa-instagram';
          networkName = 'Instagram';
          break;
        case 'twitter':
          icon = 'fa-twitter';
          networkName = 'Twitter';
          break;
        case 'letterboxd':
          icon = 'fa-letterboxd';
          networkName = 'Letterboxd';
          break;
        default:
          icon = 'fa-link';
          networkName = network.charAt(0).toUpperCase() + network.slice(1);
      }
      
      link.innerHTML = `<i class="fab ${icon}"></i> ${networkName}`;
      this.socialLinks.appendChild(link);
    }
  }
  
  // Заповнення форми редагування профілю поточними даними
  populateEditForm(profile) {
    this.editUsernameInput.value = profile.username || '';
    this.editBioInput.value = profile.bio || '';

    // Заповнюємо соціальні посилання
    const socialLinks = profile.social_links || {};

    for (const [network, input] of Object.entries(this.socialInputs)) {
      input.value = socialLinks[network] || '';
    }
  }

  // Обробка відправки форми редагування профілю
  async handleProfileUpdate(e) {
    e.preventDefault();

    try {
      // Збираємо дані форми
      const username = this.editUsernameInput.value.trim();
      const bio = this.editBioInput.value.trim();

      // Перевіряємо ім'я користувача
      if (!username) {
        throw new Error('Ім\'я користувача не може бути порожнім');
      }

      // Збираємо соціальні посилання
      const socialLinks = {};
      for (const [network, input] of Object.entries(this.socialInputs)) {
        const value = input.value.trim();
        if (value) {
          socialLinks[network] = value;
        }
      }

      // Надсилаємо запит на оновлення
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username,
          bio,
          social_links: socialLinks
        }),
        credentials: 'include'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Не вдалося оновити профіль');
      }

      const data = await response.json();

      // Оновлюємо дані профілю і перемальовуємо сторінку
      if (this.profileData) {
        this.profileData.profile = data.profile;
        this.renderProfileData();
      }

      // Закриваємо модальне вікно
      this.closeEditModal();

      // Показуємо сповіщення про успішне оновлення
      this.showNotification('Профіль успішно оновлено', 'success');
    } catch (error) {
      console.error('Помилка при оновленні профілю:', error);
      this.showFormError(error.message);
    }
  }

  // Обробка завантаження нового аватара
  async handleAvatarUpdate() {
    try {
      // Тут буде код для завантаження аватара (потрібна додаткова логіка для завантаження файлів)
      // У найпростішому випадку можемо використати URL
      const avatarUrl = prompt('Введіть URL зображення для аватара:', this.profileData?.profile?.avatar_url || '');

      if (!avatarUrl) return;

      // Надсилаємо запит на оновлення аватара
      const response = await fetch('/api/profile/avatar', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          avatar_url: avatarUrl
        }),
        credentials: 'include'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Не вдалося оновити аватар');
      }

      const data = await response.json();

      // Оновлюємо дані профілю і перемальовуємо сторінку
      if (this.profileData) {
        this.profileData.profile = data.profile;
        this.renderProfileData();
      }

      // Показуємо сповіщення про успішне оновлення
      this.showNotification('Аватар успішно оновлено', 'success');
    } catch (error) {
      console.error('Помилка при оновленні аватара:', error);
      this.showNotification(error.message, 'error');
    }
  }

  // Налаштування обробників подій
  setupEventListeners() {
    // Перемикання вкладок
    this.tabs.forEach(tab => {
      tab.addEventListener('click', () => this.switchTab(tab));
    });

    // Відкриття модального вікна редагування профілю
    if (this.editProfileBtn) {
      this.editProfileBtn.addEventListener('click', () => this.openEditModal());
    }

    // Закриття модального вікна
    const closeModalBtn = this.editProfileModal?.querySelector('.modal-close');
    const modalOverlay = this.editProfileModal?.querySelector('.modal-overlay');

    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', () => this.closeEditModal());
    }

    if (modalOverlay) {
      modalOverlay.addEventListener('click', () => this.closeEditModal());
    }

    // Відправка форми редагування профілю
    const editProfileForm = document.getElementById('edit-profile-form');
    if (editProfileForm) {
      editProfileForm.addEventListener('submit', (e) => this.handleProfileUpdate(e));
    }

    // Обробка завантаження аватара
    if (this.editAvatarBtn) {
      this.editAvatarBtn.addEventListener('click', () => this.handleAvatarUpdate());
    }

    // Попереднє завантаження даних для вкладок при перемиканні
    if (this.tabs) {
      this.tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          const tabName = tab.getAttribute('data-tab');
          switch (tabName) {
            case 'reviews':
              this.loadUserReviews();
              break;
            case 'favorites':
              this.loadUserFavorites();
              break;
            case 'achievements':
              this.loadUserAchievements();
              break;
          }
        });
      });
    }
  }
  
  // Перемикання між вкладками
  switchTab(selectedTab) {
    // Отримуємо ім'я вкладки
    const tabName = selectedTab.getAttribute('data-tab');

    // Прибираємо активний клас у всіх вкладок
    this.tabs.forEach(tab => tab.classList.remove('active'));

    // Додаємо активний клас обраній вкладці
    selectedTab.classList.add('active');

    // Приховуємо весь вміст вкладок
    this.tabContents.forEach(content => content.classList.remove('active'));

    // Показуємо вміст обраної вкладки
    const selectedContent = document.getElementById(`${tabName}-tab`);
    if (selectedContent) {
      selectedContent.classList.add('active');
    }
  }

  // Відкриття модального вікна редагування профілю
  openEditModal() {
    try {
      if (this.editProfileModal) {
        // Спочатку переконаємось, що форма заповнена актуальними даними
        if (this.profileData && this.profileData.profile) {
          this.populateEditForm(this.profileData.profile);
        }

        // Блокуємо прокрутку body
        document.body.classList.add('modal-open');

        // Відображаємо модальне вікно
        this.editProfileModal.classList.add('active');

        console.log('Модальне вікно редагування профілю відкрито');
      } else {
        console.error('Модальне вікно не знайдено');
      }
    } catch (error) {
      console.error('Помилка при відкритті модального вікна:', error);
    }
  }

  // Закриття модального вікна редагування профілю
  closeEditModal() {
    try {
      if (this.editProfileModal) {
        // Приховуємо модальне вікно
        this.editProfileModal.classList.remove('active');

        // Розблоковуємо прокрутку body
        document.body.classList.remove('modal-open');

        // Видаляємо повідомлення про помилку, якщо воно є
        const errorMessage = this.editProfileModal.querySelector('.form-error');
        if (errorMessage) {
          errorMessage.remove();
        }

        console.log('Модальне вікно редагування профілю закрито');
      }
    } catch (error) {
      console.error('Помилка при закритті модального вікна:', error);
    }
  }

  // Відображення помилки форми
  showFormError(errorMessage) {
    const form = document.getElementById('edit-profile-form');
    if (!form) return;

    // Видаляємо попереднє повідомлення про помилку, якщо воно є
    const existingError = form.querySelector('.form-error');
    if (existingError) {
      existingError.remove();
    }

    // Створюємо елемент для відображення помилки
    const errorElement = document.createElement('div');
    errorElement.className = 'form-error';
    errorElement.textContent = errorMessage;

    // Вставляємо повідомлення про помилку перед кнопкою відправки
    const submitButton = form.querySelector('.save-profile-btn');
    form.insertBefore(errorElement, submitButton);
  }

  // Відображення сповіщення
  showNotification(message, type = 'info') {
    // Видаляємо попереднє сповіщення, якщо воно є
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    // Створюємо елемент сповіщення
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;

    // Додаємо іконку залежно від типу сповіщення
    let icon = '';
    switch (type) {
      case 'success':
        icon = '<i class="fas fa-check-circle"></i>';
        break;
      case 'error':
        icon = '<i class="fas fa-exclamation-circle"></i>';
        break;
      case 'warning':
        icon = '<i class="fas fa-exclamation-triangle"></i>';
        break;
      default:
        icon = '<i class="fas fa-info-circle"></i>';
    }

    // Формуємо вміст сповіщення
    notification.innerHTML = `
      ${icon}
      <span>${message}</span>
      <button class="notification-close"><i class="fas fa-times"></i></button>
    `;

    // Додаємо сповіщення на сторінку
    document.body.appendChild(notification);

    // Додаємо обробник закриття сповіщення
    const closeButton = notification.querySelector('.notification-close');
    if (closeButton) {
      closeButton.addEventListener('click', () => {
        notification.classList.add('closing');
        setTimeout(() => {
          notification.remove();
        }, 300);
      });
    }

    // Автоматичне приховування сповіщення через 5 секунд
    setTimeout(() => {
      if (document.body.contains(notification)) {
        notification.classList.add('closing');
        setTimeout(() => {
          if (document.body.contains(notification)) {
            notification.remove();
          }
        }, 300);
      }
    }, 5000);
  }
  
  // Завантаження рецензій користувача
  async loadUserReviews() {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) return;

    try {
      // Показуємо анімацію завантаження
      reviewsList.innerHTML = `
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Завантаження рецензій...</p>
        </div>
      `;

      // Отримуємо ID користувача з даних профілю
      if (!this.profileData || !this.profileData.profile) {
        await this.loadProfileData();
      }

      const userId = this.profileData?.profile?.user_id;
      if (!userId) {
        throw new Error('Дані користувача не знайдені');
      }

      // Визначаємо, чи це свій профіль
      let isOwnProfile = true;
      if (this.profileUserId && window.authManager && window.authManager.currentUser) {
        isOwnProfile = (window.authManager.currentUser.user_id == this.profileUserId);
      } else if (this.profileUserId) {
        isOwnProfile = false;
      }

      // Запитуємо список рецензій користувача
      const response = await fetch(`/api/reviews/user/${userId}`, {
        method: 'GET',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Не вдалося завантажити рецензії');
      }

      const data = await response.json();
      const reviews = data.reviews || [];

      // Якщо список порожній, показуємо відповідне повідомлення
      if (reviews.length === 0) {
        reviewsList.innerHTML = '<div class="empty-content">У вас поки немає рецензій</div>';
        return;
      }

      // Формуємо HTML з рецензіями
      let reviewsHTML = '';
      for (const review of reviews) {
        // Обрізаємо довгі рецензії та додаємо кнопку 'Дивитись повністю', повний текст і короткий текст у data-атрибутах
        const maxLength = 350;
        let isLong = review.content.length > maxLength;
        let shortText = isLong ? review.content.slice(0, maxLength) + '…' : review.content;
        let reviewTextHtml = `<p class="review-text" data-full-text="${encodeURIComponent(review.content)}" data-short-text="${encodeURIComponent(shortText)}">${shortText}</p>`;
        if (isLong) {
          reviewTextHtml += `<button class="show-full-review-btn toggle-review-btn">Дивитись повністю...</button>`;
        }
        reviewsHTML += `
          <div class="review-item">
            <div class="review-media">
              <a href="/movie/${review.media?.id || ''}">
                <img src="${review.media?.poster_url || 'https://via.placeholder.com/150x225?text=Немає+постера'}" alt="${review.media?.title || 'Фільм'}">
              </a>
              <div class="review-rating">${review.rating.toFixed(1)}</div>
            </div>
            <div class="review-content">
              ${isOwnProfile ? `<button class="delete-review-btn" data-id="${review.id}" style="background:#c0392b; color:#fff; border:none; border-radius:6px; padding:10px 16px; cursor:pointer; font-size:22px; display:inline-flex; align-items:center; justify-content:center; position:absolute; top:12px; right:16px; z-index:2;"><i class="fas fa-trash"></i></button>` : ''}
              <h3 class="review-title">
                <a href="/movie/${review.media?.id || ''}">${review.media?.title || 'Фільм видалено'}</a>
                <span class="review-year">${review.media?.release_date ? new Date(review.media.release_date).getFullYear() : ''}</span>
              </h3>
              <div class="review-date">${new Date(review.created_at).toLocaleDateString('uk-UA')}</div>
              ${reviewTextHtml}
            </div>
          </div>
        `;
      }
      
      reviewsList.innerHTML = reviewsHTML;
      // Додаю обробник для показу/згортання повного тексту рецензії
      const showFullBtns = reviewsList.querySelectorAll('.show-full-review-btn');
      showFullBtns.forEach((btn) => {
        btn.addEventListener('click', function() {
          const reviewText = btn.closest('.review-content').querySelector('.review-text');
          const isExpanded = reviewText.classList.contains('expanded-review');
          if (!isExpanded) {
            // Розгортаємо
            const fullText = decodeURIComponent(reviewText.getAttribute('data-full-text'));
            reviewText.textContent = fullText;
            reviewText.classList.add('expanded-review');
            btn.textContent = 'Приховати...';
            const reviewContent = reviewText.parentElement;
            const reviewItem = reviewText.closest('.review-item');
            if (reviewContent) reviewContent.classList.add('expanded-review');
            if (reviewItem) reviewItem.classList.add('expanded-review');
          } else {
            // Згортаємо
            const shortText = decodeURIComponent(reviewText.getAttribute('data-short-text'));
            reviewText.textContent = shortText;
            reviewText.classList.remove('expanded-review');
            btn.textContent = 'Дивитись повністю...';
            const reviewContent = reviewText.parentElement;
            const reviewItem = reviewText.closest('.review-item');
            if (reviewContent) reviewContent.classList.remove('expanded-review');
            if (reviewItem) reviewItem.classList.remove('expanded-review');
          }
          // Переміщуємо кнопку після тексту
          reviewText.after(btn);
        });
      });
      // Додаю обробник для видалення рецензії
      const deleteButtons = reviewsList.querySelectorAll('.delete-review-btn');
      deleteButtons.forEach(button => {
        button.addEventListener('click', async () => {
          const reviewId = button.getAttribute('data-id');
          if (confirm('Ви дійсно хочете видалити цю рецензію?')) {
            await window.profileManager.deleteUserReview(reviewId, button);
          }
        });
      });
    } catch (error) {
      console.error('Помилка при завантаженні рецензій:', error);
      reviewsList.innerHTML = `
        <div class="error-container">
          <i class="fas fa-exclamation-circle"></i>
          <p>Помилка при завантаженні рецензій: ${error.message}</p>
        </div>
      `;
    }
  }

  // Завантаження обраного користувача
  async loadUserFavorites() {
    const favoritesList = document.getElementById('favorites-list');
    if (!favoritesList) return;

    try {
      // Показуємо анімацію завантаження
      favoritesList.innerHTML = `
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Завантаження обраного...</p>
        </div>
      `;

      // Отримуємо ID користувача з даних профілю
      if (!this.profileData || !this.profileData.profile) {
        await this.loadProfileData();
      }

      const userId = this.profileData?.profile?.user_id;
      if (!userId) {
        throw new Error('Дані користувача не знайдено');
      }

      // Запитуємо список обраного користувача
      const response = await fetch(`/api/favorites/user/${userId}`, {
        method: 'GET',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Не вдалося завантажити обране');
      }

      const data = await response.json();
      const favorites = data.favorites || [];

      // Якщо список порожній, показуємо відповідне повідомлення
      if (favorites.length === 0) {
        favoritesList.innerHTML = '<div class="empty-content">У вас поки немає обраних фільмів</div>';
        return;
      }

      // Формуємо HTML з обраним
      let favoritesHTML = '<div class="favorites-grid">';
      
      for (const favorite of favorites) {
        favoritesHTML += `
          <div class="favorite-item" data-favorite-id="${favorite.favorites_id}" style="position:relative;">
            <div class="favorite-poster" data-movie-id="${favorite.media.id}" style="cursor:pointer;">
              <img src="${favorite.media.poster_url}" alt="${favorite.media.title}">
            </div>
            <div class="favorite-info">
              <h3 data-movie-id="${favorite.media.id}" style="cursor:pointer;">${favorite.media.title}</h3>
              <p>Рейтинг: ${favorite.media.imdb_rating || 'Н/Д'}</p>
            </div>
            <button class="favorite-delete-icon-btn" data-favorite-id="${favorite.favorites_id}" title="Видалити з обраного">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        `;
      }
      
      favoritesHTML += '</div>';
      favoritesList.innerHTML = favoritesHTML;
      // Додаємо обробники для кнопок видалення з обраного
      const removeButtons = favoritesList.querySelectorAll('.favorite-delete-icon-btn');
      removeButtons.forEach(button => {
        button.addEventListener('click', async () => {
          const favoriteId = button.getAttribute('data-favorite-id');
          await this.removeFavorite(favoriteId, button);
        });
      });
      // Додаю обробники переходу на сторінку фільму
      const posterLinks = favoritesList.querySelectorAll('.favorite-poster, .favorite-info h3');
      posterLinks.forEach(el => {
        el.addEventListener('click', function() {
          const movieId = el.getAttribute('data-movie-id');
          if (movieId) {
            window.location.href = `/movie/${movieId}`;
          }
        });
      });
    } catch (error) {
      console.error('Помилка при завантаженні обраного:', error);
      favoritesList.innerHTML = `
        <div class="error-container">
          <i class="fas fa-exclamation-circle"></i>
          <p>Помилка при завантаженні обраного: ${error.message}</p>
        </div>
      `;
    }
  }

  // Метод для видалення фільму з обраного
  async removeFavorite(favoriteId, buttonElement) {
    try {
      // Змінюємо текст кнопки і робимо її неактивною
      const originalText = buttonElement.innerHTML;
      buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Видаляю...';
      buttonElement.disabled = true;

      const response = await fetch(`/api/favorites/${favoriteId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Не вдалося видалити з обраного');
      }

      // Якщо видалення пройшло успішно, оновлюємо UI
      buttonElement.closest('.favorite-item').remove();

      // Оновлюємо лічильник обраного
      const count = parseInt(this.favoritesCount.textContent) - 1;
      this.favoritesCount.textContent = count >= 0 ? count : 0;

      // Якщо після видалення елементів не залишилось, показуємо повідомлення
      const favoritesGrid = document.querySelector('.favorites-grid');
      if (favoritesGrid && favoritesGrid.children.length === 0) {
        document.getElementById('favorites-list').innerHTML = '<div class="empty-content">У вас поки немає обраних фільмів</div>';
      }

      // Показуємо сповіщення
      this.showNotification('Фільм видалено з обраного', 'success');
    } catch (error) {
      console.error('Помилка при видаленні з обраного:', error);
      // Відновлюємо стан кнопки
      buttonElement.innerHTML = originalText;
      buttonElement.disabled = false;

      this.showNotification('Помилка при видаленні з обраного: ' + error.message, 'error');
    }
  }

  // Додаю метод для видалення рецензії користувача
  deleteUserReview = async function(reviewId, buttonElement) {
    try {
      buttonElement.disabled = true;
      buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Видаляю...';
      const response = await fetch(`/api/reviews/${reviewId}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Не вдалося видалити рецензію');
      }
      // Видаляємо елемент з DOM
      buttonElement.closest('.review-item').remove();
      this.showNotification('Рецензію видалено', 'success');
    } catch (error) {
      buttonElement.disabled = false;
      buttonElement.innerHTML = '<i class="fas fa-trash"></i> Видалити рецензію';
      this.showNotification('Помилка при видаленні рецензії: ' + error.message, 'error');
    }
  };

  // ============================================================
  // РАНГ ПРОФІЛЮ
  // ============================================================
  async loadUserRank(userId) {
    try {
      const uid = userId || this.profileData?.profile?.user_id;
      if (!uid) return;

      const response = await fetch(`/api/profile/rank/${uid}`, {
        credentials: 'include'
      });

      if (!response.ok) return;

      const data = await response.json();
      const rank = data.rank;
      if (!rank) return;

      this.renderRank(rank);
    } catch (e) {
      console.warn('Не вдалося завантажити ранг:', e);
    }
  }

  renderRank(rank) {
    const iconEl   = document.getElementById('rank-icon');
    const titleEl  = document.getElementById('rank-title');
    const levelEl  = document.getElementById('rank-level');
    const fillEl   = document.getElementById('rank-xp-fill');
    const xpTextEl = document.getElementById('rank-xp-text');

    if (!iconEl) return;

    iconEl.textContent  = rank.rank_icon  || '🎞️';
    titleEl.textContent = rank.rank_title || 'Глядач';
    levelEl.textContent = `Рівень ${rank.level || 1}`;

    // Колір назви рангу
    if (titleEl && rank.rank_color) {
      titleEl.style.color = rank.rank_color;
    }

    // XP прогрес-бар
    const xp        = rank.xp || 0;
    const xpForNext = rank.xp_for_next_level || 1;
    const pct       = Math.min(100, Math.round((xp / xpForNext) * 100));

    setTimeout(() => {
      if (fillEl)   fillEl.style.width = `${pct}%`;
      if (xpTextEl) xpTextEl.textContent = `${xp} / ${xpForNext} XP`;
    }, 200); // невелика затримка для плавної анімації
  }

  // ============================================================
  // ДОСЯГНЕННЯ
  // ============================================================
  async loadUserAchievements() {
    const grid = document.getElementById('achievements-grid');
    if (!grid) return;

    // Прибираємо кешування, щоб завжди бачити актуальні досягнення (якщо XP оновилося)
    // if (this._achievementsLoaded) return;

    try {
      grid.innerHTML = `
        <div class="loading-container">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Завантаження досягнень...</p>
        </div>`;

      const uid = this.profileData?.profile?.user_id;
      if (!uid) throw new Error('user_id not found');

      const [allRes, userRes] = await Promise.all([
        fetch('/api/achievements/all',            { credentials: 'include' }),
        fetch(`/api/achievements/user/${uid}`,    { credentials: 'include' })
      ]);

      const allData  = allRes.ok  ? await allRes.json()  : { achievements: [] };
      const userData = userRes.ok ? await userRes.json() : { achievements: [] };

      this._allAchievements  = allData.achievements  || [];
      this._userAchievements = userData.achievements || [];
      this._achievementsLoaded = true;

      this.renderAchievements('all');
      this.setupAchievementCategories();
      this.updateAchievementStats();

    } catch (e) {
      console.error('Помилка завантаження досягнень:', e);
      if (grid) {
        grid.innerHTML = `
          <div class="error-container">
            <i class="fas fa-exclamation-circle"></i>
            <p>Помилка при завантаженні досягнень: ${e.message}</p>
          </div>`;
      }
    }
  }

  renderAchievements(category = 'all') {
    const grid = document.getElementById('achievements-grid');
    if (!grid) return;

    const earnedIds = new Set(
      (this._userAchievements || []).map(a => a.achievement_id)
    );
    const earnedMap = {};
    (this._userAchievements || []).forEach(a => { earnedMap[a.achievement_id] = a; });

    let items = this._allAchievements || [];
    if (category !== 'all') {
      items = items.filter(a => a.category === category);
    }

    if (items.length === 0) {
      grid.innerHTML = '<div class="empty-content">У цій категорії немає досягнень</div>';
      return;
    }

    // Спочатку отримані, потім заблоковані
    items = [
      ...items.filter(a => earnedIds.has(a.id)),
      ...items.filter(a => !earnedIds.has(a.id))
    ];

    grid.innerHTML = items.map(ach => {
      const isEarned  = earnedIds.has(ach.id);
      const userAch   = earnedMap[ach.id];
      const isHidden  = ach.is_hidden && !isEarned;

      const cardClass = isEarned ? 'earned' : (isHidden ? 'locked hidden-locked' : 'locked');
      const icon      = isHidden ? '❓' : ach.icon;
      const title     = isHidden ? 'Таємне досягнення' : ach.title;
      const desc      = isHidden ? 'Виконайте певну умову, щоб розкрити' : ach.description;

      const earnedBadge = isEarned
        ? '<span class="ach-card-earned-badge">✓ Отримано</span>'
        : '<i class="fas fa-lock ach-card-lock"></i>';

      const dateHtml = isEarned && userAch?.earned_at
        ? `<span class="ach-card-date">${new Date(userAch.earned_at).toLocaleDateString('uk-UA')}</span>`
        : '';

      const xpHtml = ach.xp_reward > 0
        ? `<span class="ach-card-xp">+${ach.xp_reward} XP</span>`
        : '';

      return `
        <div class="achievement-card ${cardClass}" title="${desc}">
          ${earnedBadge}
          <span class="ach-card-icon">${icon}</span>
          <span class="ach-card-title">${title}</span>
          <span class="ach-card-desc">${desc}</span>
          ${xpHtml}
          ${dateHtml}
        </div>`;
    }).join('');
  }

  setupAchievementCategories() {
    const btns = document.querySelectorAll('.ach-cat-btn');
    btns.forEach(btn => {
      btn.addEventListener('click', () => {
        btns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.renderAchievements(btn.dataset.cat);
      });
    });
  }

  updateAchievementStats() {
    const earned = (this._userAchievements || []).length;
    const total  = (this._allAchievements  || []).filter(a => !a.is_hidden).length;
    const xpSum  = (this._userAchievements || []).reduce((sum, ua) => {
      const ach = (this._allAchievements || []).find(a => a.id === ua.achievement_id);
      return sum + (ach?.xp_reward || 0);
    }, 0);

    const earnedEl = document.getElementById('ach-earned-count');
    const totalEl  = document.getElementById('ach-total-count');
    const xpEl     = document.getElementById('ach-xp-total');

    if (earnedEl) earnedEl.textContent = earned;
    if (totalEl)  totalEl.textContent  = total;
    if (xpEl)     xpEl.textContent     = xpSum;
  }
}

// Ініціалізація менеджера профілю при завантаженні сторінки
document.addEventListener('DOMContentLoaded', () => {
  const profileManager = new ProfileManager();

  // Експортуємо екземпляр для використання в інших модулях
  window.profileManager = profileManager;
});

async function removeFromFavorites(favoriteId) {
  try {
    const response = await fetch(`/api/favorites/${favoriteId}`, {
      method: 'DELETE',
      credentials: 'include'
    });

    if (!response.ok) {
      throw new Error('Помилка при видаленні з обраного');
    }

    // Видаляємо елемент з DOM
    const favoriteItem = document.querySelector(`[data-favorite-id="${favoriteId}"]`);
    if (favoriteItem) {
      favoriteItem.remove();
    }

    // Перевіряємо, чи залишились ще обрані фільми
    const favoritesGrid = document.querySelector('.favorites-grid');
    if (favoritesGrid && favoritesGrid.children.length === 0) {
      document.getElementById('favorites-list').innerHTML =
        '<p>У вас поки немає обраних фільмів</p>';
    }
  } catch (error) {
    console.error('Помилка:', error);
    alert('Не вдалося видалити з обраного');
  }
}

// Скидання стану кнопки 'Написати' при поверненні назад (bfcache/pageshow)
window.addEventListener('pageshow', function() {
  const writeBtn = document.getElementById('write-message-btn');
  const params = new URLSearchParams(window.location.search);
  const profileUserId = params.get('id');
  const currentUser = window.authManager?.currentUser;
  if (writeBtn && profileUserId && currentUser && currentUser.user_id != profileUserId) {
    writeBtn.disabled = false;
    writeBtn.innerHTML = '<i class="fas fa-envelope"></i> Написати';
  }
}); 